﻿using Microsoft.EntityFrameworkCore;
using Civica.ABI.MDM.API.Shared.Extensions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Shared.Extensions
{
    public static class DataPagerExtension
    {
        public static async Task<Pagination<TModel>> PaginateAsync<TModel>(
            this IQueryable<TModel> query,
            int page,
            int limit)
            where TModel : class
        {
            var paged = new Pagination<TModel>();
            page = (page < 0) ? 1 : page;
            paged.CurrentPage = page;
            paged.PageSize = limit;
            paged.TotalItems = await query.CountAsync();

            var startRow = (page - 1) * limit;
            paged.Items = await query.Skip(startRow).Take(limit).ToListAsync();

            paged.TotalPages = (int)Math.Ceiling(paged.TotalItems / (double)limit);
            return paged;
        }
    }
}
