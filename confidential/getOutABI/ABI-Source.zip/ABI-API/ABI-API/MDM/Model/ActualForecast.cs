﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ActualForecast
    {
        public string T7 { get; set; }
        public string BusinessUnit { get; set; }
        public string T3 { get; set; }
        public string Department { get; set; }
        public string AccountCode { get; set; }
        public string AccountDescription { get; set; }
        public DateTime? MonthDescription { get; set; }
        public double? CalendarMonth { get; set; }
        public double? CalendarYear { get; set; }
        public double? Period { get; set; }
        public double? Value { get; set; }
        public string ValueType { get; set; }
        public string Currency { get; set; }
        public string SystemInstance { get; set; }
    }
}
