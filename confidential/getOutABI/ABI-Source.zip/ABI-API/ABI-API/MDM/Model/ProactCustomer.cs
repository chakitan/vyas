﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProactCustomer
    {
        public int Id { get; set; }
        public string CustomerCode { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
    }
}
