﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ContractLine
    {
        public int ContractId { get; set; }
        public int LineId { get; set; }
        public int? CustomerId { get; set; }
        public string ContractRef { get; set; }
        public string Description { get; set; }
        public DateTime? OrderDate { get; set; }
        public string ProductCatg { get; set; }
        public string ProductType { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string MaintFlag { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
