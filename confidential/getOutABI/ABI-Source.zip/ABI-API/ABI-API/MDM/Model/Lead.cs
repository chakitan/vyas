﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Lead
    {
        public int EnquiryId { get; set; }
        public int? SubLeadId { get; set; }
        public int? EnquirerId { get; set; }
        public string Method { get; set; }
        public int? RegionId { get; set; }
        public string Region { get; set; }
        public string TerritoryName { get; set; }
        public string Division { get; set; }
        public string SubdivisionName { get; set; }
        public string ProductDesc { get; set; }
        public string SaleType { get; set; }
        public string AccountType { get; set; }
        public string ResultName { get; set; }
        public decimal? ChanceOfClose { get; set; }
        public DateTime? LeadCreateDate { get; set; }
        public DateTime? LeadIssueDate { get; set; }
        public DateTime? Estclosedate { get; set; }
        public DateTime? Nextcontact { get; set; }
        public string Description { get; set; }
        public string Currency { get; set; }
        public decimal? OwnSoftware { get; set; }
        public decimal? TotalRevenue { get; set; }
        public decimal? TotalMargin { get; set; }
        public decimal? OwnSoftwareMargin { get; set; }
        public decimal? ThirdPartySoftware { get; set; }
        public decimal? ThirdPartySoftwareMargin { get; set; }
        public decimal? OwnServices { get; set; }
        public decimal? OwnServicesMargin { get; set; }
        public decimal? ThirdPartyServices { get; set; }
        public decimal? ThirdPartyServicesMargin { get; set; }
        public decimal? Hardware { get; set; }
        public decimal? HardwareMargin { get; set; }
        public decimal? SupportNew { get; set; }
        public decimal? SupportNewMargin { get; set; }
        public decimal? SupportReSigned { get; set; }
        public decimal? SupportReSignedMargin { get; set; }
        public decimal? ResignedReplaceAmount { get; set; }
        public decimal? ResignedReplaceAmountMargin { get; set; }
        public string LossReason { get; set; }
        public int? LengthofContract { get; set; }
        public string SolutionsArea { get; set; }
        public string DatabaseProvider { get; set; }
        public string ProcurementMethodName { get; set; }
        public string MediaName { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UpdatedBy { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? PersonMdmid { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string RepEmail { get; set; }
        public string ValidationComment { get; set; }
    }
}
