﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProactLegalEntity
    {
        public int Id { get; set; }
        public string Label { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
    }
}
