﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class BusinessUnitLookup
    {
        public int BusinessUnitLookupId { get; set; }
        public string Name { get; set; }
        public string Division { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string Bucode { get; set; }
        public string Region { get; set; }
        public string T7code { get; set; }
        public string SourceIdentifier { get; set; }
        public int? WorkflowStatusId { get; set; }
        public string Remarks { get; set; }
        public Guid RunId { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }

        public virtual WorkflowStatus WorkflowStatus { get; set; }
    }
}
