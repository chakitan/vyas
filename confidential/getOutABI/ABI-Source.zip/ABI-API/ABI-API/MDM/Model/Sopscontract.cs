﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Sopscontract
    {
        public int ContractId { get; set; }
        public string ContractRef { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
    }
}
