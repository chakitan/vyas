﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class BusinessUnit1
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public decimal WorkingTime { get; set; }
        public bool Active { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SunT7code { get; set; }
        public int LegalEntityId { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
