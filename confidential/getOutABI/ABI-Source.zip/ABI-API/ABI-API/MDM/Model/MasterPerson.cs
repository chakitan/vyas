﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class MasterPerson
    {
        public int PersonMdmid { get; set; }
        public string Name { get; set; }
        public string EmployeeId { get; set; }
        public string Email { get; set; }
        public string Qcsp { get; set; }
        public string CostCentre { get; set; }
        public string BusinessUnitName { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string Division { get; set; }

        public string SourceIdentifier { get; set; }
        public bool IsDeleted { get; set; }
        public string Remarks { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }
    }
}
