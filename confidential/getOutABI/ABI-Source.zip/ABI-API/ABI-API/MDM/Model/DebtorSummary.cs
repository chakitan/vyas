﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class DebtorSummary
    {
        public string T7code { get; set; }
        public string BusinessUnitName { get; set; }
        public DateTime MonthEndDate { get; set; }
        public decimal? TotalDebtorAmount { get; set; }
        public int? TotalDebtorDay { get; set; }
        public string CurrencyCode { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
