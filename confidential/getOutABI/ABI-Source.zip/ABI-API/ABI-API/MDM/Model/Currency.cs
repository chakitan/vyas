﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Currency
    {
        public string CurrencyCode { get; set; }
        public string Name { get; set; }
    }
}
