﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Model
{
    public class Request
    {
        public string filter { get; set; }  
    }
}
