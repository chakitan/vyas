﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class TimesheetPeriodCutOff
    {
        public int Id { get; set; }
        public int TimesheetPeriodId { get; set; }
        public DateTime CutOffDate { get; set; }
        public int LegalEntityId { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
