﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class DimPeriod
    {
        public int PeriodKey { get; set; }
        public int CalendarMonth { get; set; }
        public int CalendarYear { get; set; }
        public int CalendarYyyymm { get; set; }
        public int FinancialMonth { get; set; }
        public int FinancialYear { get; set; }
        public int FinancialYyyymm { get; set; }
        public int Quarter { get; set; }
        public string QuarterName { get; set; }
        public DateTime DateInserted { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string Dmlflag { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
