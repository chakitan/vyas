﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ContractRevenue
    {
        public int ContractId { get; set; }
        public int RevId { get; set; }
        public int? CustomerId { get; set; }
        public int? LineId { get; set; }
        public string Status { get; set; }
        public int? RevPeriod { get; set; }
        public decimal? RevValue { get; set; }
        public decimal? RevCost { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
