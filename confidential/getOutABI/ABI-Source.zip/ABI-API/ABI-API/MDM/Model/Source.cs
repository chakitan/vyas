﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Source
    {
        public int SourceId { get; set; }
        public string SourceIdentifier { get; set; }
        public string Description { get; set; }
        public bool Deleted { get; set; }
        public string Remarks { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }
    }
}
