﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProjectInvoiceTemplate
    {
        public int Id { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public int ContractTypeId { get; set; }
        public decimal? ContractHoursPerDay { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
