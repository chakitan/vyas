﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Sopsuser
    {
        public int EmployeeId { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
    }
}
