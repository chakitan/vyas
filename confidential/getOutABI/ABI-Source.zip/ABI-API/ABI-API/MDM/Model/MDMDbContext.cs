﻿using System;
using System.Collections.Generic;
using Civica.ABI.MDM.API.DTO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Civica.ABI.MDM.API.Model
{
    public partial class MDMDbContext : DbContext
    {
        public MDMDbContext()
        {
        }

        public MDMDbContext(DbContextOptions<MDMDbContext> options)
            : base(options)
        {
            var conn = (Microsoft.Data.SqlClient.SqlConnection)Database.GetDbConnection();
            conn.AccessToken = (new Microsoft.Azure.Services.AppAuthentication.AzureServiceTokenProvider()).GetAccessTokenAsync("https://database.windows.net/").Result;
        }

        public virtual DbSet<Action> Actions { get; set; }
        public virtual DbSet<ActualForecast> ActualForecasts { get; set; }
        public virtual DbSet<Agent> Agents { get; set; }
        public virtual DbSet<AgentInstance> AgentInstances { get; set; }
        public virtual DbSet<AgentVersion> AgentVersions { get; set; }
        public virtual DbSet<Allocation> Allocations { get; set; }
        public virtual DbSet<AllocationPeriod> AllocationPeriods { get; set; }
        public virtual DbSet<Budget> Budgets { get; set; }
        public virtual DbSet<BusinessUnit> BusinessUnits { get; set; }
        public virtual DbSet<BusinessUnit1> BusinessUnits1 { get; set; }
        public virtual DbSet<BusinessUnitLookup> BusinessUnitLookups { get; set; }
        public virtual DbSet<CashConversion> CashConversions { get; set; }
        public virtual DbSet<CompletedOneToOneMeeting> CompletedOneToOneMeetings { get; set; }
        public virtual DbSet<Configuration> Configurations { get; set; }
        public virtual DbSet<Contract> Contracts { get; set; }
        public virtual DbSet<ContractLine> ContractLines { get; set; }
        public virtual DbSet<ContractLineAudit> ContractLineAudits { get; set; }
        public virtual DbSet<ContractRevenue> ContractRevenues { get; set; }
        public virtual DbSet<ContractRole> ContractRoles { get; set; }
        public virtual DbSet<ContractType> ContractTypes { get; set; }
        public virtual DbSet<Correspondence> Correspondences { get; set; }
        public virtual DbSet<CostCentre> CostCentres { get; set; }
        public virtual DbSet<Currency> Currencies { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Customer1> Customers1 { get; set; }
        public virtual DbSet<DebtorSummary> DebtorSummaries { get; set; }
        public virtual DbSet<DeliveryCompliantProject> DeliveryCompliantProjects { get; set; }
        public virtual DbSet<DimCostCentre> DimCostCentres { get; set; }
        public virtual DbSet<DimDepartment> DimDepartments { get; set; }
        public virtual DbSet<DimOrganisationalUnit> DimOrganisationalUnits { get; set; }
        public virtual DbSet<DimPeriod> DimPeriods { get; set; }
        public virtual DbSet<DimSalesContractType> DimSalesContractTypes { get; set; }
        public virtual DbSet<DivisionBusinessUnit> DivisionBusinessUnits { get; set; }
        public virtual DbSet<EnumType> EnumTypes { get; set; }
        public virtual DbSet<FabsdimOrganisationalUnit> FabsdimOrganisationalUnits { get; set; }
        public virtual DbSet<FabsfactCapDevCost> FabsfactCapDevCosts { get; set; }
        public virtual DbSet<FabsfactEmployeeHeadcount> FabsfactEmployeeHeadcounts { get; set; }
        public virtual DbSet<FabsfactEmploymentCost> FabsfactEmploymentCosts { get; set; }
        public virtual DbSet<FabsfactSalesRevenue> FabsfactSalesRevenues { get; set; }
        public virtual DbSet<FactCapDevCost> FactCapDevCosts { get; set; }
        public virtual DbSet<FactEmployeeHeadcount> FactEmployeeHeadcounts { get; set; }
        public virtual DbSet<FactEmploymentCost> FactEmploymentCosts { get; set; }
        public virtual DbSet<FactSalesRevenue> FactSalesRevenues { get; set; }
        public virtual DbSet<ForecastDetail> ForecastDetails { get; set; }
        public virtual DbSet<ForecastMonth> ForecastMonths { get; set; }
        public virtual DbSet<ForecastRag> ForecastRags { get; set; }
        public virtual DbSet<ForecastRagtype> ForecastRagtypes { get; set; }
        public virtual DbSet<ForecastSummary> ForecastSummaries { get; set; }
        public virtual DbSet<IgminMonth> IgminMonths { get; set; }
        public virtual DbSet<IgmyearToGo> IgmyearToGos { get; set; }
        public virtual DbSet<Iprrevenue> Iprrevenues { get; set; }
        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<Lead> Leads { get; set; }
        public virtual DbSet<LegalEntity> LegalEntities { get; set; }
        public virtual DbSet<MaintenanceSupportRevenue> MaintenanceSupportRevenues { get; set; }
        public virtual DbSet<ManagedServiceRevenue> ManagedServiceRevenues { get; set; }
        public virtual DbSet<MasterBusinessUnit> MasterBusinessUnits { get; set; }
        public virtual DbSet<MasterPerson> MasterPeople { get; set; }
        public virtual DbSet<MessageQueue> MessageQueues { get; set; }
        public virtual DbSet<MetaInformation> MetaInformations { get; set; }
        public virtual DbSet<MetaInformation1> MetaInformations1 { get; set; }
        public virtual DbSet<MonthlyTeamMeetingCompleted> MonthlyTeamMeetingCompleteds { get; set; }
        public virtual DbSet<Movement> Movements { get; set; }
        public virtual DbSet<NonUkbusinessUnit> NonUkbusinessUnits { get; set; }
        public virtual DbSet<ObservedMeeting> ObservedMeetings { get; set; }
        public virtual DbSet<PeriodEnd> PeriodEnds { get; set; }
        public virtual DbSet<PeriodForecastingPeriod> PeriodForecastingPeriods { get; set; }
        public virtual DbSet<Person> People { get; set; }
        public virtual DbSet<PersonLookup> PersonLookups { get; set; }
        public virtual DbSet<PersonalForecastNonRecurringRevenue> PersonalForecastNonRecurringRevenues { get; set; }
        public virtual DbSet<ProactAllocationPeriod> ProactAllocationPeriods { get; set; }
        public virtual DbSet<ProactBusinessUnit> ProactBusinessUnits { get; set; }
        public virtual DbSet<ProactCostCentre> ProactCostCentres { get; set; }
        public virtual DbSet<ProactCustomer> ProactCustomers { get; set; }
        public virtual DbSet<ProactForecastMonth> ProactForecastMonths { get; set; }
        public virtual DbSet<ProactForecastRagtype> ProactForecastRagtypes { get; set; }
        public virtual DbSet<ProactForecastSummary> ProactForecastSummaries { get; set; }
        public virtual DbSet<ProactLegalEntity> ProactLegalEntities { get; set; }
        public virtual DbSet<ProactProject> ProactProjects { get; set; }
        public virtual DbSet<ProactProjectType> ProactProjectTypes { get; set; }
        public virtual DbSet<ProactSiteLogForecast> ProactSiteLogForecasts { get; set; }
        public virtual DbSet<ProactTimesheetPeriod> ProactTimesheetPeriods { get; set; }
        public virtual DbSet<ProfessionalServiceRevenue> ProfessionalServiceRevenues { get; set; }
        public virtual DbSet<ProfiledReport> ProfiledReports { get; set; }
        public virtual DbSet<Project> Projects { get; set; }
        public virtual DbSet<ProjectInvoiceTemplate> ProjectInvoiceTemplates { get; set; }
        public virtual DbSet<ProjectType> ProjectTypes { get; set; }
        public virtual DbSet<ProvisionMarkerDss> ProvisionMarkerDsses { get; set; }
        public virtual DbSet<Resource> Resources { get; set; }
        public virtual DbSet<Resource1> Resources1 { get; set; }
        public virtual DbSet<RunStatus> RunStatuses { get; set; }
        public virtual DbSet<SalesCompliantProject> SalesCompliantProjects { get; set; }
        public virtual DbSet<SalesDirectorForecast> SalesDirectorForecasts { get; set; }
        public virtual DbSet<Scaleunitlimit> Scaleunitlimits { get; set; }
        public virtual DbSet<Schedule> Schedules { get; set; }
        public virtual DbSet<ScheduleTask> ScheduleTasks { get; set; }
        public virtual DbSet<ScheduleTask1> ScheduleTasks1 { get; set; }
        public virtual DbSet<SchemaInfoDss> SchemaInfoDsses { get; set; }
        public virtual DbSet<ScopeConfigDss> ScopeConfigDsses { get; set; }
        public virtual DbSet<ScopeInfoDss> ScopeInfoDsses { get; set; }
        public virtual DbSet<SiteLogForecast> SiteLogForecasts { get; set; }
        public virtual DbSet<SiteLogForecastDetail> SiteLogForecastDetails { get; set; }
        public virtual DbSet<SiteLogProject> SiteLogProjects { get; set; }
        public virtual DbSet<Sopscontract> Sopscontracts { get; set; }
        public virtual DbSet<SopscontractLine> SopscontractLines { get; set; }
        public virtual DbSet<Sopscustomer> Sopscustomers { get; set; }
        public virtual DbSet<Sopsuser> Sopsusers { get; set; }
        public virtual DbSet<Source> Sources { get; set; }
        public virtual DbSet<Subscription> Subscriptions { get; set; }
        public virtual DbSet<SyncObjectDatum> SyncObjectData { get; set; }
        public virtual DbSet<Syncgroup> Syncgroups { get; set; }
        public virtual DbSet<Syncgroupmember> Syncgroupmembers { get; set; }
        public virtual DbSet<Task> Tasks { get; set; }
        public virtual DbSet<ThirdPartyServiceHardwareGm> ThirdPartyServiceHardwareGms { get; set; }
        public virtual DbSet<TimesheetEntry> TimesheetEntries { get; set; }
        public virtual DbSet<TimesheetPeriod> TimesheetPeriods { get; set; }
        public virtual DbSet<TimesheetPeriodCutOff> TimesheetPeriodCutOffs { get; set; }
        public virtual DbSet<TimesheetSubmission> TimesheetSubmissions { get; set; }
        public virtual DbSet<Uihistory> Uihistories { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<User1> Users1 { get; set; }
        public virtual DbSet<UserCode> UserCodes { get; set; }
        public virtual DbSet<Userdatabase> Userdatabases { get; set; }
        public virtual DbSet<WorkflowStatus> WorkflowStatuses { get; set; }
        public virtual DbSet<usp_FetchBlockedRecordCountForEachSourceTable> Usp_FetchBlockedRecordCounts { get; set; }
       public virtual DbSet<MasterPersonDataSetDTO> MasterPersonDataSetDTO { get; set; }
        //public virtual DbSet<ManagePersonDataSetDTO> ManagePersonDataSetDTO { get; set; }
        public virtual DbSet<ETLSourceSystemRegion> ETLsourceSystemRegions { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<usp_FetchBlockedRecordCountForEachSourceTable>().HasNoKey();
           modelBuilder.Entity<MasterPersonDataSetDTO>().HasNoKey();
           // modelBuilder.Entity<ManagePersonDataSetDTO>().HasNoKey();
            modelBuilder.Entity<Action>(entity =>
            {
                entity.ToTable("action", "dss");

                entity.HasIndex(e => new { e.State, e.Lastupdatetime }, "index_action_state_lastupdatetime");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Creationtime)
                    .HasColumnType("datetime")
                    .HasColumnName("creationtime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Lastupdatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastupdatetime");

                entity.Property(e => e.State).HasColumnName("state");

                entity.Property(e => e.Syncgroupid).HasColumnName("syncgroupid");

                entity.Property(e => e.Type).HasColumnName("type");
            });

            modelBuilder.Entity<ActualForecast>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ActualForecast", "FABS");

                entity.Property(e => e.AccountCode)
                    .HasMaxLength(255)
                    .HasColumnName("Account Code");

                entity.Property(e => e.AccountDescription)
                    .HasMaxLength(255)
                    .HasColumnName("Account Description");

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(255)
                    .HasColumnName("Business Unit");

                entity.Property(e => e.CalendarMonth).HasColumnName("Calendar Month");

                entity.Property(e => e.CalendarYear).HasColumnName("Calendar Year");

                entity.Property(e => e.Currency).HasMaxLength(255);

                entity.Property(e => e.Department).HasMaxLength(255);

                entity.Property(e => e.MonthDescription)
                    .HasColumnType("datetime")
                    .HasColumnName("Month Description");

                entity.Property(e => e.SystemInstance)
                    .HasMaxLength(255)
                    .HasColumnName("System Instance");

                entity.Property(e => e.T3).HasMaxLength(255);

                entity.Property(e => e.T7).HasMaxLength(255);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(255)
                    .HasColumnName("Value Type");
            });

            modelBuilder.Entity<Agent>(entity =>
            {
                entity.ToTable("agent", "dss");

                entity.HasIndex(e => new { e.Subscriptionid, e.Name }, "IX_Agent_SubId_Name")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.IsOnPremise).HasColumnName("is_on_premise");

                entity.Property(e => e.Lastalivetime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastalivetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(140)
                    .HasColumnName("name");

                entity.Property(e => e.PasswordHash)
                    .HasMaxLength(256)
                    .HasColumnName("password_hash");

                entity.Property(e => e.PasswordSalt)
                    .HasMaxLength(256)
                    .HasColumnName("password_salt");

                entity.Property(e => e.State)
                    .HasColumnName("state")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Subscriptionid).HasColumnName("subscriptionid");

                entity.Property(e => e.Version)
                    .HasMaxLength(40)
                    .HasColumnName("version");

                entity.HasOne(d => d.Subscription)
                    .WithMany(p => p.Agents)
                    .HasForeignKey(d => d.Subscriptionid)
                    .HasConstraintName("FK__agent__subscript");
            });

            modelBuilder.Entity<AgentInstance>(entity =>
            {
                entity.ToTable("agent_instance", "dss");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Agentid).HasColumnName("agentid");

                entity.Property(e => e.Lastalivetime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastalivetime");

                entity.Property(e => e.Version)
                    .IsRequired()
                    .HasMaxLength(40)
                    .HasColumnName("version");

                entity.HasOne(d => d.Agent)
                    .WithMany(p => p.AgentInstances)
                    .HasForeignKey(d => d.Agentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__agent_ins__agent");
            });

            modelBuilder.Entity<AgentVersion>(entity =>
            {
                entity.ToTable("agent_version", "dss");

                entity.HasIndex(e => e.Version, "UQ__agent_ve__0F540134997A1B4C")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Comment).HasMaxLength(200);

                entity.Property(e => e.ExpiresOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('9999-12-31 23:59:59.997')");

                entity.Property(e => e.Version)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Allocation>(entity =>
            {
                entity.ToTable("Allocation", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ChargeTypeDescription).HasMaxLength(50);

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EditedDate).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RoleDescription).HasMaxLength(255);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StatusDescription).HasMaxLength(50);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AllocationPeriod>(entity =>
            {
                entity.ToTable("AllocationPeriod", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.DaysEffort).HasColumnType("decimal(10, 4)");

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Budget>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Budget", "FABS");

                entity.Property(e => e.AccountCode)
                    .HasMaxLength(255)
                    .HasColumnName("Account Code");

                entity.Property(e => e.AccountDescription)
                    .HasMaxLength(255)
                    .HasColumnName("Account Description");

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(255)
                    .HasColumnName("Business Unit");

                entity.Property(e => e.CalendarMonth).HasColumnName("Calendar Month");

                entity.Property(e => e.CalendarYear).HasColumnName("Calendar Year");

                entity.Property(e => e.Currency).HasMaxLength(255);

                entity.Property(e => e.Department).HasMaxLength(255);

                entity.Property(e => e.MonthDescription)
                    .HasColumnType("datetime")
                    .HasColumnName("Month Description");

                entity.Property(e => e.SystemInstance)
                    .HasMaxLength(255)
                    .HasColumnName("System Instance");

                entity.Property(e => e.T3).HasMaxLength(255);

                entity.Property(e => e.T7).HasMaxLength(255);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(255)
                    .HasColumnName("Value Type");
            });

            modelBuilder.Entity<BusinessUnit>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("BusinessUnit", "Master");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Code)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.DivisionName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BusinessUnit1>(entity =>
            {
                entity.ToTable("BusinessUnit", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SunT7code)
                    .HasMaxLength(3)
                    .HasColumnName("SunT7Code");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WorkingTime).HasColumnType("decimal(4, 2)");
            });

            modelBuilder.Entity<BusinessUnitLookup>(entity =>
            {
                entity.ToTable("BusinessUnitLookup", "MDM");

                entity.Property(e => e.BusinessUnitLookupId).HasColumnName("BusinessUnitLookupID");

                entity.Property(e => e.Bucode)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BUCode");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMID");

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.RunId).HasColumnName("RunID");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.Property(e => e.T7code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.WorkflowStatusId).HasColumnName("WorkflowStatusID");

                entity.HasOne(d => d.WorkflowStatus)
                    .WithMany(p => p.BusinessUnitLookups)
                    .HasForeignKey(d => d.WorkflowStatusId)
                    .HasConstraintName("FK_MDM_BusinessUnitLookup_WorkflowStatusID(K)");
            });

            modelBuilder.Entity<CashConversion>(entity =>
            {
                entity.HasKey(e => new { e.BusinessUnitName, e.MonthEndDate })
                    .HasName("PK_Finance_CashConversion_BusinessUnitName(K)_MonthEndDate(K)");

                entity.ToTable("CashConversion", "Finance");

                entity.Property(e => e.BusinessUnitName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WorkingCapital).HasColumnType("decimal(18, 4)");
            });

            modelBuilder.Entity<CompletedOneToOneMeeting>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_CompletedOneToOneMeeting_Name(K)_FiscalStartYear(K)");

                entity.ToTable("CompletedOneToOneMeeting", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Aug)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Dec)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jan)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jul)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jun)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Mar)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.May)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Nov)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Oct)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Configuration>(entity =>
            {
                entity.ToTable("configuration", "dss");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ConfigKey)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ConfigValue)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.LastModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");
            });

            modelBuilder.Entity<Contract>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.Region })
                    .HasName("PK_SOPS_Contract_ContractId(K)_Region(K)");

                entity.ToTable("Contract", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FixedTerm)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Hosting)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.LegalEntity)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MarketType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.QuotationRef)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ScheduledPayment)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractLine>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.LineId, e.Region })
                    .HasName("PK_SOPS_ContractLine_ContractId(K)_LineID(K)_Region(K)");

                entity.ToTable("ContractLine", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Description)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MaintFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.ProductCatg)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ProductType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractLineAudit>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.LineId, e.AudIdx, e.Region })
                    .HasName("PK_SOPS_Contract_ContractId(K)_LineID(K)_AudIdx(K)_Region(K)");

                entity.ToTable("ContractLineAudit", "SOPS");

                entity.Property(e => e.ContractId).HasColumnName("ContractID");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.AudCost).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.AudDate).HasColumnType("datetime");

                entity.Property(e => e.AudMaintCost).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.AudMaintSale).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.AudQty).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.AudValue).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractRevenue>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.RevId, e.Region })
                    .HasName("PK_SOPS_ContractRevenue_ContractId(K)_RevId(K)_Region(K)");

                entity.ToTable("ContractRevenue", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RevCost).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.RevValue).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractRole>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.RoleId, e.EmployeeId, e.Region })
                    .HasName("PK_SOPS_ContractRole_ContractId(K)_RoleId(K)_EmployeeId(K)_Region(K)");

                entity.ToTable("ContractRole", "SOPS");

                entity.Property(e => e.RoleId)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractType>(entity =>
            {
                entity.ToTable("ContractType", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Correspondence>(entity =>
            {
                entity.HasKey(e => e.NoteId)
                    .HasName("PK_MarketPoint_Correspondence_NoteId(K)");

                entity.ToTable("Correspondence", "MarketPoint");

                entity.Property(e => e.NoteId).ValueGeneratedNever();

                entity.Property(e => e.Body).IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Company)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDateAndTime).HasColumnType("datetime");

                entity.Property(e => e.DateAndTime).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Division)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag")
                    .IsFixedLength();

                entity.Property(e => e.DocType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.RepEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SubDivision)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CostCentre>(entity =>
            {
                entity.ToTable("CostCentre", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Code).HasMaxLength(50);

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<Currency>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Currency", "Master");

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customer", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CustomerCode).HasMaxLength(20);

                entity.Property(e => e.CustomerName).HasMaxLength(100);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<Customer1>(entity =>
            {
                entity.HasKey(e => new { e.CustomerId, e.Region })
                    .HasName("PK_SOPS_Customer_CustomerId(K)_Region(K)");

                entity.ToTable("Customer", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<DebtorSummary>(entity =>
            {
                entity.HasKey(e => new { e.T7code, e.MonthEndDate })
                    .HasName("PK_DSO_DebtorSummary_T7Code(K)_MonthEndDate(K)");

                entity.ToTable("DebtorSummary", "DSO");

                entity.Property(e => e.T7code)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDebtorAmount).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DeliveryCompliantProject>(entity =>
            {
                entity.HasKey(e => new { e.MonthEndDate, e.ProjectCode })
                    .HasName("PK_PPM_DeliveryCompliantProject_Multiplekeys");

                entity.ToTable("DeliveryCompliantProject", "PPM");

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.ProjectCode)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryCompliance)
                    .IsRequired()
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DimCostCentre>(entity =>
            {
                entity.HasKey(e => e.CostCentreKey)
                    .HasName("PK_FABS_DimCostCentre_CostCentreKey(K)");

                entity.ToTable("DimCostCentre", "FABS");

                entity.Property(e => e.CostCentreKey).ValueGeneratedNever();

                entity.Property(e => e.AlternateKey)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.T3costCentre)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("T3CostCentre");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DimDepartment>(entity =>
            {
                entity.HasKey(e => e.DepartmentKey)
                    .HasName("PK_FABS_DimDepartment_DepartmentKey(K)");

                entity.ToTable("DimDepartment", "FABS");

                entity.Property(e => e.DepartmentKey).ValueGeneratedNever();

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.DepartmentName).HasMaxLength(250);

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DimOrganisationalUnit>(entity =>
            {
                entity.HasKey(e => e.OrganisationalUnitKey)
                    .HasName("PK_FABS_DimOrganisationalUnit_OrganisationalUnitKey(K)");

                entity.ToTable("DimOrganisationalUnit", "FABS");

                entity.Property(e => e.OrganisationalUnitKey).ValueGeneratedNever();

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.OrganisationalUnitCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrganisationalUnitName)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.OrganisationalUnitType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DimPeriod>(entity =>
            {
                entity.HasKey(e => e.PeriodKey)
                    .HasName("PK_FABS_DimPeriod_PeriodKey(K)");

                entity.ToTable("DimPeriod", "FABS");

                entity.Property(e => e.PeriodKey).ValueGeneratedNever();

                entity.Property(e => e.CalendarYyyymm).HasColumnName("CalendarYYYYMM");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FinancialYyyymm).HasColumnName("FinancialYYYYMM");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.QuarterName)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DimSalesContractType>(entity =>
            {
                entity.HasKey(e => e.SalesContractTypeKey)
                    .HasName("PK_FABS_SalesContractType_SalesContractTypeKey(K)");

                entity.ToTable("DimSalesContractType", "FABS");

                entity.Property(e => e.SalesContractTypeKey).ValueGeneratedNever();

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SalesContractTypeDescription)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DivisionBusinessUnit>(entity =>
            {
                entity.HasKey(e => new { e.Bucode, e.Region })
                    .HasName("PK_SOPS_DivisionBusinessUnit_BUCode(K)_Region(K)");

                entity.ToTable("DivisionBusinessUnit", "SOPS");

                entity.Property(e => e.Bucode)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BUCode");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.AccCode)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MarketType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PurPeriod)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.T0code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T0Code");

                entity.Property(e => e.T7code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<EnumType>(entity =>
            {
                entity.ToTable("EnumType", "dss");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.LastModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FabsdimOrganisationalUnit>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FABSDimOrganisationalUnit", "Report");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.OrganisationalUnitCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrganisationalUnitName)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.OrganisationalUnitType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FabsfactCapDevCost>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FABSFactCapDevCost", "Report");

                entity.Property(e => e.CapDevCostsKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FabsfactEmployeeHeadcount>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FABSFactEmployeeHeadcount", "Report");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmployeeHeadcountKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FabsfactEmploymentCost>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FABSFactEmploymentCost", "Report");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmploymentCostKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FabsfactSalesRevenue>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FABSFactSalesRevenue", "Report");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.RevenueType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SalesRevenueKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Source)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FactCapDevCost>(entity =>
            {
                entity.HasKey(e => new { e.Source, e.PeriodKey, e.OrganisationalUnitKey, e.ValueType, e.PeriodForecasted })
                    .HasName("PK_FABS_FactCapDevCost_Multiplekeys");

                entity.ToTable("FactCapDevCost", "FABS");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CapDevCostsKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyIso)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("CurrencyISO");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Value).HasColumnType("decimal(10, 2)");
            });

            modelBuilder.Entity<FactEmployeeHeadcount>(entity =>
            {
                entity.HasKey(e => new { e.Source, e.OrganisationalUnitKey, e.DepartmentKey, e.PeriodKey, e.ValueType, e.PeriodForecasted })
                    .HasName("PK_FABS_FactEmployeeHeadcount_MultipleKey(K)");

                entity.ToTable("FactEmployeeHeadcount", "FABS");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmployeeHeadcountKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HeadCount).HasColumnType("decimal(6, 0)");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FactEmploymentCost>(entity =>
            {
                entity.HasKey(e => new { e.Source, e.OrganisationalUnitKey, e.DepartmentKey, e.PeriodKey, e.ValueType, e.PeriodForecasted });

                entity.ToTable("FactEmploymentCost", "FABS");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CurrencyIso)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("CurrencyISO");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmploymentCostKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Value).HasColumnType("decimal(10, 2)");
            });

            modelBuilder.Entity<FactSalesRevenue>(entity =>
            {
                entity.HasKey(e => new { e.Source, e.PeriodKey, e.OrganisationalUnitKey, e.SalesContractTypeKey, e.ValueType, e.RevenueType, e.PeriodForecasted })
                    .HasName("PK_FABS_FactSalesRevenue");

                entity.ToTable("FactSalesRevenue", "FABS");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RevenueType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyIso)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("CurrencyISO");

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SalesRevenueKey)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Value).HasColumnType("decimal(10, 2)");
            });

            modelBuilder.Entity<ForecastDetail>(entity =>
            {
                entity.ToTable("ForecastDetail", "Proact");

                entity.Property(e => e.ForecastDetailId).ValueGeneratedNever();

                entity.Property(e => e.CurrentMonthName).HasMaxLength(10);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ForecastCharge).HasColumnType("decimal(9, 2)");

                entity.Property(e => e.ForecastCost).HasColumnType("decimal(9, 2)");

                entity.Property(e => e.ForecastDays).HasColumnType("decimal(9, 2)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ForecastMonth>(entity =>
            {
                entity.ToTable("ForecastMonth", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ForecastRag>(entity =>
            {
                entity.ToTable("ForecastRAG", "Proact");

                entity.Property(e => e.ForecastRagid)
                    .ValueGeneratedNever()
                    .HasColumnName("ForecastRAGId");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RagtypeId).HasColumnName("RAGTypeId");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ForecastRagtype>(entity =>
            {
                entity.ToTable("ForecastRAGType", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<ForecastSummary>(entity =>
            {
                entity.ToTable("ForecastSummary", "Proact");

                entity.Property(e => e.ForecastSummaryId).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PublishedDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WorkLeftToDo).HasColumnType("decimal(12, 2)");
            });

            modelBuilder.Entity<IgminMonth>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_IGMInMonth_Name(K)_FiscalStartYear(K)");

                entity.ToTable("IGMInMonth", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<IgmyearToGo>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_IGMYearToGo_Name(K)_FiscalStartYear(K)");

                entity.ToTable("IGMYearToGo", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Iprrevenue>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_IPRRevenue_Name(K)_FiscalStartYear(K)");

                entity.ToTable("IPRRevenue", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Job>(entity =>
            {
                entity.ToTable("Job", "TaskHosting");

                entity.HasIndex(e => e.IsCancelled, "index_job_iscancelled");

                entity.Property(e => e.JobId).HasDefaultValueSql("(newid())");

                entity.Property(e => e.InitialInsertTimeUtc)
                    .HasColumnType("datetime")
                    .HasColumnName("InitialInsertTimeUTC")
                    .HasDefaultValueSql("(getutcdate())");
            });

            modelBuilder.Entity<Lead>(entity =>
            {
                entity.HasKey(e => e.EnquiryId)
                    .HasName("PK_MarketPoint_Leads_EnquiryId(K)");

                entity.ToTable("Leads", "MarketPoint");

                entity.Property(e => e.EnquiryId).ValueGeneratedNever();

                entity.Property(e => e.AccountType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.ChanceOfClose).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Currency)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DatabaseProvider)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag")
                    .IsFixedLength();

                entity.Property(e => e.Estclosedate).HasColumnType("date");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Hardware).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.HardwareMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.LeadCreateDate).HasColumnType("date");

                entity.Property(e => e.LeadIssueDate).HasColumnType("date");

                entity.Property(e => e.LossReason)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MediaName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Method)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Nextcontact).HasColumnType("datetime");

                entity.Property(e => e.OwnServices).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.OwnServicesMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.OwnSoftware).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.OwnSoftwareMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.ProcurementMethodName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductDesc)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RepEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ResignedReplaceAmount).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ResignedReplaceAmountMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ResultName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SaleType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SolutionsArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SubdivisionName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupportNew).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SupportNewMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SupportReSigned).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SupportReSignedMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.TerritoryName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ThirdPartyServices).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ThirdPartyServicesMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ThirdPartySoftware).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ThirdPartySoftwareMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.TotalMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.TotalRevenue).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.UpdateDate).HasColumnType("date");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LegalEntity>(entity =>
            {
                entity.ToTable("LegalEntity", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Label)
                    .IsRequired()
                    .HasMaxLength(4);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<MaintenanceSupportRevenue>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_MaintenanceSupportRevenue_Name(K)_FiscalStartYear(K)");

                entity.ToTable("MaintenanceSupportRevenue", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ManagedServiceRevenue>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_ManagedServiceRevenue_Name(K)_FiscalStartYear(K)");

                entity.ToTable("ManagedServiceRevenue", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MasterBusinessUnit>(entity =>
            {
                entity.HasKey(e => e.BusinessUnitMdmid)
                    .HasName("PK_MDM_MasterBusinessUnit_BusinessUnitMDMID(K)");

                entity.ToTable("MasterBusinessUnit", "MDM");

                entity.ToTable(tb => tb.IsTemporal(ttb =>
    {
        ttb.UseHistoryTable("MasterBusinessUnitHistory", "MDM");
        ttb
            .HasPeriodStart("EffectiveFromDate")
            .HasColumnName("EffectiveFromDate");
        ttb
            .HasPeriodEnd("EffectiveToDate")
            .HasColumnName("EffectiveToDate");
    }
));

                entity.HasIndex(e => new { e.Bucode, e.Region }, "UQ_MDM_MasterBusinessUnit_BUCode(K)_Region(K)")
                    .IsUnique();

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMID");

                entity.Property(e => e.Bucode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BUCode");

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.T7code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");
            });

            modelBuilder.Entity<MasterPerson>(entity =>
            {
                entity.HasKey(e => e.PersonMdmid)
                    .HasName("PK_MDM_MasterPerson_PersonMDMID(K)");

                entity.ToTable("MasterPerson", "MDM");

                entity.ToTable(tb => tb.IsTemporal(ttb =>
    {
        ttb.UseHistoryTable("MasterPersonHistory", "MDM");
        ttb
            .HasPeriodStart("EffectiveFromDate")
            .HasColumnName("EffectiveFromDate");
        ttb
            .HasPeriodEnd("EffectiveToDate")
            .HasColumnName("EffectiveToDate");
    }
));

                entity.HasIndex(e => e.EmployeeId, "UQ_MDM_MasterPerson_EmployeeID(K)")
                    .IsUnique();

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMID");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMID");

                entity.Property(e => e.BusinessUnitName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CostCentre)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.EmployeeId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Qcsp)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("QCSP");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MessageQueue>(entity =>
            {
                entity.HasKey(e => e.MessageId)
                    .HasName("PK__MessageQ__C87C0C9C4C947FAF");

                entity.ToTable("MessageQueue", "TaskHosting");

                entity.HasIndex(e => new { e.QueueId, e.UpdateTimeUtc, e.InsertTimeUtc, e.ExecTimes, e.Version }, "index_messagequeue_getnextmessage");

                entity.HasIndex(e => new { e.QueueId, e.MessageType, e.UpdateTimeUtc, e.InsertTimeUtc, e.ExecTimes, e.Version }, "index_messagequeue_getnextmessagebytype");

                entity.HasIndex(e => e.JobId, "index_messagequeue_jobid");

                entity.Property(e => e.MessageId).HasDefaultValueSql("(newid())");

                entity.Property(e => e.InitialInsertTimeUtc)
                    .HasColumnType("datetime")
                    .HasColumnName("InitialInsertTimeUTC")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InsertTimeUtc)
                    .HasColumnType("datetime")
                    .HasColumnName("InsertTimeUTC");

                entity.Property(e => e.UpdateTimeUtc)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdateTimeUTC");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.MessageQueues)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("FK__MessageQu__JobId__235DBD20");
            });

            modelBuilder.Entity<MetaInformation>(entity =>
            {
                entity.ToTable("MetaInformation", "dss");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.VersionString)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('1.0.0.0')");
            });

            modelBuilder.Entity<MetaInformation1>(entity =>
            {
                entity.ToTable("MetaInformation", "TaskHosting");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.VersionString)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('1.0.0.0')");
            });

            modelBuilder.Entity<MonthlyTeamMeetingCompleted>(entity =>
            {
                entity.HasKey(e => new { e.BusinessUnitName, e.FiscalStartYear })
                    .HasName("PK_SalesFile_MonthlyTeamMeetingCompleted_BusinessUnitName(K)_FiscalStartYear(K)");

                entity.ToTable("MonthlyTeamMeetingCompleted", "SalesFile");

                entity.Property(e => e.BusinessUnitName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Apr)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Aug)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Dec)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jan)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jul)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Jun)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Mar)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.May)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Nov)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Oct)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Sep)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Movement>(entity =>
            {
                entity.HasKey(e => new { e.T7code, e.MonthEndDate })
                    .HasName("PK_QueryDebt_Movement_T7Code(K)_MonthEndDate(K)");

                entity.ToTable("Movement", "QueryDebt");

                entity.Property(e => e.T7code)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TotalQueryDebtAmount).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NonUkbusinessUnit>(entity =>
            {
                entity.HasKey(e => e.Bucode)
                    .HasName("PK_SOPS_NonUKBusinessUnit_BUCode(K)");

                entity.ToTable("NonUKBusinessUnit", "SOPS");

                entity.Property(e => e.Bucode)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BUCode");

                entity.Property(e => e.AccCode)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MarketType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PurPeriod)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('SOPS UK NonUKBusinessUnit')");

                entity.Property(e => e.T0code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T0Code");

                entity.Property(e => e.T7code)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ObservedMeeting>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_ObservedMeeting_Name(K)_FiscalStartYear(K)");

                entity.ToTable("ObservedMeeting", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PeriodEnd>(entity =>
            {
                entity.HasKey(e => new { e.YearNo, e.PeriodNo, e.Region })
                    .HasName("PK_SOPS_PeriodEnd_YearNo(K)_PeriodNo(K)_Region(K)");

                entity.ToTable("PeriodEnd", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PeriodEndDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<PeriodForecastingPeriod>(entity =>
            {
                entity.HasKey(e => new { e.Source, e.PeriodKey, e.ValueType })
                    .HasName("PK_FABS_PeriodForecastingPeriod_Source(K)_PeriodKey(K)_ValueType(K)");

                entity.ToTable("PeriodForecastingPeriod", "FABS");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ValueType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateInserted).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag")
                    .IsFixedLength();

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.EmployeeId)
                    .HasName("PK_HR_Person_EmployeeID(K)");

                entity.ToTable("Person", "HR");

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.CostCentre)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Division)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag")
                    .IsFixedLength();

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EmploymentEndDate).HasColumnType("date");

                entity.Property(e => e.EmploymentStartDate).HasColumnType("date");

                entity.Property(e => e.EmploymentStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LegacyCode)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Location)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Manager)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Qcspcode)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("QCSPCode");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WorkEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PersonLookup>(entity =>
            {
                entity.ToTable("PersonLookup", "MDM");

                entity.Property(e => e.PersonLookupId).HasColumnName("PersonLookupID");

                entity.Property(e => e.BusinessUnitName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CostCentre)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMID");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.RunId).HasColumnName("RunID");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.Property(e => e.WorkflowStatusId).HasColumnName("WorkflowStatusID");

                entity.HasOne(d => d.WorkflowStatus)
                    .WithMany(p => p.PersonLookups)
                    .HasForeignKey(d => d.WorkflowStatusId)
                    .HasConstraintName("FK_MDM_PersonLookup_WorkflowStatusID(K)");
            });

            modelBuilder.Entity<PersonalForecastNonRecurringRevenue>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_PersonalForecastNonRecurringRevenue_Name(K)_FiscalStartYear(K)");

                entity.ToTable("PersonalForecastNonRecurringRevenue", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactAllocationPeriod>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactAllocationPeriod", "Report");

                entity.Property(e => e.DaysEffort).HasColumnType("decimal(10, 4)");

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProactBusinessUnit>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactBusinessUnit", "Report");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.WorkingTime).HasColumnType("decimal(4, 2)");
            });

            modelBuilder.Entity<ProactCostCentre>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactCostCentre", "Report");

                entity.Property(e => e.Code).HasMaxLength(50);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactCustomer", "Report");

                entity.Property(e => e.CustomerCode).HasMaxLength(20);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactForecastMonth>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactForecastMonth", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactForecastRagtype>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactForecastRAGType", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactForecastSummary>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactForecastSummary", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactLegalEntity>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactLegalEntity", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.Label)
                    .IsRequired()
                    .HasMaxLength(4);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactProject>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactProject", "Report");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactProjectType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactProjectType", "Report");

                entity.Property(e => e.Code).HasMaxLength(20);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactSiteLogForecast>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactSiteLogForecast", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProactTimesheetPeriod>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ProactTimesheetPeriod", "Report");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProfessionalServiceRevenue>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_ProfessionalServiceRevenue_Name(K)_FiscalStartYear(K)");

                entity.ToTable("ProfessionalServiceRevenue", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProfiledReport>(entity =>
            {
                entity.HasKey(e => new { e.BusinessUnit, e.SnapShotDate })
                    .HasName("PK_MarketPoint_ProfiledReport_BusinessUnit(K)_SnapShotDate(K)");

                entity.ToTable("ProfiledReport", "MarketPoint");

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SnapShotDate).HasColumnType("datetime");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag")
                    .IsFixedLength();

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalWeightedMargin).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Project>(entity =>
            {
                entity.ToTable("Project", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Bp4dcode)
                    .HasMaxLength(40)
                    .HasColumnName("BP4DCode");

                entity.Property(e => e.BudgetDays).HasColumnType("decimal(19, 2)");

                entity.Property(e => e.ClosedOn).HasColumnType("datetime");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(255);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SiteLogAnalysisCode2).HasMaxLength(20);

                entity.Property(e => e.Sopsid).HasColumnName("SOPSId");

                entity.Property(e => e.SopssystemId).HasColumnName("SOPSSystemId");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProjectInvoiceTemplate>(entity =>
            {
                entity.ToTable("ProjectInvoiceTemplate", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ContractHoursPerDay).HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProjectType>(entity =>
            {
                entity.ToTable("ProjectType", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Code).HasMaxLength(20);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProvisionMarkerDss>(entity =>
            {
                entity.HasKey(e => new { e.OwnerScopeLocalId, e.ObjectId })
                    .HasName("PK_DataSync.provision_marker_dss");

                entity.ToTable("provision_marker_dss", "DataSync");

                entity.Property(e => e.OwnerScopeLocalId).HasColumnName("owner_scope_local_id");

                entity.Property(e => e.ObjectId).HasColumnName("object_id");

                entity.Property(e => e.ProvisionDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("provision_datetime");

                entity.Property(e => e.ProvisionLocalPeerKey).HasColumnName("provision_local_peer_key");

                entity.Property(e => e.ProvisionScopeLocalId).HasColumnName("provision_scope_local_id");

                entity.Property(e => e.ProvisionScopePeerKey).HasColumnName("provision_scope_peer_key");

                entity.Property(e => e.ProvisionScopePeerTimestamp).HasColumnName("provision_scope_peer_timestamp");

                entity.Property(e => e.ProvisionTimestamp).HasColumnName("provision_timestamp");

                entity.Property(e => e.State).HasColumnName("state");

                entity.Property(e => e.Version)
                    .IsRequired()
                    .IsRowVersion()
                    .IsConcurrencyToken()
                    .HasColumnName("version");
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Resource", "Centum");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CostCentreCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CostCentreName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmployeeNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FromDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.T7code)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("T7Code");

                entity.Property(e => e.ToDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Resource1>(entity =>
            {
                entity.ToTable("Resource", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EmployeeNumber)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RunStatus>(entity =>
            {
                entity.ToTable("RunStatus", "MDM");

                entity.Property(e => e.RunStatusId).HasColumnName("RunStatusID");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SalesCompliantProject>(entity =>
            {
                entity.HasKey(e => new { e.MonthEndDate, e.ProjectCode })
                    .HasName("PK_PPM_SalesCompliantProject_Multiplekeys");

                entity.ToTable("SalesCompliantProject", "PPM");

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.ProjectCode)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SalesCompliance)
                    .IsRequired()
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SalesDirectorForecast>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.MonthEndDate })
                    .HasName("PK_SalesFile_SalesDirectorForecast_Name(K)_MonthEndDate(K)");

                entity.ToTable("SalesDirectorForecast", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MonthEndDate).HasColumnType("date");

                entity.Property(e => e.BusinessUnitMdmid).HasColumnName("BusinessUnitMDMId");

                entity.Property(e => e.BusinessUnitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CurrencyCode)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Role)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SalesDirectorForecast1)
                    .HasColumnType("decimal(18, 4)")
                    .HasColumnName("SalesDirectorForecast");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Scaleunitlimit>(entity =>
            {
                entity.ToTable("scaleunitlimits", "dss");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.LastModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Schedule>(entity =>
            {
                entity.ToTable("Schedule", "TaskHosting");
            });

            modelBuilder.Entity<ScheduleTask>(entity =>
            {
                entity.HasKey(e => e.SyncGroupId);

                entity.ToTable("ScheduleTask", "dss");

                entity.Property(e => e.SyncGroupId).ValueGeneratedNever();

                entity.Property(e => e.ExpirationTime).HasColumnType("datetime");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.LastUpdate).HasColumnType("datetime");

                entity.HasOne(d => d.SyncGroup)
                    .WithOne(p => p.ScheduleTask)
                    .HasForeignKey<ScheduleTask>(d => d.SyncGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ScheduleT__SyncG");
            });

            modelBuilder.Entity<ScheduleTask1>(entity =>
            {
                entity.HasKey(e => e.ScheduleTaskId)
                    .HasName("PK__Schedule__8DAD173ADC264E33");

                entity.ToTable("ScheduleTask", "TaskHosting");

                entity.HasIndex(e => e.MessageId, "ScheduleTask_MessageId_Index");

                entity.Property(e => e.ScheduleTaskId).ValueGeneratedNever();

                entity.Property(e => e.NextRunTime).HasColumnType("datetime");

                entity.Property(e => e.TaskName)
                    .IsRequired()
                    .HasMaxLength(128);

                entity.HasOne(d => d.ScheduleNavigation)
                    .WithMany(p => p.ScheduleTask1s)
                    .HasForeignKey(d => d.Schedule)
                    .HasConstraintName("FK__ScheduleT__Sched__2DDB4B93");
            });

            modelBuilder.Entity<SchemaInfoDss>(entity =>
            {
                entity.HasKey(e => new { e.SchemaMajorVersion, e.SchemaMinorVersion })
                    .HasName("PK_DataSync.schema_info_dss");

                entity.ToTable("schema_info_dss", "DataSync");

                entity.Property(e => e.SchemaMajorVersion).HasColumnName("schema_major_version");

                entity.Property(e => e.SchemaMinorVersion).HasColumnName("schema_minor_version");

                entity.Property(e => e.SchemaExtendedInfo)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("schema_extended_info");
            });

            modelBuilder.Entity<ScopeConfigDss>(entity =>
            {
                entity.HasKey(e => e.ConfigId)
                    .HasName("PK_DataSync.scope_config_dss");

                entity.ToTable("scope_config_dss", "DataSync");

                entity.Property(e => e.ConfigId)
                    .ValueGeneratedNever()
                    .HasColumnName("config_id");

                entity.Property(e => e.ConfigData)
                    .IsRequired()
                    .HasColumnType("xml")
                    .HasColumnName("config_data");

                entity.Property(e => e.ScopeStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("scope_status")
                    .IsFixedLength();
            });

            modelBuilder.Entity<ScopeInfoDss>(entity =>
            {
                entity.HasKey(e => e.SyncScopeName)
                    .HasName("PK_DataSync.scope_info_dss");

                entity.ToTable("scope_info_dss", "DataSync");

                entity.Property(e => e.SyncScopeName)
                    .HasMaxLength(100)
                    .HasColumnName("sync_scope_name");

                entity.Property(e => e.ScopeConfigId).HasColumnName("scope_config_id");

                entity.Property(e => e.ScopeId)
                    .HasColumnName("scope_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.ScopeLocalId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("scope_local_id");

                entity.Property(e => e.ScopeRestoreCount).HasColumnName("scope_restore_count");

                entity.Property(e => e.ScopeSyncKnowledge).HasColumnName("scope_sync_knowledge");

                entity.Property(e => e.ScopeTimestamp)
                    .IsRowVersion()
                    .IsConcurrencyToken()
                    .HasColumnName("scope_timestamp");

                entity.Property(e => e.ScopeTombstoneCleanupKnowledge).HasColumnName("scope_tombstone_cleanup_knowledge");

                entity.Property(e => e.ScopeUserComment).HasColumnName("scope_user_comment");
            });

            modelBuilder.Entity<SiteLogForecast>(entity =>
            {
                entity.ToTable("SiteLogForecast", "Proact");

                entity.Property(e => e.SiteLogForecastId).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SiteLogUpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.WorkLeftToDo).HasColumnType("decimal(12, 2)");
            });

            modelBuilder.Entity<SiteLogForecastDetail>(entity =>
            {
                entity.ToTable("SiteLogForecastDetail", "Proact");

                entity.Property(e => e.SiteLogForecastDetailId).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ForecastDays).HasColumnType("decimal(9, 2)");

                entity.Property(e => e.SiteLogUpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SiteLogProject>(entity =>
            {
                entity.ToTable("SiteLogProject", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SiteLogUpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Sopscontract>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("SOPSContract", "Report");

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SopscontractLine>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("SOPSContractLine", "Report");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Sopscustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("SOPSCustomer", "Report");

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Sopsuser>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("SOPSUser", "Report");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate).HasColumnType("datetime");

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Source>(entity =>
            {
                entity.ToTable("Source", "MDM");

                entity.Property(e => e.SourceId).HasColumnName("SourceID");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ModifiedDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Subscription>(entity =>
            {
                entity.ToTable("subscription", "dss");

                entity.HasIndex(e => e.Syncserveruniquename, "IX_SyncServerUniqueName")
                    .IsUnique()
                    .HasFilter("([syncserveruniquename] IS NOT NULL)");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Creationtime)
                    .HasColumnType("datetime")
                    .HasColumnName("creationtime");

                entity.Property(e => e.EnableDetailedProviderTracing).HasDefaultValueSql("((0))");

                entity.Property(e => e.Lastlogintime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastlogintime");

                entity.Property(e => e.Name)
                    .HasMaxLength(140)
                    .HasColumnName("name");

                entity.Property(e => e.Policyid)
                    .HasColumnName("policyid")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Subscriptionstate).HasColumnName("subscriptionstate");

                entity.Property(e => e.Syncserveruniquename)
                    .HasMaxLength(256)
                    .HasColumnName("syncserveruniquename");

                entity.Property(e => e.Tombstoneretentionperiodindays).HasColumnName("tombstoneretentionperiodindays");

                entity.Property(e => e.Version)
                    .HasMaxLength(40)
                    .HasColumnName("version");
            });

            modelBuilder.Entity<SyncObjectDatum>(entity =>
            {
                entity.HasKey(e => new { e.ObjectId, e.DataType })
                    .HasName("PK_SyncObjectExtInfo");

                entity.ToTable("SyncObjectData", "dss");

                entity.Property(e => e.CreatedTime).HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastModified)
                    .IsRequired()
                    .IsRowVersion()
                    .IsConcurrencyToken();

                entity.Property(e => e.ObjectData).IsRequired();
            });

            modelBuilder.Entity<Syncgroup>(entity =>
            {
                entity.ToTable("syncgroup", "dss");

                entity.HasIndex(e => e.HubMemberid, "index_syncgroup_hub_memberid");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.ConflictResolutionPolicy).HasColumnName("conflict_resolution_policy");

                entity.Property(e => e.ConflictTableRetentionInDays).HasDefaultValueSql("((30))");

                entity.Property(e => e.HubMemberid).HasColumnName("hub_memberid");

                entity.Property(e => e.Hubhasdata).HasColumnName("hubhasdata");

                entity.Property(e => e.Lastupdatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastupdatetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(140)
                    .HasColumnName("name");

                entity.Property(e => e.Ocsschemadefinition).HasColumnName("ocsschemadefinition");

                entity.Property(e => e.SchemaDescription)
                    .HasColumnType("xml")
                    .HasColumnName("schema_description");

                entity.Property(e => e.State)
                    .HasColumnName("state")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Subscriptionid).HasColumnName("subscriptionid");

                entity.Property(e => e.SyncEnabled)
                    .IsRequired()
                    .HasColumnName("sync_enabled")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.SyncInterval).HasColumnName("sync_interval");

                entity.HasOne(d => d.HubMember)
                    .WithMany(p => p.Syncgroups)
                    .HasForeignKey(d => d.HubMemberid)
                    .HasConstraintName("FK__syncgroup__hub_m");

                entity.HasOne(d => d.Subscription)
                    .WithMany(p => p.Syncgroups)
                    .HasForeignKey(d => d.Subscriptionid)
                    .HasConstraintName("FK__syncgroup__subsc");
            });

            modelBuilder.Entity<Syncgroupmember>(entity =>
            {
                entity.ToTable("syncgroupmember", "dss");

                entity.HasIndex(e => new { e.Syncgroupid, e.Databaseid }, "IX_SyncGroupMember_SyncGroupId_DatabaseId")
                    .IsUnique();

                entity.HasIndex(e => e.Databaseid, "index_syncgroupmember_databaseid");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Databaseid).HasColumnName("databaseid");

                entity.Property(e => e.HubJobId).HasColumnName("hubJobId");

                entity.Property(e => e.Hubstate).HasColumnName("hubstate");

                entity.Property(e => e.HubstateLastupdated)
                    .HasColumnType("datetime")
                    .HasColumnName("hubstate_lastupdated")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.JobId).HasColumnName("jobId");

                entity.Property(e => e.Lastsynctime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastsynctime");

                entity.Property(e => e.LastsynctimeZerofailuresHub)
                    .HasColumnType("datetime")
                    .HasColumnName("lastsynctime_zerofailures_hub");

                entity.Property(e => e.LastsynctimeZerofailuresMember)
                    .HasColumnType("datetime")
                    .HasColumnName("lastsynctime_zerofailures_member");

                entity.Property(e => e.Memberhasdata).HasColumnName("memberhasdata");

                entity.Property(e => e.Memberstate).HasColumnName("memberstate");

                entity.Property(e => e.MemberstateLastupdated)
                    .HasColumnType("datetime")
                    .HasColumnName("memberstate_lastupdated")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(140)
                    .HasColumnName("name");

                entity.Property(e => e.Noinitsync).HasColumnName("noinitsync");

                entity.Property(e => e.Scopename)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("scopename")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Syncdirection).HasColumnName("syncdirection");

                entity.Property(e => e.Syncgroupid).HasColumnName("syncgroupid");

                entity.HasOne(d => d.Database)
                    .WithMany(p => p.Syncgroupmembers)
                    .HasForeignKey(d => d.Databaseid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__syncmember__datab");

                entity.HasOne(d => d.Syncgroup)
                    .WithMany(p => p.Syncgroupmembers)
                    .HasForeignKey(d => d.Syncgroupid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__syncmember__syncg");
            });

            modelBuilder.Entity<Task>(entity =>
            {
                entity.ToTable("task", "dss");

                entity.HasIndex(e => e.Actionid, "index_task_actionid");

                entity.HasIndex(e => new { e.Agentid, e.State }, "index_task_agentid_state")
                    .HasFilter("([state]=(0))");

                entity.HasIndex(e => e.Completedtime, "index_task_completedtime");

                entity.HasIndex(e => new { e.State, e.Agentid, e.DependencyCount, e.Priority, e.Creationtime }, "index_task_gettask");

                entity.HasIndex(e => new { e.State, e.Completedtime }, "index_task_state")
                    .HasFilter("([state]=(2))");

                entity.HasIndex(e => new { e.Lastheartbeat, e.State }, "index_task_state_lastheartbeat")
                    .HasFilter("([state]<(0))");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Actionid).HasColumnName("actionid");

                entity.Property(e => e.Agentid).HasColumnName("agentid");

                entity.Property(e => e.Completedtime)
                    .HasColumnType("datetime")
                    .HasColumnName("completedtime");

                entity.Property(e => e.Creationtime)
                    .HasColumnType("datetime")
                    .HasColumnName("creationtime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.DependencyCount).HasColumnName("dependency_count");

                entity.Property(e => e.Lastheartbeat)
                    .HasColumnType("datetime")
                    .HasColumnName("lastheartbeat");

                entity.Property(e => e.Lastresettime)
                    .HasColumnType("datetime")
                    .HasColumnName("lastresettime");

                entity.Property(e => e.OwningInstanceid).HasColumnName("owning_instanceid");

                entity.Property(e => e.Pickuptime)
                    .HasColumnType("datetime")
                    .HasColumnName("pickuptime");

                entity.Property(e => e.Priority)
                    .HasColumnName("priority")
                    .HasDefaultValueSql("((100))");

                entity.Property(e => e.Request).HasColumnName("request");

                entity.Property(e => e.Response).HasColumnName("response");

                entity.Property(e => e.RetryCount).HasColumnName("retry_count");

                entity.Property(e => e.State)
                    .HasColumnName("state")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TaskNumber)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("taskNumber");

                entity.Property(e => e.Type).HasColumnName("type");

                entity.Property(e => e.Version).HasColumnName("version");

                entity.HasOne(d => d.Action)
                    .WithMany(p => p.Tasks)
                    .HasForeignKey(d => d.Actionid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__task__actionid");

                entity.HasMany(d => d.Nexttasks)
                    .WithMany(p => p.Prevtasks)
                    .UsingEntity<Dictionary<string, object>>(
                        "Taskdependency",
                        l => l.HasOne<Task>().WithMany().HasForeignKey("Nexttaskid").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__taskdepen__nextt"),
                        r => r.HasOne<Task>().WithMany().HasForeignKey("Prevtaskid").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__taskdepen__prevt"),
                        j =>
                        {
                            j.HasKey("Nexttaskid", "Prevtaskid").HasName("PK_TaskTask");

                            j.ToTable("taskdependency", "dss");

                            j.IndexerProperty<Guid>("Nexttaskid").HasColumnName("nexttaskid");

                            j.IndexerProperty<Guid>("Prevtaskid").HasColumnName("prevtaskid");
                        });

                entity.HasMany(d => d.Prevtasks)
                    .WithMany(p => p.Nexttasks)
                    .UsingEntity<Dictionary<string, object>>(
                        "Taskdependency",
                        l => l.HasOne<Task>().WithMany().HasForeignKey("Prevtaskid").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__taskdepen__prevt"),
                        r => r.HasOne<Task>().WithMany().HasForeignKey("Nexttaskid").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__taskdepen__nextt"),
                        j =>
                        {
                            j.HasKey("Nexttaskid", "Prevtaskid").HasName("PK_TaskTask");

                            j.ToTable("taskdependency", "dss");

                            j.IndexerProperty<Guid>("Nexttaskid").HasColumnName("nexttaskid");

                            j.IndexerProperty<Guid>("Prevtaskid").HasColumnName("prevtaskid");
                        });
            });

            modelBuilder.Entity<ThirdPartyServiceHardwareGm>(entity =>
            {
                entity.HasKey(e => new { e.Name, e.FiscalStartYear })
                    .HasName("PK_SalesFile_ThirdPartyServiceHardwareGM_Name(K)_FiscalStartYear(K)");

                entity.ToTable("ThirdPartyServiceHardwareGM", "SalesFile");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Apr).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Aug).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dec).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Feb).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jan).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jul).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Jun).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Mar).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.May).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Multiplier)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Nov).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.Oct).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Sep).HasColumnType("decimal(18, 4)");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TimesheetEntry>(entity =>
            {
                entity.ToTable("TimesheetEntry", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApprovedDate).HasColumnType("datetime");

                entity.Property(e => e.Date).HasColumnType("datetime");

                entity.Property(e => e.DeletedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Hours).HasColumnType("decimal(15, 4)");

                entity.Property(e => e.RejectedDate).HasColumnType("datetime");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TimesheetPeriod>(entity =>
            {
                entity.ToTable("TimesheetPeriod", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<TimesheetPeriodCutOff>(entity =>
            {
                entity.ToTable("TimesheetPeriodCutOff", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CutOffDate).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TimesheetSubmission>(entity =>
            {
                entity.ToTable("TimesheetSubmission", "Proact");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Uihistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("UIHistory", "dss");

                entity.HasIndex(e => e.Agentid, "Idx_UIHistory_AgentId");

                entity.HasIndex(e => e.CompletionTime, "Idx_UIHistory_CompletionTime");

                entity.HasIndex(e => e.Databaseid, "Idx_UIHistory_DatabaseId");

                entity.HasIndex(e => e.Id, "Idx_UIHistory_Id");

                entity.HasIndex(e => e.Serverid, "Idx_UIHistory_ServerId")
                    .IsClustered();

                entity.HasIndex(e => e.SyncgroupId, "Idx_UIHistory_SyncgroupId");

                entity.Property(e => e.Agentid).HasColumnName("agentid");

                entity.Property(e => e.CompletionTime).HasColumnName("completionTime");

                entity.Property(e => e.Databaseid).HasColumnName("databaseid");

                entity.Property(e => e.DetailEnumId)
                    .IsRequired()
                    .HasMaxLength(400)
                    .HasColumnName("detailEnumId");

                entity.Property(e => e.DetailStringParameters).HasColumnName("detailStringParameters");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.IsWritable)
                    .HasColumnName("isWritable")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RecordType).HasColumnName("recordType");

                entity.Property(e => e.Serverid).HasColumnName("serverid");

                entity.Property(e => e.SyncgroupId).HasColumnName("syncgroupId");

                entity.Property(e => e.TaskType).HasColumnName("taskType");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("User", "Master");

                entity.Property(e => e.Aademail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("AADEmail");

                entity.Property(e => e.EmployeeId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.EmploymentEndDate).HasColumnType("date");

                entity.Property(e => e.EmploymentStartDate).HasColumnType("date");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LineManagerPersonMdmid).HasColumnName("LineManagerPersonMDMId");

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.Qcspcode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("QCSPCode");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.WorkEmail)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<User1>(entity =>
            {
                entity.HasKey(e => new { e.EmployeeId, e.Region })
                    .HasName("PK_SOPS_User_EmployeeId(K)_Region(K)");

                entity.ToTable("User", "SOPS");

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PayrollId)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PersonMdmid).HasColumnName("PersonMDMId");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SunPersonId)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.UserAccount)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ValidationComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserCode>(entity =>
            {
                entity.HasKey(e => new { e.Prefix, e.Code, e.Region })
                    .HasName("PK_SOPS_UserCode_Prefix(K)_Code(K)_Region(K)");

                entity.ToTable("UserCode", "SOPS");

                entity.Property(e => e.Prefix)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Code)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Dmlflag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("DMLFlag");

                entity.Property(e => e.ExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SourceIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Userdatabase>(entity =>
            {
                entity.ToTable("userdatabase", "dss");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Agentid).HasColumnName("agentid");

                entity.Property(e => e.ConnectionString).HasColumnName("connection_string");

                entity.Property(e => e.Database)
                    .HasMaxLength(256)
                    .HasColumnName("database");

                entity.Property(e => e.DbSchema).HasColumnName("db_schema");

                entity.Property(e => e.IsOnPremise).HasColumnName("is_on_premise");

                entity.Property(e => e.JobId).HasColumnName("jobId");

                entity.Property(e => e.LastSchemaUpdated)
                    .HasColumnType("datetime")
                    .HasColumnName("last_schema_updated");

                entity.Property(e => e.LastTombstonecleanup)
                    .HasColumnType("datetime")
                    .HasColumnName("last_tombstonecleanup");

                entity.Property(e => e.Region)
                    .HasMaxLength(256)
                    .HasColumnName("region");

                entity.Property(e => e.Server)
                    .HasMaxLength(256)
                    .HasColumnName("server");

                entity.Property(e => e.SqlazureInfo)
                    .HasColumnType("xml")
                    .HasColumnName("sqlazure_info");

                entity.Property(e => e.State).HasColumnName("state");

                entity.Property(e => e.Subscriptionid).HasColumnName("subscriptionid");

                entity.HasOne(d => d.Subscription)
                    .WithMany(p => p.Userdatabases)
                    .HasForeignKey(d => d.Subscriptionid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__userdatab__subsc");
            });

            modelBuilder.Entity<WorkflowStatus>(entity =>
            {
                entity.ToTable("WorkflowStatus", "MDM");

                entity.Property(e => e.WorkflowStatusId).HasColumnName("WorkflowStatusID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ETLSourceSystemRegion>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ETLSourceSystemRegion", "Report");

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SourceSystem)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
