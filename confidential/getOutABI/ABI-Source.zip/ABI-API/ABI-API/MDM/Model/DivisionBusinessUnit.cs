﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class DivisionBusinessUnit
    {
        public string Bucode { get; set; }
        public string T0code { get; set; }
        public string T7code { get; set; }
        public string AccCode { get; set; }
        public string PurPeriod { get; set; }
        public string Division { get; set; }
        public string BusinessUnit { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string MarketType { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string ValidationComment { get; set; }
    }
}
