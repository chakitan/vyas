﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProactProject
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public int? BusinessUnitId { get; set; }
        public int CustomerId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DeletedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
    }
}
