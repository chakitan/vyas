﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class BusinessUnit
    {
        public int BusinessUnitId { get; set; }
        public int BusinessUnitMdmid { get; set; }
        public string Code { get; set; }
        public string Region { get; set; }
        public string Name { get; set; }
        public string DivisionName { get; set; }
        public string CurrencyCode { get; set; }
        public string Description { get; set; }
        public string Dmlflag { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDateTime { get; set; }
    }
}
