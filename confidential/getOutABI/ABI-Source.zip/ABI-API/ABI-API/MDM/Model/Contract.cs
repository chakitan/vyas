﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Contract
    {
        public int ContractId { get; set; }
        public string ContractRef { get; set; }
        public int? CustomerId { get; set; }
        public string Description { get; set; }
        public int? EndUserId { get; set; }
        public string FixedTerm { get; set; }
        public string Hosting { get; set; }
        public string LegalEntity { get; set; }
        public string MarketType { get; set; }
        public DateTime? OrderDate { get; set; }
        public string PaymentType { get; set; }
        public string QuotationRef { get; set; }
        public string ScheduledPayment { get; set; }
        public string Status { get; set; }
        public int? Term { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
