﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class PeriodForecastingPeriod
    {
        public string Source { get; set; }
        public int PeriodKey { get; set; }
        public string ValueType { get; set; }
        public int ForecastId { get; set; }
        public int ForecastingPeriodId { get; set; }
        public bool PeriodClosed { get; set; }
        public DateTime DateInserted { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string Dmlflag { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
