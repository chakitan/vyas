﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class User
    {
        public int UserId { get; set; }
        public int PersonMdmid { get; set; }
        public string EmployeeId { get; set; }
        public int BusinessUnitId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string WorkEmail { get; set; }
        public string Aademail { get; set; }
        public string Qcspcode { get; set; }
        public int? LineManagerPersonMdmid { get; set; }
        public int? WorkManagerUserId { get; set; }
        public DateTime EmploymentStartDate { get; set; }
        public DateTime? EmploymentEndDate { get; set; }
        public bool? SalePersonFlag { get; set; }
        public bool? QuotaFlag { get; set; }
        public bool SysAdmin { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDateTime { get; set; }
    }
}
