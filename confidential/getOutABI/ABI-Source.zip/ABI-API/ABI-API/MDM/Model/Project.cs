﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Project
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Bp4dcode { get; set; }
        public int? ParentProjectId { get; set; }
        public int? BusinessUnitId { get; set; }
        public int CustomerId { get; set; }
        public decimal? BudgetDays { get; set; }
        public string Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? ClosedOn { get; set; }
        public int? ResourceContainerBusinessUnitId { get; set; }
        public bool IsClosed { get; set; }
        public int? NumberOfDays { get; set; }
        public int? Sopsid { get; set; }
        public int? SopssystemId { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DeletedDateTime { get; set; }
        public int ProjectTypeId { get; set; }
        public int? ProjectInvoiceTemplateId { get; set; }
        public string SiteLogAnalysisCode2 { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
