﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Customer1
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
