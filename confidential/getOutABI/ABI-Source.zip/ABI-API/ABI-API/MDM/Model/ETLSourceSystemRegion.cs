﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Model
{
    /// <summary>
    /// Class for ETL source system 
    /// </summary>
    public partial class ETLSourceSystemRegion
    {
        public int SourceSystemRegionId { get; set; }
        public string SourceSystem { get; set; }
        public string Region { get; set; }
        public byte ExecutionOrder { get; set; }
        public bool IsActive { get; set; }
    }
}
