﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProfiledReport
    {
        public string BusinessUnit { get; set; }
        public DateTime SnapShotDate { get; set; }
        public string CurrencyCode { get; set; }
        public decimal TotalWeightedMargin { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string ValidationComment { get; set; }
    }
}
