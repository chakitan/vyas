﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class FabsfactCapDevCost
    {
        public string CapDevCostsKey { get; set; }
        public string Source { get; set; }
        public int PeriodKey { get; set; }
        public int OrganisationalUnitKey { get; set; }
        public string ValueType { get; set; }
        public int PeriodForecasted { get; set; }
        public DateTime DateInserted { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string Dmlflag { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
    }
}
