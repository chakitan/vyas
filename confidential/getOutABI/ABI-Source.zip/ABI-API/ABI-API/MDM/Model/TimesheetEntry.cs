﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class TimesheetEntry
    {
        public int Id { get; set; }
        public int? TimesheetSubmissionId { get; set; }
        public int ProjectId { get; set; }
        public int ResourceId { get; set; }
        public decimal Hours { get; set; }
        public DateTime Date { get; set; }
        public bool IsApproved { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public bool IsRejected { get; set; }
        public DateTime? RejectedDate { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DeletedDateTime { get; set; }
        public bool IsCorrection { get; set; }
        public int? IncorrectEntryId { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
