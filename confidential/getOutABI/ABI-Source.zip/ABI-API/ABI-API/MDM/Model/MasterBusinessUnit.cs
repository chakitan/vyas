﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class MasterBusinessUnit
    {
        public int BusinessUnitMdmid { get; set; }
        public string Name { get; set; }
        public string Division { get; set; }
        public string Bucode { get; set; }
        public string Region { get; set; }
        public string T7code { get; set; }
        public string SourceIdentifier { get; set; }
        public bool IsDeleted { get; set; }
        public string Remarks { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }
    }
}
