﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Correspondence
    {
        public int NoteId { get; set; }
        public int? EnquirerId { get; set; }
        public int? EnquiryId { get; set; }
        public string DocType { get; set; }
        public string Company { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Description { get; set; }
        public string Body { get; set; }
        public DateTime? DateAndTime { get; set; }
        public string Division { get; set; }
        public string SubDivision { get; set; }
        public DateTime? CreatedDateAndTime { get; set; }
        public string CreatedBy { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? PersonMdmid { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string RepEmail { get; set; }
        public string ValidationComment { get; set; }
    }
}
