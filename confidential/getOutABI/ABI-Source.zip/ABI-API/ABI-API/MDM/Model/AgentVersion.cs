﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class AgentVersion
    {
        public int Id { get; set; }
        public string Version { get; set; }
        public DateTime ExpiresOn { get; set; }
        public string Comment { get; set; }
    }
}
