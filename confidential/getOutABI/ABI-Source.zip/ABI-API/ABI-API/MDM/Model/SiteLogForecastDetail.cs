﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class SiteLogForecastDetail
    {
        public int SiteLogForecastDetailId { get; set; }
        public int SiteLogForecastId { get; set; }
        public int ForecastMonthId { get; set; }
        public decimal? ForecastDays { get; set; }
        public DateTime SiteLogUpdatedDateTime { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
