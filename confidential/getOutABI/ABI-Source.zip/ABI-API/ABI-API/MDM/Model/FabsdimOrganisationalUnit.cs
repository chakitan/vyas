﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class FabsdimOrganisationalUnit
    {
        public int OrganisationalUnitKey { get; set; }
        public string OrganisationalUnitName { get; set; }
        public string OrganisationalUnitCode { get; set; }
        public string OrganisationalUnitType { get; set; }
        public int? ParentOrganisationalUnitKey { get; set; }
        public DateTime DateInserted { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string Dmlflag { get; set; }
        public string Source { get; set; }
        public int AlternateKey { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? BusinessUnitMdmid { get; set; }
    }
}
