﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class SiteLogForecast
    {
        public int SiteLogForecastId { get; set; }
        public int ProjectId { get; set; }
        public int ForecastMonthId { get; set; }
        public decimal? WorkLeftToDo { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime SiteLogUpdatedDateTime { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
