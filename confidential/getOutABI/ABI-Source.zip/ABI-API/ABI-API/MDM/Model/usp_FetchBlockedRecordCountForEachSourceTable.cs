﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Model
{
    public partial class usp_FetchBlockedRecordCountForEachSourceTable
    {
        public string SchemaName { get; set; }
        public string TableName { get; set; }
        public int BlockedRecordCount { get; set; }
    }
}

