﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ForecastSummary
    {
        public int ForecastSummaryId { get; set; }
        public int ProjectId { get; set; }
        public int ForecastMonthId { get; set; }
        public decimal? WorkLeftToDo { get; set; }
        public bool IsPublished { get; set; }
        public DateTime? PublishedDateTime { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
