﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ContractLineAudit
    {
        public int ContractId { get; set; }
        public int LineId { get; set; }
        public int AudIdx { get; set; }
        public int? CustomerId { get; set; }
        public decimal? AudValue { get; set; }
        public decimal? AudMaintCost { get; set; }
        public decimal? AudMaintSale { get; set; }
        public decimal? AudCost { get; set; }
        public int? AudPeriod { get; set; }
        public decimal? AudQty { get; set; }
        public DateTime? AudDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
