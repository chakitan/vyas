﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ProactForecastSummary
    {
        public int ForecastSummaryId { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
    }
}
