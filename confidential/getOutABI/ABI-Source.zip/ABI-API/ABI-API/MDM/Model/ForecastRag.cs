﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ForecastRag
    {
        public int ForecastRagid { get; set; }
        public int Status { get; set; }
        public int RagtypeId { get; set; }
        public int ForecastSummaryId { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
