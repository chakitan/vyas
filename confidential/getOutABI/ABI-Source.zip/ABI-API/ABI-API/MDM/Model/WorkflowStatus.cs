﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Civica.ABI.MDM.API.Model
{
    public partial class WorkflowStatus
    {
        public WorkflowStatus()
        {
            BusinessUnitLookups = new HashSet<BusinessUnitLookup>();
            PersonLookups = new HashSet<PersonLookup>();
        }

        public int WorkflowStatusId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }
        [NotMapped]
        public virtual ICollection<BusinessUnitLookup> BusinessUnitLookups { get; set; }
        public virtual ICollection<PersonLookup> PersonLookups { get; set; }
    }
}
