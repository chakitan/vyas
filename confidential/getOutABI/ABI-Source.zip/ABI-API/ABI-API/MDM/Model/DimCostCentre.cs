﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class DimCostCentre
    {
        public int CostCentreKey { get; set; }
        public int OrganisationalUnitKey { get; set; }
        public int DepartmentKey { get; set; }
        public string T3costCentre { get; set; }
        public DateTime DateInserted { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string Dmlflag { get; set; }
        public string Source { get; set; }
        public string AlternateKey { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
