﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class CashConversion
    {
        public string BusinessUnitName { get; set; }
        public DateTime MonthEndDate { get; set; }
        public decimal? WorkingCapital { get; set; }
        public string CurrencyCode { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
