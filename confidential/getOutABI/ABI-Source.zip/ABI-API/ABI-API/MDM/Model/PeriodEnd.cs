﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class PeriodEnd
    {
        public int YearNo { get; set; }
        public int PeriodNo { get; set; }
        public DateTime? PeriodEndDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
