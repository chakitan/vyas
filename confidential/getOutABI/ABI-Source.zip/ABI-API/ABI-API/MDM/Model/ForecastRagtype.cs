﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class ForecastRagtype
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
    }
}
