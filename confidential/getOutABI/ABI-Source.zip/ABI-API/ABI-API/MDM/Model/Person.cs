﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class Person
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string EmploymentStatus { get; set; }
        public string JobTitle { get; set; }
        public string WorkEmail { get; set; }
        public DateTime? EmploymentStartDate { get; set; }
        public DateTime? EmploymentEndDate { get; set; }
        public string Qcspcode { get; set; }
        public string Manager { get; set; }
        public string Division { get; set; }
        public string BusinessUnit { get; set; }
        public string CostCentre { get; set; }
        public string LegacyCode { get; set; }
        public string Location { get; set; }
        public int? PersonMdmid { get; set; }
        public int? BusinessUnitMdmid { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public string ValidationComment { get; set; }
    }
}
