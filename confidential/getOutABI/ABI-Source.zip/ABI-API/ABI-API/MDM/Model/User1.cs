﻿using System;
using System.Collections.Generic;

namespace Civica.ABI.MDM.API.Model
{
    public partial class User1
    {
        public int EmployeeId { get; set; }
        public string UserAccount { get; set; }
        public string PayrollId { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string SunPersonId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string Region { get; set; }
        public string Dmlflag { get; set; }
        public bool ProcessedFlag { get; set; }
        public int? PersonMdmid { get; set; }
        public string ValidationComment { get; set; }
    }
}
