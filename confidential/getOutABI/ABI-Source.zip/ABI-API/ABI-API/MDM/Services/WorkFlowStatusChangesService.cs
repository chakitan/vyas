﻿using Civica.ABI.MDM.API.Services.Interface;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Data;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.ENUM;

namespace Civica.ABI.MDM.API.Services
{
    public class WorkFlowStatusChangesService : IWorkFlowStatusChangesService
    {
        private readonly ILogger<WorkFlowStatusChangesService> _logger;
        private readonly MDMDbContext _dbContext;

        public WorkFlowStatusChangesService(ILogger<WorkFlowStatusChangesService> log, MDMDbContext dbContext)
        {
            this._logger = log;
            this._dbContext = dbContext;
        }
        /// <summary>
        /// Update status as button click like : junk , match , no master  pass action name and update In database
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <param name="action"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public async Task<int> UpdateWorkFlowStatusByEntityName(int id, string type, string action,string name)
        {
            try
            {
                int WorkflowStatusId = _dbContext.WorkflowStatuses.Where(x => x.Name == action).Select(x => x.WorkflowStatusId).FirstOrDefault();
                if (type.ToLower() == MDMEnum.PageType.BU.ToString().ToLower())
                {
                    if (WorkflowStatusId > 0)
                    {
                        var BusinessUnitLookup = _dbContext.BusinessUnitLookups.Where(x => x.BusinessUnitLookupId == id).FirstOrDefault();
                        if (BusinessUnitLookup != null)
                        {
                            BusinessUnitLookup.WorkflowStatusId = WorkflowStatusId;
                            BusinessUnitLookup.ModifiedDateTime = DateTime.Now;
                            BusinessUnitLookup.ModifiedBy = name;
                            _dbContext.BusinessUnitLookups.Update(BusinessUnitLookup);
                            _dbContext.SaveChanges();
                            return BusinessUnitLookup.BusinessUnitLookupId;
                        }
                        else
                        {
                            return 0;
                        }
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (WorkflowStatusId > 0)
                    {
                        var PersonLookups = _dbContext.PersonLookups.Where(x => x.PersonLookupId == id).FirstOrDefault();
                        if (PersonLookups != null)
                        {
                            PersonLookups.WorkflowStatusId = WorkflowStatusId;
                            PersonLookups.ModifiedDateTime = DateTime.Now;
                            PersonLookups.ModifiedBy = name;
                            _dbContext.PersonLookups.Update(PersonLookups);
                            _dbContext.SaveChanges();
                            return PersonLookups.PersonLookupId;
                        }
                        else
                        {
                            return 0;
                        }
                    }
                    else
                    {
                        return 0;
                    }
                }

            }
            catch (Exception ex)
            {
                 _logger.LogError(ex.ToString());
                throw;
            }
        }
        /// <summary>
        /// MDM > MDM Person/Business Unit Data Set :- on grid dropdown selected value update in database with status waiting for match approval
        /// </summary>
        public async Task<int> MatchLookupRecordByEntityName(int id, string type, string value,string name)
        {
            try
            {
                int waitingformatchapproval = _dbContext.WorkflowStatuses.Where(x => x.Name == "Waiting for Matched Approval").Select(x => x.WorkflowStatusId).FirstOrDefault();
           
                if (type.ToLower() == MDMEnum.PageType.BU.ToString().ToLower())
                {
                    var BusinessUnitLookup = _dbContext.BusinessUnitLookups.Where(x => x.BusinessUnitLookupId == id).FirstOrDefault();
                    if (BusinessUnitLookup != null)
                    {
                        BusinessUnitLookup.BusinessUnitMdmid = Convert.ToInt32(value);
                        BusinessUnitLookup.WorkflowStatusId = waitingformatchapproval;
                        BusinessUnitLookup.ModifiedDateTime = DateTime.Now;
                        BusinessUnitLookup.ModifiedBy = name;
                        _dbContext.BusinessUnitLookups.Update(BusinessUnitLookup);
                        _dbContext.SaveChanges();
                        return BusinessUnitLookup.BusinessUnitLookupId; // Yes it's here
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    var PersonLookups = _dbContext.PersonLookups.Where(x => x.PersonLookupId == id).FirstOrDefault();
                    if (PersonLookups != null)
                    {
                        PersonLookups.PersonMdmid = Convert.ToInt32(value);
                        PersonLookups.WorkflowStatusId = waitingformatchapproval;
                        PersonLookups.ModifiedDateTime = DateTime.Now;
                        PersonLookups.ModifiedBy = name;
                        _dbContext.PersonLookups.Update(PersonLookups);
                        _dbContext.SaveChanges();
                        return PersonLookups.PersonLookupId; // Yes it's here
                    }
                    else
                    {
                        return 0;
                    }
                }
                return 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }
        /// <summary>
        /// Update wotk flow status as reject in Business unit and person aprroval screen 
        /// </summary>
        public async Task<int> RejectLookupRecordByEntityName(int id, string value,string action, string type, string name)
        {
            try
            {
                var getRejectionId = _dbContext.WorkflowStatuses.Where(x => x.Name == action).Select(x => x.WorkflowStatusId).FirstOrDefault();
                if (type.ToLower() == MDMEnum.PageType.BU.ToString().ToLower())
                {
                    var BusinessUnitLookups = _dbContext.BusinessUnitLookups.Where(x => x.BusinessUnitLookupId == id).FirstOrDefault();
                    if (BusinessUnitLookups != null)
                    {
                        BusinessUnitLookups.BusinessUnitMdmid = null;
                        BusinessUnitLookups.WorkflowStatusId = getRejectionId;
                        BusinessUnitLookups.Remarks = value;
                        BusinessUnitLookups.ModifiedDateTime = DateTime.Now;
                        BusinessUnitLookups.ModifiedBy = name;
                        _dbContext.BusinessUnitLookups.Update(BusinessUnitLookups);
                        _dbContext.SaveChanges();
                        return BusinessUnitLookups.BusinessUnitLookupId; // Yes it's here
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    var PersonLookUp = _dbContext.PersonLookups.Where(x => x.PersonLookupId == id).FirstOrDefault();
                    if (PersonLookUp != null)
                    {
                        PersonLookUp.PersonMdmid = null;
                        PersonLookUp.WorkflowStatusId = getRejectionId;
                        PersonLookUp.Remarks = value;
                        PersonLookUp.ModifiedDateTime = DateTime.Now;
                        PersonLookUp.ModifiedBy = name;
                        _dbContext.PersonLookups.Update(PersonLookUp);
                        _dbContext.SaveChanges();
                        return PersonLookUp.PersonLookupId; // Yes it's here
                    }
                    else
                    {
                        return 0;
                    }
                }
                    
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }
    }
}