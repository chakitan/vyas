﻿using Civica.ABI.MDM.API.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Data;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.DTO;

namespace Civica.ABI.MDM.API.Services
{
    public  class MasterRecordService: IMasterRecordService
    {
        private readonly ILogger<MasterRecordService> _logger;
        private readonly MDMDbContext _dbContext;

        public MasterRecordService(ILogger<MasterRecordService> log, MDMDbContext dbContext)
        {
            this._logger = log;
            this._dbContext = dbContext;
        }
        /// <summary>
        /// Right Filter panel Dataset(table :- BusinessUnitLookups > SourceIdentifier) multi selection dropdown for MDM > MDM Business Unit Data Set screen
        /// </summary>
        public async Task<List<BusinessUnitLookup>> GetBusinessUnitSourceIdentifierList()
        {
           
            var BusinessUnitLookups = _dbContext.BusinessUnitLookups.Where(x=>x.SourceIdentifier != null).ToList();
            return BusinessUnitLookups;
        }
        /// <summary>
        /// Right Filter panel Person Dataset(table :- PersonLookups > SourceIdentifier) multi selection dropdown for MDM > MDM Person Data Set screen
        /// </summary>
        /// <returns></returns>
        public async Task<List<PersonLookup>> GetPersonSourceIdentifierList()
        {

            var PersonLookups = _dbContext.PersonLookups.Where(x => x.SourceIdentifier != null).ToList();
            return PersonLookups;
        }

        /// <summary>
        /// MDM > MDM Business Unit Data Set :- in grid master business unit dropdown search call this api (table : MasterBusinessUnits)
        /// </summary>
        /// <param name="searchMasterBusinessUnitName"></param>
        public async Task<List<ManageMasterBUDTO>> GetMasterBusinessUnitListForMatching(string searchMasterBusinessUnitName)
        {
            try
            {
                return await System.Threading.Tasks.Task.FromResult(
                    _dbContext.MasterBusinessUnits.Select(x => new ManageMasterBUDTO
                {
                    BusinessUnitMDMID = x.BusinessUnitMdmid,
                    Name = x.Name
                }).Where(x => x.Name.ToLower().Contains(searchMasterBusinessUnitName.ToLower())).ToList());
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// Right Filter panel WorkFlow Status(table :- WorkflowStatuses) single selection dropdown for MDM > MDM Business Unit/Person Data Set screen
        /// </summary>
        public async Task<List<WorkflowStatus>> GetWorkflowStatusList()
        {
            try
            {
                var MdmworkflowStatuses = _dbContext.WorkflowStatuses.ToList();
                return MdmworkflowStatuses;
            }
            catch (Exception ex)
            {

                throw;
            }
         
        }
        #region Get source master data from table and return list
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- source and region dropdown bind ETL data with this api
        /// </summary>
        /// <returns></returns>
        public async Task<List<ETLSourceSystemRegion>> GetETLSourceSystemRegionList()
        {
            try
            {
                var ETLSourceSystemRegion = _dbContext.ETLsourceSystemRegions.Select(x => new ETLSourceSystemRegion
                {
                    SourceSystemRegionId = x.SourceSystemRegionId,  
                    SourceSystem = x.SourceSystem,
                    Region = x.Region,
                    ExecutionOrder = x.ExecutionOrder,
                    IsActive=x.IsActive,    
                }).ToList();
                return ETLSourceSystemRegion;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Methord:- GetETLSourceSystemRegionList." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw;
            }
        }
        #endregion
    }
}
