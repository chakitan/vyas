﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IMasterRecordService
    {
        Task<List<BusinessUnitLookup>> GetBusinessUnitSourceIdentifierList();
        Task<List<WorkflowStatus>> GetWorkflowStatusList();
        Task<List<ManageMasterBUDTO>> GetMasterBusinessUnitListForMatching(string searchMasterBusinessUnitName);
        Task<List<PersonLookup>> GetPersonSourceIdentifierList();
        Task<List<ETLSourceSystemRegion>> GetETLSourceSystemRegionList();

    }
}
