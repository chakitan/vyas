﻿using Civica.ABI.MDM.API.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IManageBUDataSetRecords
    {
        Task<ManageBUDataSetListDTO> GetLookupBusinessUnitList(string filter = null, int page = 1, int limit = 20, string sort = null, DateTime? modifiedDateTime = null);
        Task<ManageBUDataSetListDTO> GetLookupBusinessUnitWaitingForApprovalList(string filter = null, int page = 1, int limit = 20, string sort = null);
    }
}
