﻿using Civica.ABI.MDM.API.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IManageMasterPerson
    {
        Task<MasterPersonListDTO> GetMasterPersonList(string filter = null, int page = 1, int limit = 20, string sort = null);
    }
}
