﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface  IManageMasterBusinessUnit
    {
        Task<MasterBusinessUnitDTO> GetMasterBusinessUnitList(string filter = null, int page = 1, int limit = 20, string sort = null);
        Task<string> SaveBusinessUnit(MasterBusinessUnit content = null, string name = null);
        Task<string> AutoGenerateBusinessUnitCode(string region);
        Task<bool> IsBusinessUnitCodeExitsInRegion(string bucode,string region);
        Task<bool> IsBusinessUnitNameExits(string buname, int businessUnitMDMID);
        Task<bool> IsT7CodeExits(string T7Code);
        Task<string> AutoGenerateT7Code();
        Task<bool> RollBackSaveBusinessUnit(int BusinessUnitMdmid);
        Task<ManageMasterBUDTO> GetBusinessUnitDetailByBusinessUnitMDMID(int businessUnitMDMID);
    }
}
