﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IWorkFlowStatusChangesService
    {
        Task<int> MatchLookupRecordByEntityName(int id,string type,string value,string name);
        Task<int> UpdateWorkFlowStatusByEntityName(int id, string type, string action, string name);
        Task<int> RejectLookupRecordByEntityName(int id = 0, string value = null, string action=null, string type = null, string name=null);

    }
}
