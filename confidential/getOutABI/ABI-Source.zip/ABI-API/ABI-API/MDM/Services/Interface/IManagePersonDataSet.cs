﻿using Civica.ABI.MDM.API.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IManagePersonDataSet
    {
        Task<ManagePeronDataSetListDTO> GetLookupPersonList(string filter = null, int page = 1, int limit = 20, string sort = null, DateTime? modifiedDate = null);
        Task<IEnumerable<MasterPersonDataSetDTO>> GetMasterPersonListForMatching(string srchMasterPersonNameByInsertedChaaracter);

        Task<ManagePeronDataSetListDTO> GetLookupPersonWaitingForApprovalList(string filter = null, int page = 1, int limit = 20, string sort = null);

        
    } 
}