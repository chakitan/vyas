﻿using Civica.ABI.MDM.API.DTO;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.Interface
{
    public interface IFailedRecordService
    {
        Task<List<FailedRecordCountDTO>> GetFailedRecordList(string schemaname = null, string search = null);
        Task<DataTable> ExportFailedRecordListByEntityName(string schemaName, string tableName);
    }
}
