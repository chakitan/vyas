﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Civica.ABI.MDM.API.Shared.Extensions;
using Gridify;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services
{
    public class ManageBUDataSetDataService : IManageBUDataSetRecords
    {
        private readonly MDMDbContext _dbContext;
        public ManageBUDataSetDataService(MDMDbContext dbContext)
        {
            this._dbContext = dbContext;
        }

        #region GetBusinessUnitRecords
        /// <summary>
        /// MDM Business Unit Data Set Index screen Index screen API to get data
        /// </summary>
        public async Task<ManageBUDataSetListDTO> GetLookupBusinessUnitList(string filter = null, int page = 1, int limit = 10, string sort = null
            , DateTime? modifiedDateTime = null)
        {

            try
            {
                GridifyQuery gQuery = new()
                {
                    Filter = $"{filter}",
                    OrderBy = $"{sort}"
                };
                // Execute Stored Proc to get failed record counts
                var BusinessUnitLookups = await
                (from l1 in _dbContext.BusinessUnitLookups
                 join l2 in _dbContext.WorkflowStatuses on l1.WorkflowStatusId equals l2.WorkflowStatusId
                 join l3 in _dbContext.MasterBusinessUnits on l1.BusinessUnitMdmid equals l3.BusinessUnitMdmid
                 into leftJ
                 from lj in leftJ.DefaultIfEmpty()
                 where modifiedDateTime != null ? l1.ModifiedDateTime.Date == modifiedDateTime.Value.Date : 0 == 0
                 select new ManageBUDataSetDTO
                 {
                     BusinessUnitLookupId = l1.BusinessUnitLookupId,
                     Name = l1.Name,
                     Division = l1.Division,
                     BusinessUnitMdmid = l1.BusinessUnitMdmid,
                     Bucode = l1.Bucode,
                     Region = l1.Region,
                     T7code = l1.T7code,
                     SourceIdentifier = l1.SourceIdentifier,
                     WorkflowStatusId = l1.WorkflowStatusId,
                     WorkflowStatusName = l2.Name,
                     Remarks = l1.Remarks,
                     RunId = l1.RunId,
                     ModifiedDateTime = l1.ModifiedDateTime,
                     ModifiedBy = l1.ModifiedBy,
                     MasterBusinessunitName = lj.Name
                 }).OrderBy(p => p.Name).AsNoTracking().ApplyFilteringAndOrdering(gQuery).PaginateAsync(page, limit);
                return new ManageBUDataSetListDTO
                {
                    CurrentPage = BusinessUnitLookups.CurrentPage,
                    TotalPages = BusinessUnitLookups.TotalPages,
                    TotalItems = BusinessUnitLookups.TotalItems,
                    Items = BusinessUnitLookups.Items.Select(p => new ManageBUDataSetDTO
                    {
                        BusinessUnitLookupId = p.BusinessUnitLookupId,
                        Name = p.Name,
                        Division = p.Division,
                        BusinessUnitMdmid = p.BusinessUnitMdmid,
                        Bucode = p.Bucode,
                        Region = p.Region,
                        T7code = p.T7code,
                        SourceIdentifier = p.SourceIdentifier,
                        WorkflowStatusId = p.WorkflowStatusId,
                        WorkflowStatusName = p.WorkflowStatusName,
                        Remarks = p.Remarks,
                        RunId = p.RunId,
                        ModifiedDateTime = p.ModifiedDateTime,
                        ModifiedBy = p.ModifiedBy,
                        MasterBusinessunitName = p.MasterBusinessunitName
                    }).ToList()
                };
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region GetBusinessUnitDatasetRecordsApproval
        /// <summary>
        /// MDM Business Unit Data Set > Waiting for Junk/Matched  Approval Index screen API to get data
        /// </summary>
        public async Task<ManageBUDataSetListDTO> GetLookupBusinessUnitWaitingForApprovalList(string filter = null, int page = 1, int limit = 20, string sort = null)
        {
            try
            {
                GridifyQuery gQuery = new()
                {
                    Filter = $"{filter}",
                    OrderBy = $"{sort}"
                };
                // Execute Stored Proc to get failed record counts
                var BusinessUnitLookups = await
                    (from l1 in _dbContext.BusinessUnitLookups
                     join l2 in _dbContext.WorkflowStatuses on l1.WorkflowStatusId equals l2.WorkflowStatusId
                     join l3 in _dbContext.MasterBusinessUnits on l1.BusinessUnitMdmid equals l3.BusinessUnitMdmid
                     into leftJ
                     from lj in leftJ.DefaultIfEmpty()
                         //where l2.WorkflowStatusId == 3
                     select new ManageBUDataSetDTO
                     {

                         BusinessUnitLookupId = l1.BusinessUnitLookupId,
                         Name = l1.Name,
                         Division = l1.Division,
                         BusinessUnitMdmid = l1.BusinessUnitMdmid,
                         Bucode = l1.Bucode,
                         Region = l1.Region,
                         T7code = l1.T7code,
                         SourceIdentifier = l1.SourceIdentifier,
                         WorkflowStatusId = l1.WorkflowStatusId,
                         WorkflowStatusName = l2.Name,
                         Remarks = l1.Remarks,
                         RunId = l1.RunId,
                         ModifiedDateTime = l1.ModifiedDateTime,
                         ModifiedBy = l1.ModifiedBy,
                         MasterBusinessunitName = lj.Name
                     }).OrderBy(p => p.Name).AsNoTracking().ApplyFilteringAndOrdering(gQuery).PaginateAsync(page, limit);
                return new ManageBUDataSetListDTO
                {
                    CurrentPage = BusinessUnitLookups.CurrentPage,
                    TotalPages = BusinessUnitLookups.TotalPages,
                    TotalItems = BusinessUnitLookups.TotalItems,
                    Items = BusinessUnitLookups.Items.Select(p => new ManageBUDataSetDTO
                    {
                        BusinessUnitLookupId = p.BusinessUnitLookupId,
                        Name = p.Name,
                        Division = p.Division,
                        BusinessUnitMdmid = p.BusinessUnitMdmid,
                        Bucode = p.Bucode,
                        Region = p.Region,
                        T7code = p.T7code,
                        SourceIdentifier = p.SourceIdentifier,
                        WorkflowStatusId = p.WorkflowStatusId,
                        WorkflowStatusName = p.WorkflowStatusName,
                        Remarks = p.Remarks,
                        RunId = p.RunId,
                        ModifiedDateTime = p.ModifiedDateTime,
                        ModifiedBy = p.ModifiedBy,
                        MasterBusinessunitName = p.MasterBusinessunitName
                    }).ToList()
                };
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion
    }
}
