﻿using Microsoft.Extensions.Logging;
using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Civica.ABI.MDM.API.Shared.Extensions;
using Gridify;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Civica.ABI.MDM.API.Services;

public class ManagePersonDataSetService : IManagePersonDataSet
{
    private readonly MDMDbContext _dbContext;
    private readonly ILogger<PersonDataSetEndpoint> _logger;
    public ManagePersonDataSetService(MDMDbContext dbContext, ILogger<PersonDataSetEndpoint> Logger)
    {
        this._dbContext = dbContext;
        _logger = Logger;
    }

    #region GetPersonData
    /// <summary>
    /// MDM > MDM Person Data Set :- person dataset list screen index grid to bind
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="page"></param>
    /// <param name="limit"></param>
    /// <param name="sort"></param>
    /// <param name="modifiedDate"></param>
    public async Task<ManagePeronDataSetListDTO> GetLookupPersonList(string filter = null, int page = 1, int limit = 20, string sort = null, DateTime? modifiedDate = null)
    {
        try
        {
            GridifyQuery gQuery = new()
            {
                Filter = $"{filter}",
                OrderBy = $"{sort}"
            };
            // Execute Stored Proc to get failed record counts
            var personDataSet = await (from l1 in _dbContext.PersonLookups
                                       join l2 in _dbContext.WorkflowStatuses on l1.WorkflowStatusId equals l2.WorkflowStatusId
                                       join l3 in _dbContext.MasterPeople on l1.PersonMdmid equals l3.PersonMdmid
                                       into leftJ
                                       from lj in leftJ.DefaultIfEmpty()
                                       where modifiedDate != null ? l1.ModifiedDateTime.Date == modifiedDate.Value.Date : 0 == 0
                                       select new ManagePersonDataSetDTO
                                       {
                                           Name = l1.Name,
                                           BusinessUnitName = l1.BusinessUnitName,
                                           CostCentre = l1.CostCentre,
                                           EmployeeId = l1.EmployeeId,
                                           Email = l1.Email,
                                           Remarks = l1.Remarks,
                                           ModifiedBy = l1.ModifiedBy,
                                           ModifiedDateTime = l1.ModifiedDateTime,
                                           PersonLookupId = l1.PersonLookupId,
                                           PersonMdmid = l1.PersonMdmid,
                                           RunId = l1.RunId,
                                           SourceIdentifier = l1.SourceIdentifier,
                                           WorkflowStatusId = l1.WorkflowStatusId,
                                           WorkflowStatusName = l2.Name,
                                           PersonName = lj.Name
                                       }).OrderBy(p => p.Name).AsNoTracking().ApplyFilteringAndOrdering(gQuery).PaginateAsync(page, limit);
            return new ManagePeronDataSetListDTO
            {
                CurrentPage = personDataSet.CurrentPage,
                TotalPages = personDataSet.TotalPages,
                TotalItems = personDataSet.TotalItems,
                Items = personDataSet.Items.Select(p => new ManagePersonDataSetDTO
                {
                    Name = p.Name,
                    BusinessUnitName = p.BusinessUnitName,
                    CostCentre = p.CostCentre,
                    EmployeeId = p.EmployeeId,
                    Email = p.Email,
                    Remarks = p.Remarks,
                    ModifiedBy = p.ModifiedBy,
                    ModifiedDateTime = p.ModifiedDateTime,
                    PersonLookupId = p.PersonLookupId,
                    PersonMdmid = p.PersonMdmid,
                    RunId = p.RunId,
                    SourceIdentifier = p.SourceIdentifier,
                    WorkflowStatusId = p.WorkflowStatusId,
                    WorkflowStatusName = p.WorkflowStatusName,
                    PersonName = p.PersonName
                }).ToList()
            };
        }
        catch (Exception ex)
        {
            _logger.LogInformation("GetPersonDataSet." + "*** StackTrace:- " + ex.StackTrace + "*** Message:- " + ex.Message);
            throw;
        }
    }

    #endregion

    #region GetMasterPerson
    /// <summary>
    /// MDM > MDM Person Data Set :- person dataset list screen index grid dropdown of master person bind
    /// </summary>
    /// <param name="srchMasterPersonNameByInsertedChaaracter"></param>
    public async Task<IEnumerable<MasterPersonDataSetDTO>> GetMasterPersonListForMatching(string srchMasterPersonNameByInsertedChaaracter)
    {
        try
        {
            return await System.Threading.Tasks.Task.FromResult(_dbContext.MasterPeople.Select(x => new MasterPersonDataSetDTO
            {
                PersonMdmid = x.PersonMdmid,
                BusinessUnitName = x.BusinessUnitName,
                Name = x.Name,
            }).Where(x => x.Name.ToLower().Contains(srchMasterPersonNameByInsertedChaaracter.ToLower()) ||
                     x.BusinessUnitName.ToLower().Contains(srchMasterPersonNameByInsertedChaaracter.ToLower())).ToList());

        }
        catch (Exception ex)
        {
            _logger.LogInformation("GetmasterPersonDataSet " + "*** StackTrace:- " + ex.StackTrace + "*** Message:- " + ex.Message);
            throw;
        }
    }
    #endregion

    #region GetPersonDataSetApproval
    /// <summary>
    /// MDM > MDM Person Data Set > Waiting for Matched Approval : list of approval matched/junk grid bind with this api
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="page"></param>
    /// <param name="limit"></param>
    /// <param name="sort"></param>
    public async Task<ManagePeronDataSetListDTO> GetLookupPersonWaitingForApprovalList(string filter, int page, int limit, string sort)
    {
        try
        {
            GridifyQuery gQuery = new()
            {
                Filter = $"{filter}",
                OrderBy = $"{sort}"
            };
            // Execute Stored Proc to get failed record counts
            var personDataSet = await (from l1 in _dbContext.PersonLookups
                                       join l2 in _dbContext.WorkflowStatuses on l1.WorkflowStatusId equals l2.WorkflowStatusId
                                       join l3 in _dbContext.MasterPeople on l1.PersonMdmid equals l3.PersonMdmid
                                       into leftJ
                                       from lj in leftJ.DefaultIfEmpty()
                                           //where l2.WorkflowStatusId == 3
                                       select new ManagePersonDataSetDTO
                                       {

                                           Name = l1.Name,
                                           BusinessUnitName = l1.BusinessUnitName,
                                           CostCentre = l1.CostCentre,
                                           EmployeeId = l1.EmployeeId,
                                           Email = l1.Email,
                                           Remarks = l1.Remarks,
                                           ModifiedBy = l1.ModifiedBy,
                                           ModifiedDateTime = l1.ModifiedDateTime,
                                           PersonLookupId = l1.PersonLookupId,
                                           PersonMdmid = l1.PersonMdmid,
                                           RunId = l1.RunId,
                                           SourceIdentifier = l1.SourceIdentifier,
                                           WorkflowStatusId = l1.WorkflowStatusId,
                                           WorkflowStatusName = l2.Name,
                                           PersonName = lj.Name
                                       }).OrderBy(p => p.Name).AsNoTracking().ApplyFilteringAndOrdering(gQuery).PaginateAsync(page, limit);
            return new ManagePeronDataSetListDTO
            {
                CurrentPage = personDataSet.CurrentPage,
                TotalPages = personDataSet.TotalPages,
                TotalItems = personDataSet.TotalItems,
                Items = personDataSet.Items.Select(p => new ManagePersonDataSetDTO
                {
                    Name = p.Name,
                    BusinessUnitName = p.BusinessUnitName,
                    CostCentre = p.CostCentre,
                    EmployeeId = p.EmployeeId,
                    Email = p.Email,
                    Remarks = p.Remarks,
                    ModifiedBy = p.ModifiedBy,
                    ModifiedDateTime = p.ModifiedDateTime,
                    PersonLookupId = p.PersonLookupId,
                    PersonMdmid = p.PersonMdmid,
                    RunId = p.RunId,
                    SourceIdentifier = p.SourceIdentifier,
                    WorkflowStatusId = p.WorkflowStatusId,
                    WorkflowStatusName = p.WorkflowStatusName,
                    PersonName = p.PersonName
                }).ToList()
            };
        }
        catch (Exception ex)
        {
            _logger.LogInformation("GetPersonDataSetApproval." + "*** StackTrace:- " + ex.StackTrace + "*** Message:- " + ex.Message);
            throw;
        }
    }
    #endregion

}


