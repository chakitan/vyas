﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.APIEndPoints;
using Civica.ABI.MDM.API.Services.Interface;
using Civica.ABI.MDM.API.Shared.Extensions;
using Gridify;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services
{
    public class ManageMasterPerson : IManageMasterPerson
    {
        private readonly MDMDbContext _dbContext;
        private readonly ILogger<GetMasterPerson> logger;
        public ManageMasterPerson(MDMDbContext dbContext, ILogger<GetMasterPerson> Logger)
        {
            this._dbContext = dbContext;
            logger = Logger;
        }
        #region getMasterBusinessUnitList service logic to get data with pagging and filter
        /// <summary>
        /// MDM > Add/View Person Master data :- Master perosn index screen to get data and bind in grid
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="page"></param>
        /// <param name="limit"></param>
        /// <param name="sort"></param>
        public async Task<MasterPersonListDTO> GetMasterPersonList(string filter = null, int page = 1, int limit = 20, string sort = null)
        {
            try
            {
                GridifyQuery gQuery = new()
                {
                    Filter = $"{filter}",
                    OrderBy = $"{sort}"
                };
                var query = await (from l1 in _dbContext.MasterPeople
                                   select new MasterPerson
                                   {
                                       BusinessUnitName = l1.BusinessUnitName,
                                       Name = l1.Name,
                                       PersonMdmid = l1.PersonMdmid,
                                       Email = l1.Email,
                                       EmployeeId = l1.EmployeeId,
                                       Qcsp = l1 == null ? null : l1.Qcsp,
                                       SourceIdentifier = l1.SourceIdentifier
                                   }).OrderBy(p => p.Name).AsNoTracking().ApplyFilteringAndOrdering(gQuery).PaginateAsync(page, limit);
                if (query != null)
                {
                    return new MasterPersonListDTO
                    {
                        CurrentPage = query.CurrentPage,
                        TotalPages = query.TotalPages,
                        TotalItems = query.TotalItems,
                        Items = query.Items.Select(l1 => new MasterPerson
                        {
                            BusinessUnitName = l1.BusinessUnitName,
                            Name = l1.Name,
                            PersonMdmid = l1.PersonMdmid,
                            Email = l1.Email,
                            EmployeeId = l1.EmployeeId,
                            Qcsp = l1 == null ? null : l1.Qcsp,
                            SourceIdentifier = l1.SourceIdentifier
                        }).ToList()
                    };
                }
                else
                {
                    return null; ;
                }

            }
            catch (Exception ex)
            {
                logger.LogInformation("Methord:- GetMasterPersonList." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw;
            }

        }


        #endregion
    }
}

