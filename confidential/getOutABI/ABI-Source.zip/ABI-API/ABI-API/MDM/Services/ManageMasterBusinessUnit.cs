﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.APIEndPoints;
using Civica.ABI.MDM.API.Services.Interface;
using Gridify;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services
{
    public class ManageMasterBusinessUnit : IManageMasterBusinessUnit
    {
        private readonly MDMDbContext _dbContext;
        private readonly ILogger<GetMasterBusinessUnit> logger;
        public static string getMaxT7CoddeId { get; set; }
        public static string getMaxBUCoddeId { get; set; }
        public ManageMasterBusinessUnit(MDMDbContext dbContext, ILogger<GetMasterBusinessUnit> Logger)
        {
            this._dbContext = dbContext;
            logger = Logger;
        }

        #region getMasterBusinessUnitList service logic to get data with pagging and filter
        /// <summary>
        /// MDM > Add/View Business Unit Master data Index screen to load data and bind in grid
        /// </summary>
        public async Task<MasterBusinessUnitDTO> GetMasterBusinessUnitList(string filter = null, int page = 1, int limit = 20, string sort = null)
        {
            try
            {
                GridifyQuery gQuery = new()
                {
                    Filter = $"{filter}",
                    OrderBy = $"{sort}"
                };
                var query =  (from l1 in _dbContext.MasterBusinessUnits
                                   select new MasterBusinessUnit
                                   {
                                       Division = l1.Division,
                                       Name = l1.Name,
                                       BusinessUnitMdmid = l1.BusinessUnitMdmid,
                                       Bucode = l1.Bucode,
                                       T7code = l1.T7code,
                                       Region = l1.Region,
                                       SourceIdentifier = l1.SourceIdentifier
                                   }).OrderBy(p => p.Division).AsNoTracking().ApplyFilteringAndOrdering(gQuery);
                if (query != null)
                {
                    return new MasterBusinessUnitDTO
                    {
                        Items = query.Select(l1 => new MasterBusinessUnit
                        {
                            Division = l1.Division,
                            Name = l1.Name,
                            BusinessUnitMdmid = l1.BusinessUnitMdmid,
                            Bucode = l1.Bucode,
                            T7code = l1.T7code,
                            Region = l1.Region,
                            SourceIdentifier = l1.SourceIdentifier
                        }).ToList()
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method:- GetMasterBusinessUnitList." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw;
            }
        }
        #endregion

        #region GetBusinessUnitCode
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master Click on link to create new Business unit code 
        /// </summary>
        public async Task<string> AutoGenerateBusinessUnitCode(string region)
        {
            try
            {
                int[] lstExistBusinessUnitCodes = _dbContext.MasterBusinessUnits.Where(x => EF.Functions.Like(x.Bucode, "[0-9]%") && EF.Functions.Like(x.Bucode, "%[0-9]") && x.Region == region).Select(x => Convert.ToInt32(x.Bucode)).ToArray();
                var getAvailableBUCode = Enumerable.Range(1, 999).Except(lstExistBusinessUnitCodes);
                getMaxBUCoddeId = Convert.ToString(getAvailableBUCode.First());
                getMaxBUCoddeId = getMaxBUCoddeId.ToString().PadLeft(3, '0');
                return getMaxBUCoddeId.ToString();
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method :- GetBusinessUnitAutoGenerateCode." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion

        #region Create T7 code from database 
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master Click on link to create new T7Code
        /// </summary>
        public async Task<string> AutoGenerateT7Code()
        {
            try
            {
                string checkT7CodeExistOrNot = string.Empty;
                string checkDefaultValue = _dbContext.MasterBusinessUnits.Where(x => EF.Functions.Like(x.T7code, "[A-Z]%") && EF.Functions.Like(x.T7code, "%[0-9]") && (x.T7code == "A01")).Select(x => x.T7code).FirstOrDefault();
                if (checkDefaultValue == null)
                {
                    checkT7CodeExistOrNot = "A01";
                    return checkT7CodeExistOrNot;
                }
                else
                {
                    List<string> lstExistT7Codes = _dbContext.MasterBusinessUnits.Where(x => EF.Functions.Like(x.T7code, "[A-Z]%") && EF.Functions.Like(x.T7code, "%[0-9]"))
                    .Select(x => x.T7code).OrderBy(x => x).ToList();
                    var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    string getAvailableT7Code = string.Empty;
                    foreach (var gett7code in lstExistT7Codes)
                    {
                        if (gett7code == "Z99")
                            throw new ArgumentOutOfRangeException("I can handle till Z99 only!");

                        var intPart = int.Parse(gett7code.Substring(1, 2));
                        if (intPart < 99)
                            getAvailableT7Code = gett7code.Substring(0, 1) + (++intPart).ToString("00");
                        else
                        {
                            var char2idx = letters.IndexOf(gett7code.Substring(0, 1));
                            if (char2idx < letters.Length - 1)
                                getAvailableT7Code = gett7code.Substring(0, 0) + letters.Substring(++char2idx, 1) + "01";
                            else
                            {
                                var char1idx = letters.IndexOf(gett7code.Substring(0, 1));
                                getAvailableT7Code = letters.Substring(++char1idx, 1) + "A01";
                            }
                        }
                        checkT7CodeExistOrNot = _dbContext.MasterBusinessUnits.Where(x => EF.Functions.Like(x.T7code, "[A-Z]%") && EF.Functions.Like(x.T7code, "%[0-9]") && (x.T7code == getAvailableT7Code)).Select(x => x.T7code).FirstOrDefault();
                        if (checkT7CodeExistOrNot == null)
                        {
                            checkT7CodeExistOrNot = getAvailableT7Code;
                            break;
                        }
                    }
                    return checkT7CodeExistOrNot;
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method :- GetAutoGenerateT7Code." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion

        #region Save Business Unit in MDM database and mdm.BusinessUnitLookup table and return Primary ID
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- add or update business unit screen 
        /// </summary>
        /// <param name="content"></param>
        /// <param name="name"></param>
        public async Task<string> SaveBusinessUnit(MasterBusinessUnit content = null, string name = null)
        {
            using (var dbContextTransaction = _dbContext.Database.BeginTransaction())
            {
                try
                {
                    int BusinessUnitMdmid = 0;
                    if (content != null)
                    {
                        if (content.BusinessUnitMdmid > 0)
                        {
                            MasterBusinessUnit masterBusiness = _dbContext.MasterBusinessUnits.Single(u => u.BusinessUnitMdmid == content.BusinessUnitMdmid);
                            using (var dbContextUpdateMasterBu = new MDMDbContext())
                            {


                                masterBusiness.ModifiedBy = name;
                                masterBusiness.ModifiedDateTime = DateTime.Now;
                                //masterBusiness.SourceIdentifier = content.SourceIdentifier + " " + content.Region + " " + "BusinessUnit";
                                masterBusiness.Division = content.Division;
                                masterBusiness.Name = content.Name;
                                _dbContext.MasterBusinessUnits.Update(masterBusiness);
                                _dbContext.SaveChanges();
                                masterBusiness.BusinessUnitMdmid = content.BusinessUnitMdmid;
                                logger.LogInformation("User {user} created a new Business Unit In MDM Database ({BusinessUnitID})", name, BusinessUnitMdmid);
                            }
                            using (var dbContextUpdateMasterBuLookUp = new MDMDbContext())
                            {
                                BusinessUnitLookup businessUnitLookUp = _dbContext.BusinessUnitLookups.Single(u => u.BusinessUnitMdmid == masterBusiness.BusinessUnitMdmid
                                                                                                              && u.SourceIdentifier == masterBusiness.SourceIdentifier);
                                if (businessUnitLookUp != null)
                                {
                                    if (content != null)
                                    {
                                        businessUnitLookUp.Name = content.Name;
                                        businessUnitLookUp.Division = content.Division;
                                        businessUnitLookUp.BusinessUnitMdmid = content.BusinessUnitMdmid;
                                        businessUnitLookUp.Bucode = content.Bucode;
                                        //businessUnitLookUp.Region = content.Region; // disble when edit so not need this 
                                        businessUnitLookUp.T7code = content.T7code;
                                        //businessUnitLookUp.SourceIdentifier = content.SourceIdentifier + " " + content.Region + " " + "BusinessUnit"; // disble when edit so not need this 
                                        businessUnitLookUp.ModifiedDateTime = DateTime.Now;
                                        businessUnitLookUp.ModifiedBy = name;
                                        _dbContext.BusinessUnitLookups.Update(businessUnitLookUp);
                                        _dbContext.SaveChanges();
                                        int BusinessUnitLookupID = businessUnitLookUp.BusinessUnitLookupId;
                                        logger.LogInformation("User {user} created a new Business Unit Lookup In MDM Database ({BusinessUnitLookupID})", name, BusinessUnitLookupID);
                                    }
                                    dbContextTransaction.Commit();
                                    return Convert.ToString(content.BusinessUnitMdmid);
                                }
                                else
                                {
                                    return null;
                                }
                            }
                        }
                        else
                        {
                            string SourceIdentifier = content.SourceIdentifier + " " + content.Region + " " + "BusinessUnit";
                            using (var dbContextInsertMasterBu = new MDMDbContext())
                            {
                                content.ModifiedBy = name;
                                content.ModifiedDateTime = DateTime.Now;
                                content.SourceIdentifier = SourceIdentifier;
                                _dbContext.MasterBusinessUnits.Add(content);
                                _dbContext.SaveChanges();
                                BusinessUnitMdmid = content.BusinessUnitMdmid;
                                logger.LogInformation("User {user} created a new Business Unit In MDM Database ({BusinessUnitID})", name, BusinessUnitMdmid);
                            }
                            // Save data in mdm.BusinessUnitLookup table
                            using (var dbContextInsertMasterBuLookup = new MDMDbContext())
                            {
                                BusinessUnitLookup BusinessUnitLookup = new BusinessUnitLookup();
                                if (content != null)
                                {
                                    BusinessUnitLookup.Name = content.Name;
                                    BusinessUnitLookup.Division = content.Division;
                                    BusinessUnitLookup.BusinessUnitMdmid = content.BusinessUnitMdmid;
                                    BusinessUnitLookup.Bucode = content.Bucode;
                                    BusinessUnitLookup.Region = content.Region;
                                    BusinessUnitLookup.T7code = content.T7code;
                                    BusinessUnitLookup.SourceIdentifier = SourceIdentifier;
                                    BusinessUnitLookup.WorkflowStatusId = 1; //matched
                                    BusinessUnitLookup.Remarks = null;
                                    BusinessUnitLookup.RunId = Guid.Empty;
                                    BusinessUnitLookup.ModifiedDateTime = DateTime.Now;
                                    BusinessUnitLookup.ModifiedBy = name;
                                    _dbContext.BusinessUnitLookups.Add(BusinessUnitLookup);
                                    _dbContext.SaveChanges();
                                    int BusinessUnitLookupID = BusinessUnitLookup.BusinessUnitLookupId;
                                    logger.LogInformation("User {user} created a new Business Unit Lookup In MDM Database ({BusinessUnitLookupID})", name, BusinessUnitLookupID);
                                }
                                dbContextTransaction.Commit();
                                return Convert.ToString(BusinessUnitMdmid);
                            }
                        }
                    }
                    else
                    {
                        return String.Empty;
                    }
                }
                catch (Exception ex)
                {
                    logger.LogInformation("Method:- SaveBusinessUnit." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                    dbContextTransaction.Rollback(); //Required according to MSDN article 
                    throw;
                }
            }
        }
        #endregion

        #region Check in mdm.MasterBusinessUnit that given BUcode with Region is exits or not
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- check business code exits in selected region
        /// </summary>
        public async Task<bool> IsBusinessUnitCodeExitsInRegion(string bucode, string Region)
        {
            try
            {
                int BusinessUnitMdmid = BusinessUnitMdmid = _dbContext.MasterBusinessUnits.Where(x => x.Bucode == bucode && x.Region == Region).Select(x => x.BusinessUnitMdmid).FirstOrDefault();

                if (BusinessUnitMdmid > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method:- IsBUCodeExitsInRegion." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion

        #region Check in mdm.MasterBusinessUnit that given Name is exits or not
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- check business code name duplicated or not
        /// </summary>
        /// <param name="buname"></param>
        /// <param name="businessUnitMDMID"></param>
        public async Task<bool> IsBusinessUnitNameExits(string buname, int businessUnitMDMID)
        {

            try
            {
                int BusinessUnitMdmid = 0;
                if (businessUnitMDMID > 0)
                {
                    BusinessUnitMdmid = _dbContext.MasterBusinessUnits.Where(x => x.Name == buname && x.BusinessUnitMdmid != businessUnitMDMID).Select(x => x.BusinessUnitMdmid).FirstOrDefault();

                }
                else
                {
                    BusinessUnitMdmid = _dbContext.MasterBusinessUnits.Where(x => x.Name == buname).Select(x => x.BusinessUnitMdmid).FirstOrDefault();
                }
                if (BusinessUnitMdmid > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method:- IsBusinessUnitNameExits." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion

        #region Check in mdm.MasterBusinessUnit that given T7Code is exits or not
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- check T7 code duplicated or not
        /// </summary>
        /// <param name="T7Code"></param>
        public async Task<bool> IsT7CodeExits(string T7Code)
        {
            try
            {
                int BusinessUnitMdmid = _dbContext.MasterBusinessUnits.Where(x => x.T7code == T7Code).Select(x => x.BusinessUnitMdmid).FirstOrDefault();

                if (BusinessUnitMdmid > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method:- IsT7CodeMDMExits." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion

        #region  Get master business unit data with mdm id 
        /// <summary>
        /// MDM > Manage Business Unit Master data > Edit Business Unit Master :- Edit business unit screen 
        /// </summary>
        /// <param name="businessUnitMDMID"></param>
        public async Task<ManageMasterBUDTO> GetBusinessUnitDetailByBusinessUnitMDMID(int businessUnitMDMID)
        {
            try
            {
                var getMdmBusinessUnitDetailUsingBUMDMID = _dbContext.MasterBusinessUnits.Where(e => e.BusinessUnitMdmid == businessUnitMDMID).Select(e => new ManageMasterBUDTO()
                {
                    Region = e.Region,
                    Name = e.Name,
                    BusinessUnitMDMID = e.BusinessUnitMdmid,
                    BUCode = e.Bucode,
                    Division = e.Division,
                    ModifiedBy = e.ModifiedBy,
                    ModifiedDateTime = e.ModifiedDateTime,
                    T7Code = e.T7code,
                    SourceIdentifier = e.SourceIdentifier,
                    Remarks = e.Remarks,
                }).FirstOrDefault();
                return getMdmBusinessUnitDetailUsingBUMDMID;
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method :- GetMdmBusinessUnitDetailUsingBusinessUnitMDMID." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }

        #endregion

        #region  Roll back Bu master when any error in  New BU add time
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- On save if any error come this api delete new entry from database 
        /// </summary>
        /// <param name="BusinessUnitMdmid"></param>
        public async Task<bool> RollBackSaveBusinessUnit(int BusinessUnitMdmid)
        {
            try
            {
                bool flgRollback = false;
                BusinessUnitLookup RemovesBusinessUnitLookup = _dbContext.BusinessUnitLookups.AsNoTracking()
                   .Where(e => e.BusinessUnitMdmid == BusinessUnitMdmid).FirstOrDefault();
                if (RemovesBusinessUnitLookup != null)
                {
                    _dbContext.BusinessUnitLookups.Remove(RemovesBusinessUnitLookup);
                    _dbContext.SaveChanges();

                    MasterBusinessUnit itemToRemoves = _dbContext.MasterBusinessUnits.AsNoTracking()
                    .Where(e => e.BusinessUnitMdmid == RemovesBusinessUnitLookup.BusinessUnitMdmid).FirstOrDefault();
                    if (itemToRemoves != null)
                    {
                        _dbContext.MasterBusinessUnits.Remove(itemToRemoves);
                        _dbContext.SaveChanges();

                        flgRollback = true;
                    }
                    return flgRollback;
                }
                else
                    return flgRollback;
            }
            catch (Exception ex)
            {
                logger.LogInformation("Method :- RollBackBusinessUnit." + ", StackTrace:- " + ex.StackTrace + ", Message:- " + ex.Message);
                throw ex;
            }
        }
        #endregion


    }
}
