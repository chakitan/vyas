﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API
{
    public class GetBUDataSetRecords
    {
        private readonly ILogger<GetBUDataSetRecords> _logger;
        private readonly IManageBUDataSetRecords _service;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public GetBUDataSetRecords(ILogger<GetBUDataSetRecords> log, IManageBUDataSetRecords service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            _logger = log;
            _service = service;
            _middlewareBuilder = middlewareBuilder;
        }
        /// <summary>
        /// MDM Business Unit Data Set Index screen Index screen API to get data
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of business unit data set with json string</returns>
        [FunctionName("GetLookupBusinessUnitList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the dataset. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned dataset by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned dataset by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetLookupBusinessUnitList(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getlookupbusinessunitlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request RequestData = JsonConvert.DeserializeObject<Request>(content);
                // Parse Query string parameters
                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                string date = Convert.ToString(req.Query["date"]);
                var filter = RequestData.filter;
                DateTime? modifiedDateTime = string.IsNullOrEmpty(date) ? null : DateTime.Parse(date,CultureInfo.CreateSpecificCulture("en-GB"));
                // Execute if no page or limit params available
                if (page == 0 || limit == 0)
                {
                    var data = await _service.GetLookupBusinessUnitList();
                    // Return HTTP 200 OK response with data
                    return new OkObjectResult(data);
                }
                // Execute if all params available
                else
                {
                    var data = await _service.GetLookupBusinessUnitList(filter, page, limit, sort, modifiedDateTime);
                    return new OkObjectResult(data);
                }
            }, executionContext));
        }
        /// <summary>
        /// MDM Business Unit Data Set > Waiting for Junk/Matched  Approval Index screen API to get data
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List json string</returns>
        [FunctionName("GetLookupBusinessUnitWaitingForApprovalList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the dataset. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned dataset by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned dataset by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetLookupBusinessUnitWaitingForApprovalList(
    [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getlookupbusinessunitwaitingforapprovallist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request RequestData = JsonConvert.DeserializeObject<Request>(content);
                var filter = RequestData.filter;
                if (page == 0 || limit == 0)
                {
                    var data = await _service.GetLookupBusinessUnitWaitingForApprovalList();
                    // Return HTTP 200 OK response with data
                    return new OkObjectResult(data);
                }
                // Execute if all params available
                else
                {
                    // Return HTTP 200 OK response with data
                    var data = await _service.GetLookupBusinessUnitWaitingForApprovalList(filter, page, limit, sort);
                    return new OkObjectResult(data);
                }
            }, executionContext));
        }

    }
}
