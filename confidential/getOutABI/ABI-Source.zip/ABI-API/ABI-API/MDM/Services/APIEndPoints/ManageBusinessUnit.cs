﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.APIEndPoints
{
    public class ManageBusinessUnit
    {
        private readonly ILogger<ManageBusinessUnit> logger;
        private readonly IManageMasterBusinessUnit serviceManageMasterBusinessUnit;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public ManageBusinessUnit(ILogger<ManageBusinessUnit> log, IManageMasterBusinessUnit service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            logger = log;
            serviceManageMasterBusinessUnit = service;
            _middlewareBuilder = middlewareBuilder;
        }
        #region Save Business Unit in MDM.MasterBusinessUnit

        /// <summary>
        ///MDM > Manage Business Unit Master data > Add Business Unit Master :- add or update business unit screen 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>Added new primary id of BU</returns>
        [FunctionName("SaveBusinessUnit")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "name", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "User name who is adding new BU")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> SaveBusinessUnit(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/savebusinessunit")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var name = req.Query["name"];
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                if (content != null)
                {
                    MasterBusinessUnit requestData = JsonConvert.DeserializeObject<MasterBusinessUnit>(JsonConvert.DeserializeObject<Request>(content).filter);
                    if (requestData != null)
                    {
                        var data = await serviceManageMasterBusinessUnit.SaveBusinessUnit(requestData, name);
                        return new OkObjectResult(data);

                    }
                    else
                    {
                        return new BadRequestObjectResult("Issue in data available.");
                    }
                }
                else
                {
                    return new BadRequestObjectResult("Issue in data available.");
                }
            }, executionContext));
        }

        #endregion

        #region Check in MDM.MasterBusinessUnit with BUcode in same region exits or not

        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- check business code exits in selected region
        /// </summary>
        /// <param name="region"></param>
        /// <param name="bucode"></param>
        /// <returns>bool true false</returns>
        [FunctionName("IsBusinessUnitCodeExitsInRegion")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "bucode", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Send BU code added by user to check in table")]
        [OpenApiParameter(name: "region", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Send region added by user to check in table")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> IsBusinessUnitCodeExitsInRegion(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/isbusinessunitcodeexitsinregion")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var businessUnitCode = Convert.ToString(req.Query["bucode"]);
                var region = Convert.ToString(req.Query["region"]);
                var data = await serviceManageMasterBusinessUnit.IsBusinessUnitCodeExitsInRegion(businessUnitCode, region);
                return new OkObjectResult(data);
            }, executionContext));
        }

        #endregion


        #region Check in mdm.MasterBusinessUnit that given Name is exits or not

        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- check business code name duplicated or not
        /// </summary>
        /// <param name="name"></param>
        /// <returns>bool true false</returns>
        [FunctionName("IsBusinessUnitNameExits")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "name", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Business Unit Name pass to check")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> IsBusinessUnitNameExits(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/isbusinessunitnameexits")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var name = Convert.ToString(req.Query["name"]);
                var businessUnitMDMID = Convert.ToString(req.Query["businessUnitMDMID"]);
                var data = await serviceManageMasterBusinessUnit.IsBusinessUnitNameExits(name, Convert.ToInt32(businessUnitMDMID));
                return new OkObjectResult(data);
            }, executionContext));
        }

        #endregion


        #region Check in mdm.MasterBusinessUnit that given T7Code is exits or not

        /// <summary>
        ///MDM > Manage Business Unit Master data > Add Business Unit Master :- check T7 code duplicated or not
        /// </summary>
        /// <param name="name"></param>
        /// <returns>bool true false</returns>
        [FunctionName("IsT7CodeExits")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "tcode", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "T7code pass to check exits or not")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> IsT7CodeExits(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/ist7codeexits")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var tcode = Convert.ToString(req.Query["tcode"]);
                var data = await serviceManageMasterBusinessUnit.IsT7CodeExits(tcode);
                return new OkObjectResult(data);
            }, executionContext));
        }

        #endregion

        #region  Roll back Bu master when any error in  New BU add time

        /// <summary>
        /// Roll back Bu master when any error in  New BU add time
        /// </summary>
        /// <param name="name"></param>
        /// <returns>bool true false</returns>
        [FunctionName("RollBackSaveBusinessUnit")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "businessUnitMDMId", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "businessUnitMDMId to Rollback from database table")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> RollBackSaveBusinessUnit(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/rollbacksavebusinessunit")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                string BusinessUnitMdmid = Convert.ToString(req.Query["BusinessUnitMdmid"]);
                if (!string.IsNullOrWhiteSpace(BusinessUnitMdmid))
                {
                    var data = await serviceManageMasterBusinessUnit.RollBackSaveBusinessUnit(Convert.ToInt32(BusinessUnitMdmid));
                    return new OkObjectResult(data);
                }
                else
                {
                    return new BadRequestResult();
                }
            }, executionContext));
        }

        #endregion


        

    }
}
