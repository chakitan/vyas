﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.APIEndPoints
{
    public class GetMasterPerson
    {
        private readonly ILogger<GetMasterPerson> logger;
        private readonly IManageMasterPerson serviceManageMasterPersonDataSet;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public GetMasterPerson(ILogger<GetMasterPerson> log, IManageMasterPerson service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            logger = log;
            serviceManageMasterPersonDataSet = service;
            _middlewareBuilder = middlewareBuilder;
        }

        #region Get Data from MDM.MasterPersonUnit table
        /// <summary>
        /// MDM.MasterPersonUnit table data fetch
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="page"></param>
        /// <param name="sort"></param>
        /// <param name="filter"></param>
        /// <returns>list of data in json</returns>
        [FunctionName("GetMasterPersonList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the record. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned record by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned record by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]

        public async Task<IActionResult> GetMasterPersonList(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getmasterpersonlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request requestData = JsonConvert.DeserializeObject<Request>(content);

                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                string filter = string.Empty;
                if (requestData != null)
                    filter = requestData.filter;

                if (page == 0 || limit == 0)
                {
                    var data = await serviceManageMasterPersonDataSet.GetMasterPersonList();
                    var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(data);
                    object JsonDesearlize = JsonConvert.DeserializeObject(jsonString);
                    return new OkObjectResult(JsonDesearlize);
                }
                else
                {

                    var data = await serviceManageMasterPersonDataSet.GetMasterPersonList(filter, page, limit, sort);
                    var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(data);
                    object JsonDesearlize = JsonConvert.DeserializeObject(jsonString);
                    return new OkObjectResult(JsonDesearlize);
                }
            }, executionContext));
        }

        #endregion


    }
}
