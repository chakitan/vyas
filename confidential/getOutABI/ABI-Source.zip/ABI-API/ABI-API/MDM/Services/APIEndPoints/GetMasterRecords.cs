﻿using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Civica.ABI.MDM.API.Services.Interface;
using AzureFunctions.Extensions.Middleware.Abstractions;
using AzureFunctions.Extensions.Middleware;
using ExecutionContext = Microsoft.Azure.WebJobs.ExecutionContext;

namespace Civica.ABI.MDM.API
{
    public class GetMasterRecords
    {
        private readonly ILogger<GetMasterRecords> _logger;
        private readonly IMasterRecordService _service;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public GetMasterRecords(ILogger<GetMasterRecords> log, IMasterRecordService service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            _logger = log;
            _service = service;
            _middlewareBuilder = middlewareBuilder;
        }
        /// <summary>
        /// Right Filter panel Dataset(table :- BusinessUnitLookups > SourceIdentifier) multi selection dropdown for MDM > MDM Business Unit Data Set screen
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetBusinessUnitSourceIdentifierList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetBusinessUnitSourceIdentifierList(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getbusinessunitsourceidentifierlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                // Get data from service method
                var data = await _service.GetBusinessUnitSourceIdentifierList();
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }


        /// <summary>
        /// Right Filter panel Person Dataset(table :- PersonLookups > SourceIdentifier) multi selection dropdown for MDM > MDM Person Data Set screen
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetPersonSourceIdentifierList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetPersonSourceIdentifierList(
           [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getpersonsourceidentifierlist")] HttpRequest req, ExecutionContext executionContext)
        {

            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                // Get data from service method
                var data = await _service.GetPersonSourceIdentifierList();
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }
        /// <summary>
        /// Right Filter panel WorkFlow Status(table :- WorkflowStatuses) single selection dropdown for MDM > MDM Business Unit/Person Data Set screen
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetWorkflowStatusList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetWorkflowStatusList(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getworkflowstatuslist")] HttpRequest req, ExecutionContext executionContext)
        {

            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                // Get data from service method
                var data = await _service.GetWorkflowStatusList();
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }


        /// <summary>
        /// MDM > MDM Business Unit Data Set :- in grid master business unit dropdown search call this api (table : MasterBusinessUnits)
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetMasterBusinessUnitListForMatching")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]

        public async Task<IActionResult> GetMasterBusinessUnitListForMatching(
           [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getmasterbusinessunitlistformatching")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var searchMasterBusinessUnitName = req.Query["searchMasterBusinessUnitName"];
                var data = await _service.GetMasterBusinessUnitListForMatching(searchMasterBusinessUnitName);
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }

        #region Get source and region from database and return as json string 
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master :- source and region dropdown bind ETL data with this api
        /// </summary>
        /// <returns>list of data in json</returns>
        [FunctionName("GetETLSourceSystemRegionList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetETLSourceSystemRegionList(
           [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getetlsourcesystemregionlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var data = await _service.GetETLSourceSystemRegionList();
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(data);
                object jsonDesearlize = JsonConvert.DeserializeObject(jsonString);
                return new OkObjectResult(jsonDesearlize);
            }, executionContext));
        }
        #endregion



    }
}
