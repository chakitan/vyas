﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.APIEndPoints
{
    public class WorkFlowStatusChanges
    {
        private readonly ILogger<WorkFlowStatusChanges> _logger;
        private readonly IWorkFlowStatusChangesService _service;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public WorkFlowStatusChanges(ILogger<WorkFlowStatusChanges> log, IWorkFlowStatusChangesService service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            _logger = log;
            _service = service;
            _middlewareBuilder = middlewareBuilder;
        }
        /// <summary>
        /// MDM > MDM Person/Business Unit Data Set :- on grid dropdown selected value update in database with status waiting for match approval
        /// </summary>
        /// <param name="req"></param>
        /// <param name="id"></param>
        /// <param name="executionContext"></param>
        /// <returns>Update record id</returns>
        [FunctionName("MatchLookupRecordByEntityName")]
        [OpenApiOperation(operationId: "MatchLookupRecordByEntityName", tags: new[] { "name" })]
        [OpenApiParameter(name: "id", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to get primary record to update status.")]
        [OpenApiParameter(name: "value", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to update status with selected value in table")]
        [OpenApiParameter(name: "type", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Which page type request in this")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> MatchLookupRecordByEntityName(
            [HttpTrigger(AuthorizationLevel.Function, "put", Route = "v1/matchlookuprecordbyentityname/{id?}")] HttpRequest req, int id, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var type = req.Query["type"];
                var value = req.Query["value"];
                var name = req.Query["name"];
                // Get data from service method
                var data = await _service.MatchLookupRecordByEntityName(id, type, value, name);
                return new OkObjectResult(data);
            }, executionContext));
        }
        /// <summary>
        /// Update status as button click like : junk , match , no master  pass action name and update In database
        /// </summary>
        /// <param name="req"></param>
        /// <param name="id"></param>
        /// <param name="executionContext"></param>
        /// <returns>Update record id</returns>
        [FunctionName("UpdateWorkFlowStatusByEntityName")]
        [OpenApiOperation(operationId: "UpdateWorkFlowStatusByEntityName", tags: new[] { "name" })]
        [OpenApiParameter(name: "id", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "primary id to update selected value in table.")]
        [OpenApiParameter(name: "type", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "page type which call from")]
        [OpenApiParameter(name: "action", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "action which is perform in page")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> UpdateWorkFlowStatusByEntityName(
            [HttpTrigger(AuthorizationLevel.Function, "put", Route = "v1/updateworkflowstatusbyentityname/{id?}")] HttpRequest req, int id, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var type = req.Query["type"];
                var action = req.Query["action"];
                var name = req.Query["name"];
                // Get data from service method
                var data = await _service.UpdateWorkFlowStatusByEntityName(id, type, action, name);
                return new OkObjectResult(data);
            }, executionContext));
        }

        /// <summary>
        /// Update wotk flow status as reject in Business unit and person aprroval screen 
        /// </summary>
        /// <param name="req"></param>
        /// <param name="id"></param>
        /// <param name="executionContext"></param>
        /// <returns>Update record id</returns>
        [FunctionName("RejectLookupRecordByEntityName")]
        [OpenApiOperation(operationId: "RejectLookupRecordByEntityName", tags: new[] { "name" })]
        [OpenApiParameter(name: "id", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "primary id to update selected value in table.")]
        [OpenApiParameter(name: "type", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "page type which call from")]
        [OpenApiParameter(name: "action", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "action which is perform in page")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> RejectLookupRecordByEntityName(
            [HttpTrigger(AuthorizationLevel.Function, "put", Route = "v1/rejectlookuprecordbyentityname/{id?}")] HttpRequest req, int id, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var remarks = req.Query["remarks"];
                if (!string.IsNullOrEmpty(remarks))
                    remarks = remarks.ToString().Replace("§", "#").Replace("¿", "&");
                var action = req.Query["action"];
                var type = req.Query["type"];
                var name = req.Query["name"];
                // Get data from service method
                var data = await _service.RejectLookupRecordByEntityName(id, remarks, action, type, name);
                return new OkObjectResult(data);
            }, executionContext));
        }

    }
}
