using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Civica.ABI.MDM.API.Services.Interface;
using AzureFunctions.Extensions.Middleware.Abstractions;
using AzureFunctions.Extensions.Middleware;

namespace Civica.ABI.MDM.API.API
{
    public class GetFailedRecordCount
    {
        private readonly ILogger<GetFailedRecordCount> _logger;
        private readonly IFailedRecordService _service;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public GetFailedRecordCount(ILogger<GetFailedRecordCount> log, IFailedRecordService service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            _logger = log;
            _service = service;
            _middlewareBuilder = middlewareBuilder;
        }
        /// <summary>
        /// View failed record data and table list in grid with count
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetFailedRecordList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "sn", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to get schemaname wise failed records.")]
        [OpenApiParameter(name: "search", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to Search filter value")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetFailedRecordList(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getfailedrecordlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var search = req.Query["search"];
                var schemaname = req.Query["sn"];
                // Get data from service method
                var data = await _service.GetFailedRecordList(schemaname, search);
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }
        /// <summary>
        /// View failed record export button handle
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("ExportFailedRecordListByEntityName")]
        [OpenApiOperation(operationId: "RunExport", tags: new[] { "name" })]
        [OpenApiParameter(name: "sn", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to get schemaname wise failed records.")]
        [OpenApiParameter(name: "tn", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to export table name wise data")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> ExportFailedRecordListByEntityName(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/exportfailedrecordlistbyentityname")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var tableName = req.Query["tn"];
                var schemaName = req.Query["sn"];
                // Get data from service method
                var data = await _service.ExportFailedRecordListByEntityName(schemaName, tableName);
                // Return HTTP 200 OK response with JSON serialized data
                return new OkObjectResult(data);
            }, executionContext));
        }


    }
}

