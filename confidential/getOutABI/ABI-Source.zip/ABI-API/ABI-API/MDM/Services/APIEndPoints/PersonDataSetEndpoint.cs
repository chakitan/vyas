﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services
{
    public class PersonDataSetEndpoint
    {
        private readonly ILogger<PersonDataSetEndpoint> _logger;
        private readonly IManagePersonDataSet _service;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public PersonDataSetEndpoint(ILogger<PersonDataSetEndpoint> log, IManagePersonDataSet service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            _logger = log;
            _service = service;
            _middlewareBuilder = middlewareBuilder;
        }
        /// <summary>
        /// MDM > MDM Person Data Set :- person dataset list screen index grid to bind
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>list of string json</returns>
        [FunctionName("GetLookupPersonList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the dataset. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned dataset by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned dataset by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetLookupPersonList(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getlookuppersonlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request RequestData = JsonConvert.DeserializeObject<Request>(content);
                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                string date = Convert.ToString(req.Query["date"]);
                var filter = RequestData.filter;
                DateTime? modifiedDateTime = string.IsNullOrEmpty(date) ? null : DateTime.Parse(date, CultureInfo.CreateSpecificCulture("en-GB"));
                // Execute if no page or limit params available
                if (page == 0 || limit == 0)
                {
                    var data = await _service.GetLookupPersonList();
                    // Return HTTP 200 OK response with data
                    return new OkObjectResult(data);
                }
                // Execute if all params available
                else
                {
                    // Return HTTP 200 OK response with data
                    var data = await _service.GetLookupPersonList(filter, page, limit, sort, modifiedDateTime);
                    return new OkObjectResult(data);
                }
            }, executionContext));
        }

        /// <summary>
        /// MDM > MDM Person Data Set :- person dataset list screen index grid dropdown of master person bind
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetMasterPersonListForMatching")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetMasterPersonListForMatching(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getmasterpersonlistformatching")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var search = req.Query["search"];
                var data = await _service.GetMasterPersonListForMatching(search);
                // Return HTTP 200 OK response with data
                return new OkObjectResult(data);
            }, executionContext));
        }

        /// <summary>
        /// MDM > MDM Person Data Set > Waiting for Matched Approval : list of approval matched/junk grid bind with this api
        /// </summary>
        /// <param name="req"></param>
        /// <param name="executionContext"></param>
        /// <returns>List of json string</returns>
        [FunctionName("GetLookupPersonWaitingForApprovalList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the dataset. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned dataset by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned dataset by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetLookupPersonWaitingForApprovalList(
    [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getlookuppersonwaitingforapprovallist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request RequestData = JsonConvert.DeserializeObject<Request>(content);
                var filter = RequestData.filter;
                // Execute if no page or limit params available
                if (page == 0 || limit == 0)
                {
                    var data = await _service.GetLookupPersonWaitingForApprovalList();
                    // Return HTTP 200 OK response with data
                    return new OkObjectResult(data);
                }
                // Execute if all params available
                else
                {
                    // Return HTTP 200 OK response with data
                    var data = await _service.GetLookupPersonWaitingForApprovalList(filter, page, limit, sort);
                    return new OkObjectResult(data);
                }
            }, executionContext));
        }


    }
}