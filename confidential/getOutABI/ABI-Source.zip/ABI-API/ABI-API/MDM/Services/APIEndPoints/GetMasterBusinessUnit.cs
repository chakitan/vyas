﻿using AzureFunctions.Extensions.Middleware;
using AzureFunctions.Extensions.Middleware.Abstractions;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Services.APIEndPoints
{
    public class GetMasterBusinessUnit
    {
        private readonly ILogger<GetMasterBusinessUnit> logger;
        private readonly IManageMasterBusinessUnit serviceManageMasterBusinessUnit;
        private readonly IHttpMiddlewareBuilder _middlewareBuilder;

        public GetMasterBusinessUnit(ILogger<GetMasterBusinessUnit> log, IManageMasterBusinessUnit service, IHttpMiddlewareBuilder middlewareBuilder)
        {
            logger = log;
            serviceManageMasterBusinessUnit = service;
            _middlewareBuilder = middlewareBuilder;
        }
        #region Get Data from MDM.MasterBusinessUnit table

        /// <summary>
        /// MDM > Add/View Business Unit Master data Index screen to load data and bind in grid
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="page"></param>
        /// <param name="sort"></param>
        /// <param name="filter"></param>
        /// <returns>list of data in json</returns>
        [FunctionName("GetMasterBusinessUnitList")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "limit", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to limit the number of records returned for a given page. Required for paging to work.")]
        [OpenApiParameter(name: "page", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to select a specific page of the record. Requires the 'limit' query string param.")]
        [OpenApiParameter(name: "sort", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to sort the returned record by a specific column(s).")]
        [OpenApiParameter(name: "filter", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Used to filter the returned record by specific column(s) & value(s).")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetMasterBusinessUnitList(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/getmasterbusinessunitlist")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request requestData = JsonConvert.DeserializeObject<Request>(content);
                var limit = Convert.ToInt32(req.Query["limit"]);
                var page = Convert.ToInt32(req.Query["page"]);
                var sort = req.Query["sort"];
                string filter = string.Empty;
                if (requestData != null)
                    filter = requestData.filter;
                if (page == 0 || limit == 0)
                {
                    var data = await serviceManageMasterBusinessUnit.GetMasterBusinessUnitList();
                    return new OkObjectResult(data);
                }
                else
                {

                    var data = await serviceManageMasterBusinessUnit.GetMasterBusinessUnitList(filter, page, limit, sort);
                    return new OkObjectResult(data);
                }
            }, executionContext));
        }
        #endregion


        #region Auto Generate BusinessUnit Code from MDM.MasterBusinessUnit table
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master Click on link to create new Business unit code 
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="page"></param>
        /// <param name="sort"></param>
        /// <param name="filter"></param>
        /// <returns>string of data in json</returns>
        [FunctionName("AutoGenerateBusinessUnitCode")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "region", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Send region added by user to check in table")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetAutoGenerateBusinessUnitCode(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/autogeneratebusinessunitcode")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request requestData = JsonConvert.DeserializeObject<Request>(content);
                var region = Convert.ToString(req.Query["region"]);
                var data = await serviceManageMasterBusinessUnit.AutoGenerateBusinessUnitCode(region);
                return new OkObjectResult(data);
            }, executionContext));
        }

        #endregion

        #region Auto T7 generate from MDM.MasterBusinessUnit table
        /// <summary>
        /// MDM > Manage Business Unit Master data > Add Business Unit Master Click on link to create new T7Code
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="page"></param>
        /// <param name="sort"></param>
        /// <param name="filter"></param>
        /// <returns>string of data in json</returns>
        [FunctionName("AutoGenerateT7Code")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetAutoGenerateT7Code(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/autogeneratet7code")] HttpRequest req, ExecutionContext executionContext)
        {

            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request requestData = JsonConvert.DeserializeObject<Request>(content);
                var data = await serviceManageMasterBusinessUnit.AutoGenerateT7Code();
                return new OkObjectResult(data);
            }, executionContext));
        }

        #endregion

        #region Check in MDM.MasterBusinessUnit with BUcode in same region exits or not
        /// <summary>
        /// MDM > Manage Business Unit Master data > Edit Business Unit Master :- Edit business unit screen 
        /// </summary>
        /// <param name="region"></param>
        /// <param name="bucode"></param>
        /// <returns>bool true false</returns>
        [FunctionName("GetBusinessUnitDetailByBusinessUnitMDMID")]
        [OpenApiOperation(operationId: "Run", tags: new[] { "name" })]
        [OpenApiParameter(name: "bucode", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Send BU code added by user to check in table")]
        [OpenApiParameter(name: "businessUnitMDMID", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Send region added by user to check in table")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
        public async Task<IActionResult> GetBusinessUnitDetailByBusinessUnitMDMID(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/getbusinessunitdetailbybusinessunitmdmid")] HttpRequest req, ExecutionContext executionContext)
        {
            return await _middlewareBuilder.ExecuteAsync(new HttpMiddleware(async (httpContext) =>
            {
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                Request requestData = JsonConvert.DeserializeObject<Request>(content);
                int businessUnitMDMID = Convert.ToInt32(req.Query["businessUnitMDMID"]);
                var data = await serviceManageMasterBusinessUnit.GetBusinessUnitDetailByBusinessUnitMDMID(businessUnitMDMID);
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(data);
                object JsonDesearlize = JsonConvert.DeserializeObject(jsonString);
                return new OkObjectResult(JsonDesearlize);
            }, executionContext));
        }

        #endregion

    }
}
