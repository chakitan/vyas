﻿using Civica.ABI.MDM.API.DTO;
using Civica.ABI.MDM.API.Model;
using Civica.ABI.MDM.API.Services.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Civica.ABI.MDM.API.Services
{
    public class FailedRecordService : IFailedRecordService
    {
        private readonly ILogger<FailedRecordService> _logger;
        private readonly MDMDbContext _dbContext;

        private const string STORED_PROCEDURE_FOR_FAILED_RECORD_EXPORT = "usp_FetchBlockedRecordsBySourceAndTableName";
        private const string PARAMETER_TABLE_NAME_FOR_FAILED_RECORD_EXPORT = "TableName";
        private const string PARAMETER_SCHEMA_NAME__FOR_FAILED_RECORD_EXPORT = "SchemaName";

        public FailedRecordService(ILogger<FailedRecordService> log, MDMDbContext dbContext)
        {
            this._logger = log;
            this._dbContext = dbContext;
        }

        /// <summary>
        /// Export blocked records from staging by schema and table name
        /// </summary>
        /// <param name="schemaName">Schema name</param>
        /// <param name="tableName">Table name</param>
        /// <returns>List of blocked records</returns>
        public Task<DataTable> ExportFailedRecordListByEntityName(string schemaName, string tableName)
        {
            try
            {
                using (var connection = this._dbContext.Database.GetDbConnection())
                {
                    var command = connection.CreateCommand();
                    command.CommandText = STORED_PROCEDURE_FOR_FAILED_RECORD_EXPORT;
                    command.CommandType = CommandType.StoredProcedure;
                    // Setting command timeout to 3 Minutes 
                    command.CommandTimeout = 60 * 3;
                    command.Parameters.Add(new SqlParameter(PARAMETER_SCHEMA_NAME__FOR_FAILED_RECORD_EXPORT, schemaName));
                    command.Parameters.Add(new SqlParameter(PARAMETER_TABLE_NAME_FOR_FAILED_RECORD_EXPORT, tableName));
                    connection.Open();
                    using (var result = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(result);
                        return System.Threading.Tasks.Task.FromResult(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// View failed record data and table list in grid with count
        /// </summary>
        /// <param name="schemaname"></param>
        /// <param name="search"></param>
        public async Task<List<FailedRecordCountDTO>> GetFailedRecordList(string schemaname = null, string search = null)
        {
            try
            {
                // Execute Stored Proc to get failed record counts
                _dbContext.Database.SetCommandTimeout(120);
                var query = await System.Threading.Tasks.Task.FromResult(

                    _dbContext.Usp_FetchBlockedRecordCounts.FromSqlRaw("Exec dbo.usp_FetchBlockedRecordCountForEachSourceTable").ToList());

                if (string.IsNullOrEmpty(schemaname))
                {
                    // Map data returned from stored proc to DTO record class
                    var dto = query.GroupBy(l => l.SchemaName).Select(p => new FailedRecordCountDTO
                    {
                        SchemaName = p.First().SchemaName,
                        TableName = p.First().TableName,
                        BlockedRecordCount = p.Sum(c => c.BlockedRecordCount),
                    }).OrderBy(l => l.SchemaName);
                    // return mapped data as a list type
                    return dto.ToList();
                }
                else
                {
                    // Map data returned from stored proc to DTO record class
                    var dto = query.Where(l => l.SchemaName == schemaname
                    && (!String.IsNullOrWhiteSpace(search) ? l.TableName.ToLower().Contains(search.Trim().ToLower()) : true)
                    ).Select(p => new FailedRecordCountDTO
                    {
                        SchemaName = p.SchemaName,
                        TableName = p.TableName,
                        BlockedRecordCount = p.BlockedRecordCount,
                    }).OrderBy(l => l.TableName);
                    // return mapped data as a list type
                    return dto.ToList();
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }
    }
}
