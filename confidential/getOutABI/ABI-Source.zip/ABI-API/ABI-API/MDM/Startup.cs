﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Civica.ABI.MDM.API.Services.Interface;
using Civica.ABI.MDM.API.Services;
using Civica.ABI.MDM.API.Model;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Civica.ABI.MDM.API.Middlewares;
using AzureFunctions.Extensions.Middleware.Abstractions;
using AzureFunctions.Extensions.Middleware.Infrastructure;

[assembly: FunctionsStartup(typeof(Civica.ABI.MDM.API.Startup))]

namespace Civica.ABI.MDM.API
{
    public class Startup : FunctionsStartup
    {
        public IConfiguration Configuration { get; }
        public IHostingEnvironment environment { get; set; }
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddHttpContextAccessor();
            builder.Services.AddDbContext<MDMDbContext>(options =>
            {
                var serviceProvider = builder.Services.BuildServiceProvider();
                var env = serviceProvider.GetService<IHttpContextAccessor>()?.HttpContext?.Request?.Headers["x-environment"];
                var connectionString = GetSQLConnectionString("SqlConnectionString", env);
                options.UseSqlServer(connectionString);
            });
            builder.Services.AddTransient<IMasterRecordService, MasterRecordService>();
            builder.Services.AddTransient<IFailedRecordService, FailedRecordService>();
            builder.Services.AddTransient<IManagePersonDataSet, ManagePersonDataSetService>();
            builder.Services.AddTransient<IManageBUDataSetRecords, ManageBUDataSetDataService>();
            builder.Services.AddTransient<IWorkFlowStatusChangesService, WorkFlowStatusChangesService>();
            builder.Services.AddTransient<IManageMasterBusinessUnit, ManageMasterBusinessUnit>();
            builder.Services.AddTransient<IManageMasterPerson, ManageMasterPerson>();

            // Register middleware using MiddlewareBuilder
            builder.Services.AddTransient<IHttpMiddlewareBuilder, HttpMiddlewareBuilder>((serviceProvider) =>
            {
                var funcBuilder = new HttpMiddlewareBuilder(serviceProvider.GetRequiredService<IHttpContextAccessor>());
                funcBuilder.Use(new ExceptionHandlingMiddleware(serviceProvider.GetService<ILogger<ExceptionHandlingMiddleware>>()));
                return funcBuilder;
            });

        }

        //  Azure Functions app service has a different naming convention than local
        //  for connection strings.  Therefore we use the method below to
        //  grab the appropiate environmental variable connection string.
        //  * When we pick up new story for dynamic connection strings, will
        //  * we need to make changes to this method.
        public static string GetSQLConnectionString(string name, string environment)
        {
            // Local app settings naming convention
            string conStr = System.Environment.GetEnvironmentVariable($"ConnectionStrings:{name}", EnvironmentVariableTarget.Process);
            if (string.IsNullOrEmpty(conStr))
                // Azure Functions App Service naming convention
                conStr = System.Environment.GetEnvironmentVariable($"SQLAZURECONNSTR_{name}-{environment}", EnvironmentVariableTarget.Process);
            return conStr;
        }
    }
}
