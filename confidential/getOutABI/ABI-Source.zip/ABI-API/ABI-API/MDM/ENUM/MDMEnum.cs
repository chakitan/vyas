﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.ENUM
{
    public class MDMEnum
    {
        public  enum PageType
        {
            BU=1,
            Person = 2
        }
    }
}
