﻿using AzureFunctions.Extensions.Middleware.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.Middlewares
{
    /// <summary>
    /// Middleware to for handling global exception
    /// </summary>
    public class ExceptionHandlingMiddleware : HttpMiddlewareBase
    {
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger">DI for logging</param>
        public ExceptionHandlingMiddleware(ILogger<ExceptionHandlingMiddleware> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// All end point request will first invoke this method
        /// </summary>
        /// <param name="context">HTTP Context</param>
        /// <returns></returns>
        public override async Task InvokeAsync(HttpContext context)
        {
            try
            {
                // Log with function name before request processing starts
                _logger.LogInformation($"{this.ExecutionContext.FunctionName} Request triggered");
                // Pass request to next middleware/actual end point
                await this.Next.InvokeAsync(context);
                // Log with function name after request processing ends
                _logger.LogInformation($"{this.ExecutionContext.FunctionName} Request processed without any exceptions");
            }
            catch (Exception ex)
            {
                // Log exception with function name on exception
                _logger.LogError("Unexpected Error in {0}: {1}", ExecutionContext.FunctionName, ex.Message);
                // Send 500 error code in response
                // TODO : Implement detailed response handling based on type of exception
                context.Response.StatusCode = 500;
                await context.Response.WriteAsync($"{this.ExecutionContext.FunctionName} request failed, Please try again");

            }
        }
    }
}
