﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.DTO
{
    public class ManageBUDataSetListDTO
    {
        public int CurrentPage { get; init; }
        public int TotalPages { get; init; }
        public int TotalItems { get; init; }
        public List<ManageBUDataSetDTO> Items { get; init; }
    }
}
