﻿using System.Collections.Generic;

namespace Civica.ABI.MDM.API.DTO
{
    public record ManagePeronDataSetListDTO
    {
        public int CurrentPage { get; init; }
        public int TotalPages { get; init; }
        public int TotalItems { get; init; }
        public List<ManagePersonDataSetDTO> Items { get; init; }
    }
}
