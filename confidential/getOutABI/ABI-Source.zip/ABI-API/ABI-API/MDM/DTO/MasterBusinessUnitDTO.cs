﻿using Civica.ABI.MDM.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.DTO
{
    public record MasterBusinessUnitDTO
    {
        public int CurrentPage { get; init; }
        public int TotalPages { get; init; }
        public int TotalItems { get; init; }
        public List<MasterBusinessUnit> Items { get; init; }
    }
}
