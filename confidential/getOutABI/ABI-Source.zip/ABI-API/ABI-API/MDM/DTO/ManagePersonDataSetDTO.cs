﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.DTO
{
    public  class ManagePersonDataSetDTO
    {
        public int PersonLookupId { get; set; }
        public int? PersonMdmid { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string EmployeeId { get; set; }
        public string BusinessUnitName { get; set; }
        public string CostCentre { get; set; }
        public string SourceIdentifier { get; set; }
        public Guid RunId { get; set; }
        public int? WorkflowStatusId { get; set; }
        public string WorkflowStatusName { get; set; }
        public string Remarks { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }
        public string PersonName { get; set; }
         

    }
}
