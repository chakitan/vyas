﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.DTO
{
    public record AllocationDTO
    {
        public int Id { get; set; }
        public int? ResourceId { get; set; }
        public int BusinessUnitId { get; set; }
        public int ProjectId { get; set; }
        public DateTime? EditedDate { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DeletedDateTime { get; set; }
        public int RoleId { get; set; }
        public string RoleDescription { get; set; }
        public int StatusId { get; set; }
        public string StatusDescription { get; set; }
        public int? ChargeTypeId { get; set; }
        public string ChargeTypeDescription { get; set; }
        public string SourceIdentifier { get; set; }
        public DateTime ExtractDate { get; set; }
        public string ValidationComment { get; set; }
    }
}
