﻿namespace Civica.ABI.MDM.API.DTO
{
    // DTO class to return data relating to the number of records 
    // which have failed within the MDM system.
    public record FailedRecordCountDTO
    {
        public string SchemaName { get; set; }
        public string TableName { get; set; }
        public int BlockedRecordCount { get; set; }
    }
}
