﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Civica.ABI.MDM.API.DTO
{
    public class ManageMasterBUDTO
    {
        public int BusinessUnitMDMID { get; set; }
        public string Name { get; set; }
        public string Division { get; set; }
        public string BUCode { get; set; }
        public string Region { get; set; }
        public string T7Code { get; set; }
        public string SourceIdentifier { get; set; }
        public bool IsDeleted { get; set; }
        public string Remarks { get; set; }
        public DateTime ModifiedDateTime { get; set; }
        public string ModifiedBy { get; set; }

    }
}
