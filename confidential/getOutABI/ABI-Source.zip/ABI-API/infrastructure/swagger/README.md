# Introduction 

## Folder Structure
<br> |- swagger 
  - |- environments
    - |-nonprod.......................for non prod env (dev, test, devint)
    - |-prod..........................for prod env (uat, preprod, prod)
    - |-devops........................for devops purpose only
  - |- System.......................for runtime usage by scripts and bicep template only
    - |- Original
    - |- newversion

> folder environments
  >> _Every environment 's sub-folder contains `swagger.json.template` to add/ edit the changes_ 

> folder *System* 
  >> sub folders *Original* & *newversion* are used by scripts on runtime for deployment and contains empty swagger.json files _DO NOT add anything in these folders_
 
> Remember: you can create multiple version folders for different new versions but can only deploy one at a time.

## Adding new version
Let's suppose you want to create a new API version called 'v1'
1. Add a sub-folder, named same as the version name you want to create, under the respective environment folder. In this case 'v1'
   - _like: swagger/environments/nonprod/v1/_ | _swagger/environments/prod/v1/_
2. Create a new file named 'swagger.json.template' under the version folder 
   - _like: v1/swagger.json.template_
  
   - Contents of swagger.json.template are OpenAPI standards. Make sure the swagger.json.template file is compatible with ABI template --> [Ref.](#swagger-file-structure) | For full template schema [Click Here](#full-swagger-schema-file)
   
3. Run the release pipeline and make sure you add same name as the new version to variable `api_version_name`. In this case v1

> folder *Original* contains the original set of API swagger. The files remain same swagger.json & swagger.json.template so their schema. The only change is the set of Paths of actual API operations


## Swagger File Structure
* ABI API making use of OpenAPI v_3.0 for creating API Operations | [Refer](https://spec.openapis.org/oas/v3.0.1) | Full Schema

* Below snippets demonstrates the Swagger file schema used in ABI.

### Header
- Header hold some OAS Objects such as 
  - OpenAPI Version: 3.0.1 is the version ABI API making use of (as of SEP'22)
  - info: metadata of API like title, description and version
  - servers: states the base url
- Please Keep the Header as shown below in all swagger.json.template files
> 'envType' token in the header part is replaced at runtime based on the environment :: DO NOT MODIFY IT
- Do not modify anything unless project requirement
- Snippet
```
{
  "openapi": "3.0.1",
  "info": {
      "title": "MDM envType",
      "description": "Import from \"az-mdm-envType\" Function App",
      "version": "1.0"
  },
  "servers": [{
      "url": "https://apim-api-envType.azure-api.net"
  }]
  _// all other properties as shown ## Full Swagger Schema File_
}
```

### Path
- Paths object of a swagger file contains the actual operation definitions
- You can Add multiple operations with specified property and features here. Just append/ edit to the "paths" 
- Snippet
```
{
// header as mentioned ## Header
"paths": {
        "/ingestion/master/personrlst": {
            "get": {
                "summary": "GetPersonRecords",
                "operationId": "get-getpersonrecords",
                "responses": {
                    "200": {
                        "description": null
                    }
                }
            }
        },
        "/v1/ingestion/updateworkflowstatusbyrejectaction/{id}": {
            "put": {
                "summary": "UpdateWorkFlowStatusByRejectAction",
                "operationId": "put-updateworkflowstatusbyrejectaction",
                "parameters": [
                    {
                        "name": "id",
                        "in": "path",
                        "required": true,
                        "schema": {
                            "type": ""
                        }
                    }
                ],
                "responses": {
                    "200": {
                        "description": null
                    }
                }
            }
        }
    }
    // all other properties as shown ## Full Swagger Schema File
}
```

### Component 
- Components object holds a set of reusable objects of OpenAPI specification
- These objects should also be explicitly referenced from properties outside the components object in order to work (in ABI's case it's Security Scheme)
- Snippet
```
{
    // header as mentioned ## Header
    // path as mentioned ## Path
    "components": {
      "securitySchemes": {
          "apiKeyHeader": {
              "type": "apiKey",
              "name": "Ocp-Apim-Subscription-Key",
              "in": "header"
            },
          "apiKeyQuery": {
              "type": "apiKey",
              "name": "subscription-key",
              "in": "query"
            }
        }
    }
    // all other properties as shown ## Full Swagger Schema File
}
```

### Security
- Defines a security scheme that can be used by the operations
- These are explicitly declared but not defined here
- Snippet
```
{
    "security": [{
      "apiKeyHeader": []
  }, {
      "apiKeyQuery": []
  }]
}
```


## Full Swagger Schema File
```
{
  "openapi": "3.0.1",
  "info": {
      "title": "MDM envType",
      "description": "Import from \"az-mdm-envType\" Function App",
      "version": "1.0"
  },
  "servers": [{
      "url": "https://apim-api-envType.azure-api.net"
  }],
  "paths": {
        "/ingestion/master/personrlst": {
            "get": {
                "summary": "GetPersonRecords",
                "operationId": "get-getpersonrecords",
                "responses": {
                    "200": {
                        "description": null
                    }
                }
            }
        },
        "/v1/ingestion/updateworkflowstatusbyrejectaction/{id}": {
            "put": {
                "summary": "UpdateWorkFlowStatusByRejectAction",
                "operationId": "put-updateworkflowstatusbyrejectaction",
                "parameters": [
                    {
                        "name": "id",
                        "in": "path",
                        "required": true,
                        "schema": {
                            "type": ""
                        }
                    }
                ],
                "responses": {
                    "200": {
                        "description": null
                    }
                }
            }
        }
    },
     "components": {
      "securitySchemes": {
          "apiKeyHeader": {
              "type": "apiKey",
              "name": "Ocp-Apim-Subscription-Key",
              "in": "header"
          },
          "apiKeyQuery": {
              "type": "apiKey",
              "name": "subscription-key",
              "in": "query"
          }
      }
  },
  "security": [{
      "apiKeyHeader": []
  }, {
      "apiKeyQuery": []
  }]
}
```