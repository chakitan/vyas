<#
.SYNOPSIS
    Deploy Infrastructure

.DESCRIPTION
    Deploys the required API resources.
    Read README.md to know more

.PARAMETER Environment
    The environment type e.g. prod/ nonprod/ devops

.NOTES
    Change Log: JAN'22 - Created
                FEB'22 - param change to envType
                SEP'22 - APIM API Version + Logging Added
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $envType = "devops",
    $api_version_name = 'v1',
    $api_revision_id = '1',
    $api_revision_description = 'latest revision',
    $releaseName,
    $releaseRequester
)

try{  
    # Read the Core Parameters
    $apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json
    
    # Start Creating Infra
    Write-Host "##[debug] Creating Resources" -ForegroundColor DarkCyan
    az deployment group create `
    -g $apiPara.parameters.resourceGroup_name.value `
    -f $PSScriptRoot\templates\main.bicep `
    -p $PSScriptRoot\parameters\environments\$envType\api-parameters.json `
    -p apim_api_version_name=$api_version_name apim_api_revision_id=$api_revision_id apim_api_revision_description=$api_revision_description `
    tag_releaseName="$releaseName" tag_releaseRequester="$releaseRequester"
}
catch{
    Write-Host "##[error] Error Received:: $Error[0]" -ForegroundColor Red
}


