<#
    .SYNOPSIS
    Configure-FunctionApp.ps1

    .DESCRIPTION
    * Configure FunctionApp Connection String
            
    .NOTES
    Change Log: MAR'22 Created
                SEP'22 - Logging Added
#>

[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $envType = 'devops'
)

# Pull parameters from file.
Write-Host "##[debug] Pulling variables from parameter files." -ForegroundColor DarkCyan
$apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json
if($envType -eq 'devops' -or $envType -eq 'nonprod'){
    $script:subscriptionId = "e7358970-3147-4aa1-8863-49325228dd7d"
    $script:envArr = @('dev','devint','test')
}
elseif($envType -eq 'prod') {
    $script:subscriptionId = "023064ea-ee87-4a4b-88ef-ed9b69548090" 
    $script:envArr = @('preprod','prod','uat')
}
else {
    Write-Host "##[info] Env Type is Incorrect" -ForegroundColor Magenta
    exit
}


# Get the access token
Write-Host "##[debug] Generating Token" -ForegroundColor DarkCyan
$token = az account get-access-token --query accessToken --output tsv

# Configure Connection string
try{
    $bodyConStng = "{'kind':'KeyVaultReference','properties': {'connectionStrings': ["+$(foreach($environ in $envArr){"{'name': 'SqlConnectionString-$($environ.ToUpper())',`n
    'connectionString': '@Microsoft.KeyVault(SecretUri=https://$($apiPara.parameters.vault_name.value)/secrets/SqlConnectionString-$($environ)/)',`n
    'type': 'SQLAzure'},"})+"]}}"
    $bodyConStng = ($bodyConStng) -replace ("\,]}}","]}}")
    $bodyConStng = ($bodyConStng) -replace ("`'","`"")

    $requestConnStng = @{
      Method = 'PUT'
      Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($apiPara.parameters.resourceGroup_name.value)/providers/Microsoft.Web/sites/$($apiPara.parameters.functionApp_name.value)/config/web?api-version=2021-02-01"
      Headers = @{
          Authorization = "Bearer $($token)"
      }
      ContentType = 'application/json'
      Body = $bodyConStng
    }
    
    Write-Host "##[debug] Configuring FunctionApp" -ForegroundColor DarkCyan
    Invoke-RestMethod @requestConnStng     
}
catch{
    Write-Host "##[error] Configure FunctionApp :: Caught Error $Error[0]" -ForegroundColor Red
    Write-Host "##[error] StatusCode:" $_.Exception.Response.StatusCode.value__ -ForegroundColor Red
    Write-Host "##[warning] $($_.Exception)" -ForegroundColor Yellow
}
