<#
.SYNOPSIS
    Validate Infrastructure

.DESCRIPTION
    Validates the Infrastructure (resource) deployment.
    Read README.md to know more

.PARAMETER envType
    The environment type e.g. prod/ nonprod/ devops

.NOTES
    Change Log: SEP'22 - Created
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $envType = "nonprod",
    $api_version_name = 'v2',
    $api_revision_id = '1',
    $api_revision_description = 'latest revision'
)

try{  
    # Read the Core Parameters
    $apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json
    
    # Start Validation
    Write-Host "##[debug] Validating the Deployment" -ForegroundColor DarkCyan
    az deployment group validate `
    -g $apiPara.parameters.resourceGroup_name.value `
    -f $PSScriptRoot\templates\main.bicep `
    -p $PSScriptRoot\parameters\environments\$envType\api-parameters.json `
    -p apim_api_version_name=$api_version_name apim_api_revision_id=$api_revision_id apim_api_revision_description=$api_revision_description `
    tag_releaseName="$releaseName" tag_releaseRequester="$releaseRequester" `
    --no-prompt -n "ValidationDeployment${env:BUILD_BUILDID}"
}
catch{
    Write-Host "##[error] Error Received:: $Error[0]" -ForegroundColor Red
}


