<#
    .SYNOPSIS
    Configure-VaultSecrets.ps1

    .DESCRIPTION
    * Configure KeyVault Access Pollicies
        1. Function App
        2. API Management Service
    * Generate Keys & Set Secrets
        Function Host Keys
    
    .NOTES
    Change Log: JAN'22 Created
                FEB'22 - envType Condition added
                MAR'22 - LoggerCredential Secret removed
                SEP'22 - Logging Added
#>

[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $envType = 'devops'
)

# Pull parameters from file.
Write-Host "##[debug] Pulling variables from parameter files." -ForegroundColor DarkCyan
$apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json
# Param from Pipeline
$servicePrincipal = $env:servicePrincipalId

# Configure KeyVault Access Pollicies
try{
    # Getting the function app details to an object in JSON form
    Write-Host "##[debug] Getting FunctionApp details"
    $funcappObj = az functionapp show --name $($apiPara.parameters.functionApp_name.value) `
                -g $($apiPara.parameters.resourceGroup_name.value) | convertfrom-json

    # Getting the API management details to an object in JSON form
    # 'az apim' is experimental command as of Feb'22 
    Write-Host "##[debug] Getting API Management details"
    $apimObj = az apim show --name $apiPara.parameters.apiManagement_name.value `
                -g $apiPara.parameters.resourceGroup_name.value | convertfrom-json

    # Setting the Access Policies to allow the resources to get/set/list 'secrets' only
    Write-Host "##[debug] Applying Access Policies to $($funcappObj.name): "
    az keyvault set-policy -n $apiPara.parameters.vault_name.value `
    --secret-permissions get list set `
    --object-id $funcappObj.identity.principalId

    Write-Host "##[debug] Applying Access Policies to $($apimObj.name): "
    az keyvault set-policy -n $apiPara.parameters.vault_name.value `
    --secret-permissions get list set `
    --object-id $apimObj.identity.principalId

    Write-Host "##[debug] Applying Access Policies to Service Connection: "
    az keyvault set-policy -n $apiPara.parameters.vault_name.value `
    --secret-permissions get list set `
    --spn $servicePrincipal
}
catch{
    Write-Host "##[debug] Configure KeyVault :: Caught Error $Error[0]"
}

# Generate Keys & Set Secrets
try {
    # Generating new Host Keys
    $keyNameSuffix = $envType
    $keyName = "apim-apim-api-$keyNameSuffix"
    
    az functionapp keys set --key-name $keyName `
    --key-type functionKeys `
    --name $apiPara.parameters.functionApp_name.value `
    -g $apiPara.parameters.resourceGroup_name.value
    
    # Just incase
    Start-Sleep -Seconds 10

    # Get the keys and Set the Secrets in KV
    Write-Host "##[debug] Getting Keys from FunctionApp: "
    $getHostKeys = az functionapp keys list -n $apiPara.parameters.functionApp_name.value `
      -g $apiPara.parameters.resourceGroup_name.value | ConvertFrom-Json
    
    Write-Host "##[debug] Getting Keys from App Insights: "
    # Requires Application Insights Extension
    az config set extension.use_dynamic_install=yes_without_prompt
    az extension add --name  "application-insights"
    
    # Get Actual instrumentation key : NO NEED
    # $getInstrumentationKey =  az monitor app-insights component show --app $apiPara.parameters.appInsights_name.value `
    # -g $apiPara.parameters.resourceGroup_name.value | ConvertFrom-Json
    
    Write-Host "##[debug] Setting Secrets to KV: "
    # 1. MDMFunctionHostKey
    az keyvault secret set --vault-name $apiPara.parameters.vault_name.value `
    --name "MDMFunctionHostKey" --value $getHostKeys.masterKey 
    
    # 2. az-mdm-nonprod-key
    az keyvault secret set --vault-name $apiPara.parameters.vault_name.value `
    --name "az-mdm-$keyNameSuffix-key" --value $($getHostKeys.functionKeys.$keyName)

    # 3. Logger-Credentials : NO NEED 
    # az keyvault secret set --vault-name $apiPara.parameters.vault_name.value `
    # --name "LoggerCredentials"  `
    # --value $getInstrumentationKey.instrumentationKey
}
catch {
    Write-Host "##[error] Generate Keys & Set Secrets :: Caught Error $Error[0]"  -ForegroundColor Red
}