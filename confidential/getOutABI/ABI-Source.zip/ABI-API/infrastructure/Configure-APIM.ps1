<#
    .SYNOPSIS
    Configure APIM

    .DESCRIPTION
    Configure API Management Resurce
    Using Azure REST APIs
       * Set one Named Value
       * Set Backend
       * Set Policies of API
       * Set Policies of Operations under API
       * Setting new Revisions

    .NOTES
    Change Log: FEB'22 - Created
                FEB'22 - envType Condition added
                FEB'22 - Policy Update added
                MAR'22 - Operation Policy added
                SEP'22 - APIM API Revisions + API Version Policy update logic change + Logging Added
#>


[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $envType = "devops",
    $api_version_name = 'v1',
    $api_revision_id = '1',
    $api_revision_description = 'latest revision'
)

try{  
  # Read the Parameters
  Write-Host "##[debug] Pulling variables from parameter files." -ForegroundColor DarkCyan
  $apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json


  if($envType -eq 'devops' -or $envType -eq 'nonprod'){
    $script:subscriptionId = "e7358970-3147-4aa1-8863-49325228dd7d"
    $script:azmdmkey = "az-mdm-$envType-key"
  }
  elseif($envType -eq 'prod') {
    $script:subscriptionId = "023064ea-ee87-4a4b-88ef-ed9b69548090"  
    $script:azmdmkey = "az-mdm-$envType-key"
  }
  else {
    Write-Host "##[info] Env Type is Incorrect" -ForegroundColor Magenta
    exit
  }

  Write-Host "##[debug] Generating Token" -ForegroundColor DarkCyan
  $Script:token     = az account get-access-token --query accessToken --output tsv
  $Script:vaultName = $apiPara.parameters.vault_name.value
  $Script:rgName    = $apiPara.parameters.resourceGroup_name.value
  $Script:apimName  = $apiPara.parameters.apiManagement_name.value
  # $Script:apiID     = $apiPara.parameters.apim_api_id.value
  $Script:functionAppName = $apiPara.parameters.functionApp_name.value

  # NAMED VALUES
  # MDMFunctionHostKey is Hardcoded in below snippet ($bodyNV & Uri) - TODO dynamic if needed
  Write-Host "##[section] Create Named Values in APIM" -ForegroundColor Green
  Write-Host "##[debug] Creating Named Value MDMFunctionHostKey in APIM" -ForegroundColor DarkCyan
  $bodyNV0 = "{
    'name': 'MDMFunctionHostKey',
    'properties': {
      'displayName': 'MDMFunctionHostKey',
      'keyVault': {
        'secretIdentifier': 'https://$($vaultName).vault.azure.net/secrets/MDMFunctionHostKey'
      },
      'secret': true
    }
  }"
  $bodyNV0 = ($bodyNV0) -replace ("`'","`"")

  $requestNamedValue = @{
      Method = 'PUT'
      Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimName)/namedValues/MDMFunctionHostKey?api-version=2021-08-01"
      Headers = @{
          Authorization = "Bearer $($token)"
      }
      ContentType = 'application/json'
      Body = $bodyNV0
  }
  Invoke-RestMethod @requestNamedValue 

  Write-Host "##[debug] Creating Named Value $azmdmkey in APIM" -ForegroundColor DarkCyan
  $bodyNV1 = "{
    'name': '$azmdmkey',
    'properties': {
      'displayName': '$azmdmkey',
      'keyVault': {
        'secretIdentifier': 'https://$($vaultName).vault.azure.net/secrets/$azmdmkey'
      },
      'secret': true
    }
  }"
  $bodyNV1 = ($bodyNV1) -replace ("`'","`"")

  $requestNamedValue = @{
      Method = 'PUT'
      Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimName)/namedValues/$($azmdmkey)?api-version=2021-08-01"
      Headers = @{
          Authorization = "Bearer $($token)"
      }
      ContentType = 'application/json'
      Body = $bodyNV1
  }
  Invoke-RestMethod @requestNamedValue 

  # Just in case
  Start-Sleep -Seconds 10
  
  # BACKEND
  # MDMFunctionHostKey is Hardcoded in below snippet ($bodyBack/credentials) - TODO dynamic if needed
  Write-Host "##[section] Create Backend in APIM" -ForegroundColor Green
  $bodyBack = "{
    'properties': {
      'protocol': 'http',
      'url': 'https://$($functionAppName).azurewebsites.net',
      'description': '$($functionAppName)',
      'resourceId': 'https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.Web/sites/$($functionAppName)',
      'credentials': {
        'header': {
          'x-functions-key': [
            '{{MDMFunctionHostKey}}'
          ]
        }
      }
    }
  }"
  $bodyBack = ($bodyBack) -replace ("`'","`"")

  $requestBackend = @{
      Method = 'PUT'
      Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimName)/backends/$($functionAppName)?api-version=2021-08-01"  
      Headers = @{
          Authorization = "Bearer $($token)"
      }
      ContentType = 'application/json'
      Body = $bodyBack
  }
  Invoke-RestMethod @requestBackend 

  # Just in case
  Start-Sleep -Seconds 10
  
  # API POLICY UPDATE
  Write-Host "##[section] Update API Policy in APIM" -ForegroundColor Green
  # API 'ALL OPERATION' POLICY UPDATE
  $countAPIVersions = az apim api list -g $rgName -n $apimName --query [?apiRevision==`'1`'].name | ConvertFrom-Json
  $countAPIVersions
  if($countAPIVersions.Count -gt 0){
    foreach ($versionApiID in $countAPIVersions){
      Write-Host "##[info] Update API Policy: All Operation: $($versionApiID) in APIM" -ForegroundColor Magenta
      $bodyPolicy = '{
        "properties":{
        "value": "<policies><inbound><base \/><set-header name=\"x-functions-key\" exists-action=\"append\"><value>{{MDMFunctionHostKey}}<\/value><\/set-header><cors allow-credentials=\"false\"><allowed-origins><origin>*<\/origin><\/allowed-origins><allowed-methods><method>*<\/method><\/allowed-methods><allowed-headers><header>*<\/header><\/allowed-headers><expose-headers><header>*<\/header><\/expose-headers><\/cors><\/inbound><backend><base \/><\/backend><outbound><base \/><\/outbound><on-error><base \/><\/on-error><\/policies>"
      }}'
      $bodyPolicy = ($bodyPolicy) -replace ("`'","`"")
      
      $requestAPIPolicy = @{
          Method = 'PUT'
          Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimName)/apis/$($versionApiID)/policies/policy?api-version=2021-08-01"  
          Headers = @{
              Authorization = "Bearer $($token)"
          }
          ContentType = 'application/json'
          Body = $bodyPolicy
      }  
      Invoke-RestMethod @requestAPIPolicy 

    # API EACH OPERATION POLICY UPDATE
      Write-Host "##[info] Updating Policy for API Version: $($versionApiID) : Current Revision(1) only" -ForegroundColor Magenta
      $countAPIs = az apim api operation list --api-id $versionApiID -g $rgName -n $apimName --query [].name  --output tsv
      if($countAPIs.Count -gt 0){
        foreach($opsAPI in $countAPIs){
          Write-Host "##[debug] Updating Policy for Operation: $($opsAPI)" -ForegroundColor DarkCyan
          $bodyOpsPolicy = "{
            'properties':{
              'format':'xml',
              'value': '<policies><inbound><base\/><set-backend-service id=\'apim-generated-policy\' backend-id=\'$($functionAppName)\'\/><\/inbound><backend><base\/><\/backend><outbound><base\/><\/outbound><on-error><base\/><\/on-error><\/policies>'
          }}"
          $bodyOpsPolicy = ($bodyOpsPolicy) -replace ("`'","`"")
          
          $requestAPIOpsPolicy = @{
              Method = 'PUT'
              Uri    = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimName)/apis/$($versionApiID)/operations/$($opsAPI)/policies/policy?api-version=2021-08-01"  
              Headers = @{
                  Authorization = "Bearer $($token)"
              }
              ContentType = 'application/json'
              Body = $bodyOpsPolicy
          }  
          Invoke-RestMethod @requestAPIOpsPolicy 
        }
      }
    }
  }
  

  # API REVISION ADD
  # az apim api revision create --resource-group $rgName --service-name $apimName `
  # --api-id "$apiID-$($api_version_name)" --api-revision $api_revision_id --api-revision-description $api_revision_description
  
  # API VERSION ADD TODO
  # REST API
}
catch{
    Write-Host "##[error] StatusCode:" $_.Exception.Response.StatusCode.value__ -ForegroundColor Red
    Write-Host "##[warning] $($_.Exception)" -ForegroundColor Yellow
}
