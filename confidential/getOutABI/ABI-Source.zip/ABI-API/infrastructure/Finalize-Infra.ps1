<#
.SYNOPSIS
    Finalize Infrastructure

.DESCRIPTION
    Post-check of infrastructure after it Deploys the required API resources.
    Clean extra Named Values from the APIM
    Read README.md to know more

.PARAMETER Environment
    The environment type e.g. prod/ nonprod/ devops

.NOTES
    Change Log: FEB'22 - Created
                MAR'22 - Logic tweaks - nv list command picking all Named Values resulting into Error 
                SEP'22 - Logging Added + name change from PostCheck-Infra to Finalize-Infra
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $envType = "devops"
)

try{  
    # Read the Core Parameters
    $apiPara = Get-Content $PSScriptRoot\parameters\environments\$envType\api-parameters.json | ConvertFrom-Json
    if($envType -eq 'devops' -or $envType -eq 'nonprod'){
        $script:subscriptionId = "e7358970-3147-4aa1-8863-49325228dd7d"
    }
    elseif($envType -eq 'prod') {
        $script:subscriptionId = "023064ea-ee87-4a4b-88ef-ed9b69548090"  
    }
    else {
        Write-Host "##[info] Env Type is Incorrect" -ForegroundColor Magenta
        exit
    }
    $ErrorActionPreference="Ignore"   

    $rgName = $apiPara.parameters.resourceGroup_name.Value
    $apimServiceName = $apiPara.parameters.apiManagement_name.Value

    # Get the current Logger Credential    
    Write-Host "##[debug] Get Currently used Logger"
    $token = az account get-access-token --query accessToken --output tsv
    $requestAPILogger = @{
        Method = 'GET'
        Uri = "https://management.azure.com/subscriptions/$($subscriptionId)/resourceGroups/$($rgName)/providers/Microsoft.ApiManagement/service/$($apimServiceName)/loggers?api-version=2021-08-01"
        Headers = @{
            Authorization = "Bearer $($token)"
        }
    }
    $requestedAPILogger = Invoke-RestMethod @requestAPILogger
    $currentLogger = ($requestedAPILogger.value.properties.credentials.instrumentationKey) -replace ("\{{(.*)\}}",'$1')
    
    # Get All Logger Named Values except for the current one  
    $nvids = $(az apim nv list -g $rgName -n $apimServiceName --query [?displayName!=`'$currentLogger`'].name --output tsv) # Gets all Named Values - Need to sort with Logger
    # Sorting on basis of the logic : default Logger Named value IDs are always Numeric
    $nvids = $nvids -match '(^[0-9])'

    if(!($nvids | measure | foreach{$_.Count}) -eq 0){
        Write-Host "##[debug] Deleting not used in Logger"
        # Delete each access Named Value - Only Current Named Value would give error and execution stops
        foreach ($nvid in $nvids){ 
            az apim nv delete --named-value-id $nvid -g $rgName -n $apimServiceName -y
            if($? -eq $false){
                throw "Exception Generated"
            }
            else{
                Write-Host "##[debug] $nvid :: Deleted"
            }
        }
    }
    else {
        Write-Host "##[debug] Post Check Ok"
    }
}
catch{
    Write-Host "##[error] StatusCode:" $_.Exception.Response.StatusCode.value__ -ForegroundColor Red
    Write-Host "##[warning] $($_.Exception)" -ForegroundColor Yellow
}


