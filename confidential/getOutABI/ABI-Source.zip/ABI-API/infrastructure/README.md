# ABI API Infrastructure

## Folder Structure
- parameters > contains parameters in JSON file - seperated in environment folder
- swagger    > contains OpenAPI specification file containing API Operations - seperated in API Version folder
- templates  > contains bicep templates

## Environment Setup

### Prerequisites
1. J2 python library
2. Environment viz parameter folders
3. Resource Groups created for both prod/non-prod (& devops)
    3.1. Role Assignments to Service Connections over RGs
    3.2. Role Assignments to Service Connections over core keyvault 

### Initialization
0. [One time] For each new Environment: Complete the pre-req
1. [One time] For each new Environment: On local run the Generate-EnvironmentConfig.ps1 to generate environment parameter files
2. [Recurring] For each new API version: create version name folder under swagger/ and place the swagger.json.template file

### Build | [Build Pipeline](https://dev.azure.com/civica-central/ABI/_build?definitionId=198)
1. Build the Function app
2. Validate the Bicep template deployment | `Validate-Infra.ps1` 
 
### Deployment | [Release Pipeline](https://dev.azure.com/civica-central/ABI/_release?_a=releases&view=mine&definitionId=21)
1. Create Swagger Files: | `Create-Swagger.ps1`
   - Creating swagger.json files from base template inorder to deploy the API Operations
   - - [TODO] Move the logic to new Initialize-Infra.ps1 & Add Agent IP Address
2. Deploy Infrastructure: | `Deploy-Infra.ps1`
   - Create Azure Services: Storage account, Key vault, Application Insights, Function App & API Management
3. Deploy Functions: | `Azure DevOps task: Azure Functions`
   - Deploying functions under the Function App created in previous step
4. Configuring Function App: | `Configure-FunctionApp.ps1`
   - Add SQL Connection strings according to environment as Function App Configuration
5. Configuring Key vault: | `Configure-VaultSecrets.ps1`
   * Update Access Policy
        - Give Access to FunctionApp to store the Function Keys
        - Give Access to API Management to get the secrets as Named Value
    * Generate Keys
        - Function Host Keys
    * Set Secrets
6. Configure API Management: | `Configure-APIM.ps1`
   * Setting 
     - one Named Value
     - Backend
     - Policies of API "All Operations" of each API version
     - Policies of each Operations under each API version
     - Revisions
7. Post Deployment check: | `PostCheck-Infra.ps1`
   - Cleaning old Named Values from the API Management service
   - [TODO] Remove Agent IP Address 
    


### Limitations
- [TODO] Key vault supports 250 versions of any secret --> current deployment makes a new version each time it deploys

### Contribution
Chakitan Vyas