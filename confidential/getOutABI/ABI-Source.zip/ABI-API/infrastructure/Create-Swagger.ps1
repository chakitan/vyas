<#
    .SYNOPSIS
    Create Swagger File

    .DESCRIPTION
    The script generates required swagger file for environments prod & nonprod
    Store temparory file and delete once used

    .NOTES
    Change Log: MAR'22 - Created
                SEP'22 - Change in logic according to API Versioning + Logging Added
                OCT'22 - Update logic: Split swagger env viz
#>

[CmdletBinding()]
param (
    [Parameter()]
    [String]
    $envType = "nonprod",
    $api_version_name
)

$Script:templateFiles     = ls "$PSScriptRoot\swagger\environments\$envType\" -Recurse -Include *.template | foreach {$_.FullName}
$Script:newVersionFolder  = "$PSScriptRoot\swagger\System\newversion\"
$Script:ogVersionFolder   = "$PSScriptRoot\swagger\System\Original\"
$Script:newVersionFile    = "$PSScriptRoot\swagger\environments\$envType\$($api_version_name)\swagger.json"
$Script:ogVersionFile     = "$PSScriptRoot\swagger\environments\$envType\Original\swagger.json"

try {
    # Create Swagger Files based on the templates
    foreach ($templateFile in $templateFiles){
        $templateRootFolder = Split-Path $templateFile
        Write-Host "##[debug] Generating Swagger for environment: $envType" -ForegroundColor DarkCyan
        (Get-Content $templateFile) -replace ("envType", $envType) | Set-Content "$templateRootFolder\swagger.json" -Verbose -Force
    }

    # Bicep function loadTextContent() requires runtime constant file path hence copy and paste the files into System folder
    # Place the Original swagger file under System/Original folder
    Copy-Item -Path $ogVersionFile -Destination $ogVersionFolder -Force -Verbose
    # Place the new version swagger file under System/newversion folder
    Copy-Item -Path $newVersionFile -Destination $newVersionFolder -Force -Verbose
}
catch {
    Write-Host "##[error] Error Received :: $Error" -ForegroundColor Red
}
