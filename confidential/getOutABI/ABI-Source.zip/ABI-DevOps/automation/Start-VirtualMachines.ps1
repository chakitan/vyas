<#
    .SYNOPSIS
    Start Virtual Machines

    .DESCRIPTION
    This is a runbook script intended to Start the Virtual Machines

    .NOTES
    Change Log: SEP'22 - Created
    Chakitan Vyas
#>

try
{
    Write-Host "##[debug] Logging in to Azure..."
    Connect-AzAccount -Identity

    # Get IDs of all VMs in the Subscription?
    Start-AzVM -ResourceGroupName "ResourceGroup11" -Name "VirtualMachine07"

}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception
}