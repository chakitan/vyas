# AUTOMATION

## Infra automation using Azure Automation Accounts - Runbook
- [ref.](https://learn.microsoft.com/en-us/azure/automation/overview)
- [IaC](https://learn.microsoft.com/en-gb/azure/automation/quickstart-create-automation-account-template)

## Files Structure

## Run

### Pre-req
- Automation Account 'Managed Identity' to be given appropriate RBAC on intended scope
- specific ontributor access
  - Virtual Machine: Virtual Machine Contributor
  - PowerBI Embedded: PowerBI Embedded Contributor (custom role)[ref.](PowerBI%20Embedded%20Contributor.json)

### Release
- 

## Change Log

## Conrtibute
Chakitan Vyas 