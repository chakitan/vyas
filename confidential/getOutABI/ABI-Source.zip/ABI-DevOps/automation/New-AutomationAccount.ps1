<#
    .SYNOPSIS
    New Automation Account 

    .DESCRIPTION

    .NOTES
    Change Log: SEP'22 - Created
    Chakitan Vyas
#>

param (
    $Environment,
    $resource_group_name = "rg-sidi-shared"
)


$tagObj = @{
    "Environment"= $Environment
    "CostCenter" = "CENTUM"
    "CreateDate" = $(Get-Date -Format O)
    "CreateBy"   = $(RELEASE.RELEASENAME)
}

az deployment group create -g $resource_group_name -f automation.bicep -p parameters.json `
tag_object=$tagObj