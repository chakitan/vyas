<#
    .SYNOPSIS
    Start PowerBI Embedded

    .DESCRIPTION
    This is a runbook script intended to Start/ Resume the PowerBI Embedded service
    Uses Az PowerShell Module

    .NOTES
    Change Log: SEP'22 - Created
    Chakitan Vyas
#>

param(
    $powerBI_Capacity_Name,
    $resourceGroupName
)

try
{
    Write-Host "##[debug] Logging in to Azure..."
    Connect-AzAccount -Identity

    
    # Get the PowerBI capacities in the Subscription?
    # Get-AzPowerBIEmbeddedCapacity
    # Resume-AzPowerBIEmbeddedCapacity -Name $powerBI_Capacity_Name -ResourceGroupName $resourceGroupName -PassThru
    Get-AzPowerBIEmbeddedCapacity -ResourceGroupName "testRG"

}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception
}

