function Add-AdGroup {
    <#
        .SYNOPSIS
        Creates an Azure AD group and adds information to keyvault.

        .DESCRIPTION
        Stores group name and object id.

        .PARAMETER GroupName
        Specifies the Azure AD group name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the Azure AD group.

        .PARAMETER VaultName
        Specifies the keyvault name.
    #>
    param (
        [string]$GroupName,
        [string]$VaultKeyPrefix,
        [string]$VaultName
    )

    Write-Host "Check for group $GroupName" -ForegroundColor Cyan
    $groupFound = $(az ad group list --query "contains([].displayName, '$GroupName')")
    if($groupFound -eq 'false') {
        Write-Host "Group $GroupName not found. Creating." -ForegroundColor Yellow
        $group = $(az ad group create --display-name $GroupName --mail-nickname $GroupName) | ConvertFrom-Json

        az keyvault secret set --vault-name $VaultName --name "$VaultKeyPrefix-name" --value $GroupName
        az keyvault secret set --vault-name $VaultName --name "$VaultKeyPrefix-objectId" --value $group.objectId
    }
}

function Add-AdUser {
    <#
        .SYNOPSIS
        Creates an Azure AD user and adds information to keyvault.

        .DESCRIPTION
        Stores user name, password and object id.

        .PARAMETER UserName
        Specifies the Azure AD user name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the Azure AD user.

        .PARAMETER VaultName
        Specifies the keyvault name.
    #>
    param (
        [string]$UserName,
        [string]$VaultKeyPrefix,
        [string]$VaultName
    )

    Write-Host "Check for user $UserName" -ForegroundColor Cyan
    $principalFound = $(az ad user list --query "contains([].userPrincipalName, '$UserName')")
    if($principalFound -eq 'false') {
        Write-Host "User $UserName not found. Creating." -ForegroundColor Yellow
        $password = Get-Password
        $principal = $(az ad user create --display-name $UserName --user-principal-name $UserName --password $password --force-change-password-next-login false) | ConvertFrom-Json

        Write-Host "Copying $UserName details to infrastructure keyvault." -ForegroundColor Yellow
        az keyvault secret set --vault-name $VaultName --name "$VaultKeyPrefix-name" --value $UserName
        az keyvault secret set --vault-name $VaultName --name "$VaultKeyPrefix-password" --value $password
        az keyvault secret set --vault-name $VaultName --name "$VaultKeyPrefix-objectId" --value $principal.objectId
    }
}

function Add-AdUserToGroup {
    <#
        .SYNOPSIS
        Adds an Azure AD user to an Azure AD group.

        .PARAMETER UserName
        Specifies the Azure AD user name.

        .PARAMETER GroupName
        Specifies the Azure Ad group name.
    #>
    param (
        [string]$UserName,
        [string]$GroupName
    )

    $principal = $(az ad user show --id $UserName) | ConvertFrom-Json

    Write-Host "Adding $UserName to group." -ForegroundColor Yellow
    az ad group member add --group $GroupName --member-id $principal.objectId
}

function Add-ServiceConnection {
    <#
        .SYNOPSIS
        Adds an Azure DevOps service connection and underlying Azure AD principal.

        .PARAMETER Environment
        Identifier for the environment to use.

        .PARAMETER SubscriptionId
        The subscription id for the service connection to access.

        .PARAMETER SubscriptionName
        The subscription name for the service connection to access.

        .PARAMETER TenantId
        The tenant id for the Azure AD tenant.

        .PARAMETER PrincipalName
        The principal name for the service connection.

        .PARAMETER AzureDevopsOrganisation
        The name of the Azure DevOps organisation.

        .PARAMETER AzureDevopsProjectId
        The project id for the Azure DevOps organisation.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the service connection.
    #>
    param (
        [string]$Environment,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$TenantId,
        [string]$PrincipalName,
        [string]$AzureDevopsOrganisation,
        [string]$AzureDevopsProjectId,
        [string]$VaultName,
        [string]$VaultKeyPrefix
    )

    Write-Host "Check for sp $PrincipalName" -ForegroundColor Cyan
    $principalFound = $(az ad sp list --query "contains([].servicePrincipalNames[0], '$PrincipalName')" -o tsv)
    if($principalFound -eq 'false') {
        Write-Host "Principal $PrincipalName not found. Creating." -ForegroundColor Yellow
        $principal = $(az ad sp create-for-rbac --name $PrincipalName --skip-assignment) | ConvertFrom-Json
        $principalCreated = $true
    } else {
        $principalCreated = $false
    }

    $principalDetails = $(az ad sp show --id "$PrincipalName") | ConvertFrom-Json

    if($principalCreated -eq $true) {
        $env:AZURE_DEVOPS_EXT_AZURE_RM_SERVICE_PRINCIPAL_KEY = $principal.password
        az devops service-endpoint azurerm create `
            --azure-rm-service-principal-id $principalDetails.appId `
            --azure-rm-subscription-id $SubscriptionId `
            --azure-rm-subscription-name $SubscriptionName `
            --azure-rm-tenant-id $TenantId `
            --name "fcin $Environment service connection" `
            --organization $AzureDevopsOrganisation `
            --project $AzureDevopsProjectId
    }

    Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-objectId" $principalDetails.objectId
}

function Add-ServicePrincipal {
    <#
        .SYNOPSIS
        Adds an Azure DevOps service principal.

        .PARAMETER PrincipalName
        The principal name for the service principal.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the service connection.
    #>
    param (
        [string]$PrincipalName,
        [string]$VaultName,
        [string]$VaultKeyPrefix
    )

    Write-Host "Check for sp $PrincipalName" -ForegroundColor Cyan
    $principalFound = $(az ad sp list --all --query "contains([].servicePrincipalNames[0], 'http://$PrincipalName')" -o tsv)
    if($principalFound -eq 'false') {
        Write-Host "Principal $PrincipalName not found. Creating." -ForegroundColor Yellow
        $principal = $(az ad sp create-for-rbac --name $PrincipalName --skip-assignment) | ConvertFrom-Json
        $principalDetails = $(az ad sp show --id "$($principal.appId)") | ConvertFrom-Json

        Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-appId" $principalDetails.appId
        Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-objectId" $principalDetails.objectId
        Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-password" $principal.password
    }
}

function Add-ExistingServicePrincipal {
    <#
        .SYNOPSIS
        Adds details for an existing Azure AD service principal.

        .PARAMETER PrincipalName
        The principal name for the service principal.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the service connection.
    #>
    param (
        [string]$PrincipalName,
        [string]$VaultName,
        [string]$VaultKeyPrefix
    )

    Write-Host "Check for sp $PrincipalName" -ForegroundColor Cyan
    $principalDetails = $(az ad sp list --all --query "[?displayName=='$PrincipalName']") | ConvertFrom-Json

    Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-appId" $principalDetails.appId
    Add-SecretWithValue -VaultName $VaultName -SecretName "$VaultKeyPrefix-objectId" $principalDetails.objectId
    Add-UserEnteredSecret -VaultName $VaultName -SecretName "$VaultKeyPrefix-password"
}

function Add-AdUserDetailsToVault {
    <#
        .SYNOPSIS
        Adds user details for an existing Azure AD user to keyvault.

        .DESCRIPTION
        Stores user name, password and object id.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER UserKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the Azure AD user.
    #>
    param (
        [string]$VaultName,
        [string]$UserKeyPrefix
    )

    $UserNameKey = "$UserKeyPrefix-name"
    $UserPasswordKey = "$UserKeyPrefix-password"
    $UserObjectIdKey = "$UserKeyPrefix-objectId"

    # Retrieve the username and 
    $secretFound = $(az keyvault secret list --vault-name $VaultName --query "contains([].name, '$($UserNameKey)')")
    if($secretFound -eq 'false') {
        $secureSecret = Read-Host "Enter secret '$UserNameKey'" -AsSecureString
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
        $secret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)

        az keyvault secret set --vault-name $VaultName --name $UserNameKey --value $secret --query attributes
    } else {
        $secret = $(az keyvault secret show --vault-name $VaultName --name $UserNameKey --query value -o tsv)
    }

    $userObjectId = $(az ad user show --id $secret --query objectId -o tsv)

    Add-SecretWithValue -VaultName $VaultName -SecretName $UserObjectIdKey -SecretValue $userObjectId
    Add-UserEnteredSecret -VaultName $VaultName -SecretName $UserPasswordKey
}

function Add-AdAppRegistration {
    <#
        .SYNOPSIS
        Adds app registration for application

        .DESCRIPTION
        Stores user name, password and object id.

        .PARAMETER AppName
        Specifies the app registration name.

        .PARAMETER ReplyUri
        Specifies the app registration reply uri.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the service connection.

        .PARAMETER ApiPermissions
        Specifies the sets of guid identified api permissions for a specified api.
        The format is a hashtable where the key identifies the API id and the value is
        a list of permission ids.
    #>
    param (
        [string]$AppName,
        [array]$ReplyUris,
        [string]$VaultName,
        [string]$VaultKeyPrefix,
        [hashtable]$ApiPermissions
    )

    Write-Host "Check for AppRegistration $AppName" -ForegroundColor Cyan
    $appIdFound = $(az ad app list --query "contains([].displayName, '$($AppName)')")
    if($appIdFound -eq 'false') {
        Write-Host "AppRegistration not found: adding."
        $appId = $(az ad app create --display-name $AppName --reply-urls $ReplyUris --query appId -o tsv)
        az ad sp create --id $appId

        $ApiPermissions.Keys | ForEach-Object {
            $apiId = $_
            Write-Host "Adding API permissions for api '$apiId'"
            
            $ApiPermissions.Item($_) | ForEach-Object {
                $permissionId = "$_=Scope"
                Write-Host "Adding api permission '$permissionId'"
                az ad app permission add --id $appId --api $apiId --api-permissions $permissionId
            }

            Write-Host "Granting API permissions for api '$apiId'"
            az ad app permission grant --id $appId --api $apiId
        }

        $appIdKey = "$VaultKeyPrefix-appId"
        Add-SecretWithValue -VaultName $VaultName -SecretName $appIdKey -SecretValue $appId
    }
}

function Add-ExistingAdAppRegistration {
    <#
        .SYNOPSIS
        Adds a manually setup app registration to the keyvault for usage.

        .DESCRIPTION
        Stores user name, password and object id.

        .PARAMETER AppName
        Specifies the app registration name.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER VaultKeyPrefix
        Specifies the keyvault secret prefix for secrets relating to the service connection.
    #>
    param (
        [string]$AppName,
        [string]$VaultName,
        [string]$VaultKeyPrefix
    )

    Write-Host "Finding existing AppRegistration $AppName" -ForegroundColor Cyan
    $appId = $(az ad app list --all --query "[?displayName=='$AppName'].appId" -o tsv)
    $appIdKey = "$VaultKeyPrefix-appId"
    Add-SecretWithValue -VaultName $VaultName -SecretName $appIdKey -SecretValue $appId
}

function Get-RandomCharacters {
    <#
        .SYNOPSIS
        Generates random characters to create a password.

        .PARAMETER Length
        The length of the random characters to generate.

        .PARAMETER Characters
        The character set to use to generate the random characters.
    #>
    param (
        [string]$Length,
        [string]$Characters
    )

    $random = 1..$Length | ForEach-Object { Get-Random -Maximum $Characters.length } 
    $private:ofs=""

    return [String]$Characters[$random]
}
  
function Get-Password(){
    <#
        .SYNOPSIS
        Generates a random password of length 20 characters.
    #>

    $randomCharacters = Get-RandomCharacters -Length 20 -Characters 'abcdefghiklmnoprstuvwxyzABCDEFGHKLMNOPRSTUVWXYZ1234567890'
    $characterArray = $randomCharacters.ToCharArray()
    $scrambledStringArray = $characterArray | Get-Random -Count $characterArray.Length
    $outputString = -join $scrambledStringArray

    return $outputString
}

function Get-LongPassword(){
    <#
        .SYNOPSIS
        Generates a random password of length 40 characters.
    #>

    $randomCharacters = Get-RandomCharacters -Length 40 -Characters 'abcdefghiklmnoprstuvwxyzABCDEFGHKLMNOPRSTUVWXYZ1234567890!@#$%^&*:./?=+-_[]{}()<>'
    $characterArray = $randomCharacters.ToCharArray()
    $scrambledStringArray = $characterArray | Get-Random -Count $characterArray.Length
    $outputString = -join $scrambledStringArray

    return $outputString
}

function Add-Password {
    <#
        .SYNOPSIS
        Adds an autogenerated password to the keyvault.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER SecretName
        Specifies the keyvault secret name for the password.
    #>
    param (
        [string]$VaultName,
        [string]$SecretName
    )

    $passwordFound = $(az keyvault secret list --vault-name $VaultName --query "contains([].name, '$($SecretName)')")
    if($passwordFound -eq 'false') {
      $password = Get-Password
      az keyvault secret set --vault-name $VaultName --name $SecretName --value $password --query attributes
    }
}

function Add-LongPassword {
    <#
        .SYNOPSIS
        Adds an autogenerated long password to the keyvault.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER SecretName
        Specifies the keyvault secret name for the password.
    #>
    param (
        [string]$VaultName,
        [string]$SecretName
    )

    $passwordFound = $(az keyvault secret list --vault-name $VaultName --query "contains([].name, '$($SecretName)')")
    if($passwordFound -eq 'false') {
      $password = Get-LongPassword
      az keyvault secret set --vault-name $VaultName --name $SecretName --value "`"$password`"" --query attributes
    }
}

function Add-SecretWithValue {
    <#
        .SYNOPSIS
        Adds a secret with value to the keyvault.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER SecretName
        Specifies the keyvault secret name for the value.

        .PARAMETER SecretValue
        Specifies the keyvault secret value.
    #>
    param (
        [string]$VaultName,
        [string]$SecretName,
        [string]$SecretValue
    )

    $passwordFound = $(az keyvault secret list --vault-name $VaultName --query "contains([].name, '$($SecretName)')")
    if($passwordFound -eq 'false') {
        az keyvault secret set --vault-name $VaultName --name $SecretName --value $SecretValue --query attributes
    }
}

function Add-UserEnteredSecret {
    <#
        .SYNOPSIS
        Adds a secret with user-entered value to the keyvault.

        .PARAMETER VaultName
        Specifies the keyvault name.

        .PARAMETER SecretName
        Specifies the keyvault secret name for the value.
    #>
    param (
        [string]$VaultName,
        [string]$SecretName
    )

    # Get the user secret
    $secretFound = $(az keyvault secret list --vault-name $VaultName --query "contains([].name, '$($SecretName)')")
    if($secretFound -eq 'false') {
        $secureSecret = Read-Host "Enter secret '$SecretName'" -AsSecureString
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
        $secret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)

        if($secret.Length -eq 0) {
            Write-Host "Generating secret value." -ForegroundColor Yellow
            $secret = Get-Password
        }

        az keyvault secret set --vault-name $VaultName --name $SecretName --value "`"$secret`"" --query attributes
    }
}
