<#
.SYNOPSIS
    Initialised the environment for deployment.
    Allows user entry of environment secrets.
    Assumes resource group in place prior to running script.

.PARAMETER Environment
    The environment e.g. dev, test, uat.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops"
)

. "$PSScriptRoot\scripts\InfrastructureOperations.ps1"

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Retrieve current user objectId
$currentUser = $(az ad signed-in-user show) | ConvertFrom-Json

# Deploy deployment components
$deploymentName = "sidi-deployment-core-$([Guid]::NewGuid())"
Write-Host "Running deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParams.group_name `
  --template-file "$PSScriptRoot\templates\deployment-template.json" `
  --parameters "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" `
  --parameters deployment_user_object_id="$($currentUser.objectId)"

# Copy assets to storage.
Write-Host "Copying assets to storage."
az storage blob upload --account-name $parameters.parameters.sidi_corestore_name.value -f $PSScriptRoot\assets\gatewayInstall.ps1 -c artifacts -n gatewayInstall.ps1

# Set environment passwords if not present
Write-Host "Storing environment credentials."
Add-Password -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-vm-admin-password
Add-LongPassword -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-db-master-encryptionKey-password
Add-Password -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-db-master-crossdbuser-password

Write-Host "Storing sql admin credentials."
Add-SecretWithValue -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-admin-name -SecretValue "abi-$Environment-admn"
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-admin-password

Write-Host "Storing sql sync credentials."
Add-SecretWithValue -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName "abi-datasync-name" -SecretValue "abi-$Environment-sync"
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName "abi-datasync-password"

Write-Host "Storing sql user credentials."
Add-SecretWithValue -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-rw-name -SecretValue "abi-$Environment-rw"
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-rw-password
Add-SecretWithValue -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-reader-name -SecretValue "abi-$Environment-reader"
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName sidi-sqlserver-reader-password

Write-Host "Storing User entered secrets."
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName MarketPoint-oAuthBearerPassword
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName mdm-on-prem-dw-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName mdm-on-prem-mds-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-QA-12-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName ext-sftp-user-userName
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName ext-sftp-user-password

# Additional SOPS connection strings
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-NI-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-AUS-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-AUS-BPO-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-NZ-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-SNG-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName SOPs-CMI-USA-connection-string
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName fabs-Global-connection-string

# Additional oauth secrets
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName oAuthBearerTokenUrl-MarketPoint-Global
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName oAuthBearerTokenCredential-MarketPoint-Global

# Additional secrets
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName oAuthBearerTokenUrl-Proact-Global
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName oAuthBearerTokenCredential-Proact-Global
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName Proact-API-Url-Global

# Marketpoint secrets
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName MarketPoint-API-Url-Global
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName MarketPoint-API-PageSize

# Storing details about the preconfigured sql ad account.
Write-Host "Storing sql Azure AD admin account details."
Add-AdUserDetailsToVault -VaultName $parameters.parameters.sidi_corevault_name.value -UserKeyPrefix "ad-user-sqlAdAdmin"

# Initialise service principal for adf connector.
Add-ServicePrincipal -VaultName $parameters.parameters.sidi_corevault_name.value -PrincipalName $coreParams.ad_sp_adfConnector_name -VaultKeyPrefix "ad-sp-adfConnector"
Add-ExistingServicePrincipal -VaultName $parameters.parameters.sidi_corevault_name.value -PrincipalName $coreParams.ad_sp_powerBi_name -VaultKeyPrefix "ad-sp-powerBi"

Add-ExistingAdAppRegistration `
  -AppName $coreParams.ad_app_portal_name `
  -VaultKeyPrefix "ad-app-portal" `
  -VaultName $parameters.parameters.sidi_corevault_name.value
