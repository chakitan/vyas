<#
    .SYNOPSIS
    Generate Environment Config

    .DESCRIPTION
    The script generates all required parameter file for environment
    First Block executes on all the folders present under envrionments\ path
    Second Bloack executes on given environment named folder under environments\ path
    
    Prerequisites:
    >Script uses J2 python library
    >Environment Name folder with _environment.yml file in it.


    .NOTES
    To execute any block comment out the other one.
#>

#First Block
## Generate Environment Config for all Environments

#$environments = Get-ChildItem $PSScriptRoot\environments
#$templates = Get-ChildItem $PSScriptRoot\_param-templates
#
#foreach($environment in $environments) {
#    Write-Host "Generating configuration for environment: $($environment.Name)"
#
#    foreach($template in $templates) {
#        $envFilePath = "$($environment.FullName)\_Environment.yml"
#        $templatePath = $template.FullName
#        $outputPath = "$($environment.FullName)\$($template.Name -replace '.{3}$')"
#
#        j2 $templatePath $envFilePath -o $outputPath
#    }
#}

#Second Block
## Generate Environment Config for Single Env
### Comment above block & uncomment below to execute

$newEnvName = 'devopstest'
$environment = "$PSScriptRoot\environments\$newEnvName"
$templates = Get-ChildItem $PSScriptRoot\_param-templates

Write-Host "Generating configuration for environment: $environment"
foreach($template in $templates) {
    $envFilePath = "$environment\_environment.yml"
    $templatePath = $template.FullName
    $outputPath = "$environment\$($template.Name -replace '.{3}$')"
        j2 $templatePath $envFilePath -o $outputPath
}