<#
.SYNOPSIS
    Deploys access to the shared infrastructure components for the specified environment.

.PARAMETER Environment
    The environment e.g. dev, test, uat.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devopstest"
)

# Pull arm parameters into variables
Write-Host "Pulling variables from parameter files."
$coreParameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

$deploymentName = "sidi-deployment-sharedIr-$([Guid]::NewGuid())"
Write-Host "Running vm deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParameters.group_shared_name `
  --template-file "$PSScriptRoot\templates\sharedIr-template.json" `
  --parameters "$PSScriptRoot\templates\parameters\environments\$Environment\sharedIr-parameters.json"