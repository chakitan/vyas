<#
.SYNOPSIS
    Deploys the database users from script.
    Scripts are published by the ABI-Database pipeline.
    Parameters must be correctly supplied to each script run.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.PARAMETER DatabaseArtifactPath
    Path to the database artifact folder.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops",
    [Parameter()]
    [string]
    $DatabaseArtifactPath = "$PSScriptRoot\..\ABI-Databases"
)

# Get environment type based on Environment
function checkEnvType {
  param (
      $et
  )
  $envArrNonprod = @('dev','devint','test','uat','devops') #ADD devops IN THE ARRAY FOR DEVOPS DEVELOPMENT
  $envArrProd = @('preprod','prod')
  if($envArrNonprod -ccontains $et ){            
      return "nonprod"
  }
  elseif($envArrProd -ccontains $et ){            
      return "prod"
  }
  else{
      return $false;
  }
}


# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\main-parameters.json" | ConvertFrom-Json
$deploymentParameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Obtain the agent ip for firewall purposes.
Write-Host "Obtaining agent ip."
 #$agentIP = (New-Object net.webclient).downloadstring("https://ifconfig.me/ip") # DEPRECATED
$agentIP = (Invoke-WebRequest https://ifconfig.me/ip | Select-Object Content) -replace "[^\d\.]"

# Pull keyvault values.
Write-host "Adding keyvault firewall rule for $agentIP" -ForegroundColor White
az keyvault network-rule add --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP

try {
    Write-Host "Pulling secrets from infrastructure vault." -ForegroundColor Cyan
    $adminUser = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "ad-user-sqlAdAdmin-name" --query value -o tsv)
    $adminPass = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "ad-user-sqlAdAdmin-password" --query value -o tsv)
    $readerName = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-reader-name" --query value -o tsv)
    $readerPass = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-reader-password" --query value -o tsv)
    $readWriteName = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-rw-name" --query value -o tsv)
    $readWritePass = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-rw-password" --query value -o tsv)
} catch {
  Write-Host "Error retrieving keyvault secrets" -ForegroundColor Red
} finally {
  Write-host "Removing keyvault firewall rule" -ForegroundColor White
  az keyvault network-rule remove --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP
}

$ruleName = "temp-migration-rule-$([Guid]::NewGuid())"
Write-host "Adding firewall rule $ruleName for $agentIP" -ForegroundColor White
az sql server firewall-rule create -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName --start-ip-address $agentIP --end-ip-address $agentIP

$serverName = "$($parameters.parameters.sidi_sqlserver_name.value).database.windows.net"

try {
    # Database AD users
    Write-Host "Running script: InitialiseDatabaseAdUsers_Mdm.sql"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_mdm_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseAdUsers_Mdm.sql" `
      -v df_identity="$($parameters.parameters.sidi_datafactory_name.value)" `
      -G -l 30
    
    if( -not $?) {
      Write-Error "Error running script: InitialiseDatabaseAdUsers_Mdm.sql"
      throw
    }

    Write-Host "Running script: InitialiseDatabaseAdUsers_Master.sql"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_master_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseAdUsers_Master.sql" `
      -v df_identity="$($parameters.parameters.sidi_datafactory_name.value)" `
      -G -l 30
    
      if( -not $?) {
        Write-Error "Error running script: InitialiseDatabaseAdUsers_Master.sql"
        throw
      }
    
    Write-Host "Running script: InitialiseDatabaseAdUsers_Reporting.sql"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_reporting_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseAdUsers_Reporting.sql" `
      -v df_identity="$($parameters.parameters.sidi_datafactory_name.value)" `
      -G -l 30
    
      if( -not $?) {
        Write-Error "Error running script: InitialiseDatabaseAdUsers_Reporting.sql"
        throw
      }

      #Database sql users
      Write-Host "Running script: InitialiseDatabaseUsers_Mdm.sql"
      sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_mdm_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseUsers_Mdm.sql" `
      -v reader_name="$($readerName)" reader_password="$($readerPass)" rw_name="$($readWriteName)" rw_password="$($readWritePass)" `
      -G -l 30
    
      if( -not $?) {
        Write-Error "Error running script: InitialiseDatabaseUsers_Mdm.sql"
        throw
      }

    Write-Host "Running script: InitialiseDatabaseUsers_Master.sql"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_master_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseUsers_Master.sql" `
      -v reader_name="$($readerName)" reader_password="$($readerPass)" rw_name="$($readWriteName)" rw_password="$($readWritePass)" `
      -G -l 30
    
      if( -not $?) {
        Write-Error "Error running script: InitialiseDatabaseUsers_Master.sql"
        throw
      }

    Write-Host "Running script: InitialiseDatabaseUsers_Reporting.sql"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_reporting_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$DatabaseArtifactPath\Scripts\Initialisation\InitialiseDatabaseUsers_Reporting.sql" `
      -v reader_name="$($readerName)" reader_password="$($readerPass)" rw_name="$($readWriteName)" rw_password="$($readWritePass)" `
      -G -l 30
    
      if( -not $?) {
        Write-Error "Error running script: InitialiseDatabaseUsers_Reporting.sql"
        throw
      }

      # Just In case
      Start-Sleep -Seconds 5

      # New DF Identity - Only for MDM database - Change related to API
      $getEnvType = checkEnvType -et $Environment
      Write-Host "Running script: InitialiseDatabaseAdUsers.sql for MDM Database"
      sqlcmd `
        -S $serverName `
        -d $coreParams.sql_database_mdm_name `
        -U $adminUser `
        -P $adminPass `
        -i "$PSScriptRoot\sql-scripts\InitialiseDatabaseAdUsers.sql" `
        -v df_identity="az-mdm-$getEnvType" `
        -G -l 30

      if( -not $?) {
          Write-Error "Error running script: InitialiseDatabaseAdUsers.sql"
          throw
      }    
} catch {
    Write-Host "Error processing sql scripts" -ForegroundColor Red
    throw
} finally {
    Write-host "Removing firewall rule" -ForegroundColor White
    az sql server firewall-rule delete -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName
}
