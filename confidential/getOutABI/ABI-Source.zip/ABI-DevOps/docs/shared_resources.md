# Shared Resources

Each ABI environment makes use of some shared resources which should be deployed prior to any other environments.

## Resources

The resources in the shared environment are either template controlled or manually created. 
The items are defined below:

| Item                       | Deployment method              |
| -------------------------- | ------------------------------ |
| Power BI Embedded resource | Manual                         |
| Shared Azure Data Factory  | Manual                         |
| Log Analytics Workspace    | sharedResources.bicep template |

## Deployment

To deploy the automated resources run the Deploy-SharedResources.ps1 script.