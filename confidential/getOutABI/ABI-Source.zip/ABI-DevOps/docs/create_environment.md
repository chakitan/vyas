# Create environment

This document describes the process of creating a new instance of ABI.

An instance of ABI is formed of two related resource groups:

- SIDI: The core elements based around Azure Data Factory.
- Visualisation: The Power BI based portal.

This repository controls the initialisation of both but the deployment of Visualisation
is controlled by the separate ABI-Web repository.

## Limitations

The Shared DataFactory and Integration runtime were provisioned manually.
Deployment instructions for these elements are not included in these instructions.

## Prerequisites

In order to create the environment instance the following prerequisites should be in place.

### Administor Account

Your user account should have the following permissions:

- Sufficient Azure subscription permissions to create a resource group and assign RBAC roles.
- Sufficient Azure Devops permissions to create Pipelines and a service connection.

### Development Environment

A development environment with the following software installed:

- Azure CLI
- Python
- j2cli[yaml] (python library) can be installed by running the following command:
  `python -m pip install j2cli[yaml]`

### Secrets

The following secrets will also be required:

| Item                              | Description                                              |
| --------------------------------- | -------------------------------------------------------- |
| MarketPoint_oAuthBearerPassword   | The oath bearer token for MarketPoint (is this right??)  |
| mdm_on_prem_dw_connection_string  | The connection string for the on premises data-warehouse |
| mdm_on_prem_mds_connection_string | The connection string for the on premises mds db         |
| SOPs_QA_12_connection_string      | The connection string for SOPS                           |
| ext-sftp-user-userName            | The username for the sftp site                           |
| ext-sftp-user-password            | The password for the sftp site                           |
| MarketPoint-API-Url               | The URL for the Marketpoint API                          |
| sidi-sqlserver-admin-password     | The desired password for the sql server admin            |
| sidi-sqlserver-rw-password        | The desired password for the sql read/write account      |
| sidi-sqlserver-reader-password    | The desired password for the sql reader account          |

### Azure AD Assets

Due to restrictions on the Civica Azure AD tenant the following Azure AD assets should be set up manually:

| Item                           | Required Privileges | Required Information |
| ------------------------------ | ------------------- | -------------------- |
| Sql Azure AD Admin user        | n/a                 | Username, Password   |
| Visualisation App Registration | TBC                 | DisplayName          |
| Power BI Service Principal     | TBC                 | DisplayName          |

Note: The required information will be requested by the initialisation script.

### Shared Resources

SIDI makes use of a manually deployed Shared instance of Azure DataFactory and accompanying Integration Runtime.
This should be in-place prior to deployment.

In addition, some shared resource deployment is controlled by template as described [here](shared_resources.md).

## Create configuration

To create the configuration create a folder in the templates\environments folder (e.g. dev, test etc.)  
Within the folder create an _environment.yml file and populate with the following information:

| Item                                       | Description                                                                    |
| ------------------------------------------ | ------------------------------------------------------------------------------ |
| env                                        | The environment identifier (e.g. dev, test etc.)                               |
| subscription_id                            | The Azure subscription id                                                      |
| location                                   | The Azure location e.g. uksouth                                                |
| group_shared_name                          | The resource group name for the shared DataFactory                             |
| datafactory_shared_name                    | The shared DataFactory name                                                    |
| datafactory_integrationruntime_shared_name | The shared Integration Runtime name                                            |
| portal_app_registration_suffix             | The suffix used for the manually created Visualisation portal app registration |

Run the templates\Generate-EnvironmentConfig.ps1 script to generate the required configuration.

Check the new files into source control.

## Initialise environment

From a command or powershell window log in to Azure and set your subscription using the following commands:

```cmd
az login
az account set --subscription <subscription_id>
```

Run the Initialise-Environment.ps1 script for your chosen environment:

```cmd
.\Initialise-Environment.ps1 -Environment <env>
```

Initialisation puts in place the core elements required for both SIDI and Visualisation deployments.

- Provision the resource group and the deployment components (storage account, keyvault)
- Populate assets (required scripts)
- Generate passwords and store in keyvault.
- Allow manual entry of secrets (see prerequisites) and store in keyvault.
- Azure AD assets: Both creation of new items and recording of manually created items.

## Create service connection

A user with administrative rights on the subscription should create a Service connection
in Azure DevOps for the created resource group.
In addition to the default contributor role, the user access administrator role should
be granted on the resource group to the underlying service principal.  
The Initialise-ServiceConnection script should be run to:

- Configure access to the core keyvault for the Service connection
- Store the object ids of service connection principals (environment and shared)

The script can be run with the following command:

```cmd
.\Initialise-ServiceConnection.ps1 -Environment <env>
```

## Set up the pipeline

The pipeline is defined in Azure Devops under 'Pipelines -> Releases -> ABI SIDI Deployment'.  
To add a new stage:

- Click the Edit button.
- Creat a new stage by Clicking Add -> New Stage.
- Select Empty job.
- Name the stage and click on the '1 job, 0 tasks' link for the new stage.
- Click the + button and choose the Deploy ABI task-group.
- Click Add and then select the task.
- Modify the subscription parameter to your created service connection.
- Navigate to the variables tab and add a new variable scoped to your stage with the value matching your environment identifier (e.g. dev or uat.)
- Click Save.

## Run the pipeline

Ensure the ABI-Databases pipeline has run successfully and that the artifact has been published.
To run the pipeline for your environment click on Create release:

- Ensure any environments which will automatically be triggered are switched to manual as desired.
- Click ok.

The pipeline will deploy all environment resources and separately the data factory components.

## Deploy Visualisation

The Visualisation portal can now be deployed.
Instructions on deploying the portal can be found in the ABI-Web repository.

## Recreating an environment

If you are recreating an environment from scratch by tearing down all of the existing resources,
you will need to ensure that all role assignments to the deleted factory are removed from the linked
integration runtime in the shared datafactory.

To do this:

- Navigate to Resource Groups -> rg-sidi-shared -> df-sidi-shared.
- Click on Author and Monitor then Manage -> Integration Runtimes.
- Select the Abi... shared runtime and click 'Sharing'.
- Remove any entries for your chosen environment.
