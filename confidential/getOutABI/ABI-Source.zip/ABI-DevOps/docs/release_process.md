# Release process

## Overview

The deployment of the ABI project is defined by three repositories:

- ABI-Databases: Defines the three databases and publishes dacpacs and scripts to provision.
- ABI-DevOps: Defines the Azure Infrastructure and scripts for deploying all elements of the ABI system.
- ABI-SIDI: The Azure Data Factory repository which defines the datafactory and publishes deployment templates to the adf_publish branch.

The DevOps processes used to deploy the ABI project to Azure is described well by it's Azure DevOps release:

![Azure DevOps release](./images/azure-devops-release.png)

## Artifacts

Three artifacts feed into the process:

**_ABI-Databases**: Code checked into the master branch of the ABI-Databases repository will trigger the ABI-Databases pipeline.  
Successful runs of this pipeline publish an artifact containing the resultant databases .dacpac files for each database and supplemental scripts.  
As required, database package updates can be used to trigger a release.

**_ABI-DevOps**: The master branch of the ABI-Devops repository feeds into the deployment, supplying deployment scripts and infrastructure templates.  
Changes to the repository do not trigger a release.

**_ABI-SIDI**: When the Azure Data Factory is published through the authoring and monitoring portal changes are pushed to the adf_publish branch of the ABI-SIDI repository.  
The adf_publish branch contains templates for deployment of ADF components on top of the infrastructure supplied by the ABI-DevOps repository.  
Changes to the adf_branch trigger a release.

## Stages

As indicated in the diagram, there are separate release stages which correspond to individual environments.  
Each stage follows the last. Later stages require manual approval before deployment:

| Stage   | Purpose                                                       | Currently in pipeline | Notes                                                     |
| ------- | ------------------------------------------------------------- | --------------------- | --------------------------------------------------------- |
| devops  | Initial environment used for integration testing of the three | Yes                   | Auto deployed for each new release                        |
| devint  | Integration environment                                       | Yes                   |                                                           |
| test    | Test environment used for formal testing                      | Yes                   | Follows deployment to devops. Requires manual approval    |
| uat     | User acceptance testing environment                           | Yes                   | Follows deployment to test. Requires manual approval      |
| preprod | Pre-Production environment                                    | Yes                   | Follows deployment to uat. Requires manual approval .     |
| prod    | Production environment                                        | Yes                   | Follows deployment to preprod. Requires manual approval . |

## Deployment

Deployment is made of the following tasks as defined in the 'Deploy ABI' task group in Azure Devops:

![Deploy ABI task group](./images/azure-devops-taskGroup.png)

**Deploy Azure Infrastructure**: Deploys the underlying infrastructure (e.g Sql server, vnet etc.)

**Configure Shared Integration Runtime access**: Ensure the environment has access to the shared integration runtime in the df-sidi-shared data factory.

**Deploy Excel Reader Function App**: Deploys the Excel Reader Function App.

**Deploy Database**: Deploys the database dacpacs for each database.

**Deploy LogicApps**: Deploys the Azure Logic Apps.

**Deploy Database Users**:  Runs the supplemental database scripts (user creation and permission assignment.)

**Deploy Database Sync Users**:  Runs the supplemental database scripts of user creation and permission assignment needed for Database Sync

**Deploy DataFactory**: Runs the ADF deployment as defined in the adf_publish branch of the ABI-SIDI repository.
