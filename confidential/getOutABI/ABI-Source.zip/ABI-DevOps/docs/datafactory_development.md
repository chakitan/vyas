# DataFactory development

When authoring the ADF pipeline there are some important points to note with relation to the deployment.

## Custom parameters

On publish ADF pushes Azure resource manager templates to the adf_publish branch of the ABI_SIDI repository.  
Where we wish to customise elements of the generated ARM template the"parameterization template" must be updated.

To update this template navigate to the ADF authoring portal and then click on Manage => Parameterization template.  
Updates can be made following guidance as defined [here](https://docs.microsoft.com/en-us/azure/data-factory/continuous-integration-deployment#use-custom-parameters-with-the-resource-manager-template).

To test the changes the ARM template can be manually exported and inspected.  
Changes should be checked into a feature branch and submitted for pull request in the usual way.  
Once changes are reflected in the adf_publish branch then any new parameters should be populated in the `Deploy-DataFactory` script.

An example of this is the key_vault_base_url parameter which must be changed for each environment (e.g. test, uat.)  
To make this value updateable the following change was made to the parameterization template:

```json
    "Microsoft.DataFactory/factories/pipelines": {
        "properties": {
            "parameters": {
                "key_vault_base_url": {
                    "defaultValue": "="
                }
            }
        }
    },
    ...
```

This change was reflected in four additional parameters which are supplied in the `Deploy-DataFactory.ps1` script:

- PL_AUTH_OAUTH2_GENERATE_TOKEN_properties_parameters_key_vault_base_url_defaultValue
- PL_DATA_MDM_properties_parameters_key_vault_base_url_defaultValue
- PL_DATA_MDM_MarketPoint_properties_parameters_key_vault_base_url_defaultValue
- PL_MarketPoint_Source_ADLS_properties_parameters_key_vault_base_url_defaultValue

**NOTE: Care and attention must be paid when changing the names of pipeline components,**  
**as they would be reflected in changes to the parameter names and would require further updates**  
**to the `Deploy-DataFactory.ps1` script.**
