# Introduction

The Abi-Devops repo contains deployment assets required for automated deployment.

## Contents

[Create environment](docs/create_environment.md) describes how to create an instance of the software.  
[DataFactory development](docs/datafactory_development.md) highlights some important devops considerations when developing in ADF.  
[Release process](docs/release_process.md) describes the release process for the ABI system.
