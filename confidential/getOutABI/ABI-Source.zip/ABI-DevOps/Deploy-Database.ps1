<#
.SYNOPSIS
    Deploys the database from dacpac.
    Dacpacs are published by the ABI-Database pipeline.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.PARAMETER DatabaseArtifactPath
    Path to the database artifact folder.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devopstest",
    [Parameter()]
    [string]
    $DatabaseArtifactPath = "$PSScriptRoot\..\ABI-Databases"
)

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\main-parameters.json" | ConvertFrom-Json
$deploymentParameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Obtain the agent ip for firewall purposes.
Write-Host "Obtaining agent ip."
  #$agentIP = (New-Object net.webclient).downloadstring("https://ifconfig.me/ip") # DEPRECATED
$agentIP = (Invoke-WebRequest https://ifconfig.me/ip | Select-Object Content) -replace "[^\d\.]"

# Pull keyvault values.
Write-host "Adding keyvault firewall rule for $agentIP" -ForegroundColor White
az keyvault network-rule add --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP

try {
    Write-Host "Pulling secrets from infrastructure vault." -ForegroundColor Cyan
    $sqlAdminName = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-admin-name" --query value -o tsv)
    $sqlAdminPassword = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-admin-password" --query value -o tsv)
    $sqlMasterEncryptionKeyPassword = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-db-master-encryptionKey-password" --query value -o tsv)
    $sqlCrossDbUserPassword = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-db-master-crossdbuser-password" --query value -o tsv)
} catch {
  Write-Host "Error retrieving keyvault secrets" -ForegroundColor Red
} finally {
  Write-host "Removing keyvault firewall rule" -ForegroundColor White
  az keyvault network-rule remove --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP
}

$ruleName = "temp-migration-rule-$([Guid]::NewGuid())"
Write-host "Adding firewall rule $ruleName for $agentIP" -ForegroundColor White
az sql server firewall-rule create -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName --start-ip-address $agentIP --end-ip-address $agentIP

$serverName = "$($parameters.parameters.sidi_sqlserver_name.value).database.windows.net"

try {
  Write-Host "Deploying master database dacpac."
  & "C:\Program Files\Microsoft SQL Server\160\DAC\bin\SqlPackage.exe" `
    /Action:Publish `
    /SourceFile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-master-dev\bin\Debug\sqldb-abi-master.dacpac" `
    /TargetServerName:$serverName `
    /TargetDatabaseName:"$($parameters.parameters.sidi_sqlserver_db_master_name.value)" `
    /TargetUser:$sqlAdminName `
    /TargetPassword:$sqlAdminPassword `
    /Profile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-master-dev\sqldb-abi-master.publish.xml" `
    /Variables:abicrossdbuserpasswordreport=$sqlCrossDbUserPassword `
    /Variables:abicrossdbuserpasswordmaster=$sqlCrossDbUserPassword `
    /Variables:dbmastername="$($parameters.parameters.sidi_sqlserver_db_master_name.value)" ` `
    /Variables:dbreportname="$($parameters.parameters.sidi_sqlserver_db_reporting_name.value)" `
    /Variables:masterkeypassword=$sqlMasterEncryptionKeyPassword `
    /Variables:servername=$serverName `
    /p:BlockOnPossibleDataLoss=false

  if( -not $?) {
    Write-Error "Error deploying master database."
    throw
  }

  Write-Host "Deploying report database dacpac."
  & "C:\Program Files\Microsoft SQL Server\160\DAC\bin\SqlPackage.exe" `
    /Action:Publish `
    /SourceFile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-report-dev\bin\Debug\sqldb-abi-report.dacpac" `
    /TargetServerName:$serverName `
    /TargetDatabaseName:"$($parameters.parameters.sidi_sqlserver_db_reporting_name.value)" `
    /TargetUser:$sqlAdminName `
    /TargetPassword:$sqlAdminPassword `
    /Profile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-report-dev\sqldb-abi-report.publish.xml" `
    /Variables:abicrossdbuserpasswordreport=$sqlCrossDbUserPassword `
    /Variables:abicrossdbuserpasswordmaster=$sqlCrossDbUserPassword `
    /Variables:dbmastername="$($parameters.parameters.sidi_sqlserver_db_master_name.value)" `
    /Variables:masterkeypassword=$sqlMasterEncryptionKeyPassword `
    /Variables:servername=$serverName `
    /p:BlockOnPossibleDataLoss=false

  if( -not $?) {
    Write-Error "Error deploying report database"
    throw
  }

  Write-Host "Deploying mdm database dacpac."
  & "C:\Program Files\Microsoft SQL Server\160\DAC\bin\SqlPackage.exe" `
    /Action:Publish `
    /SourceFile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-mdm-dev\bin\Debug\sqldb-abi-mdm.dacpac" `
    /TargetServerName:$serverName `
    /TargetDatabaseName:"$($parameters.parameters.sidi_sqlserver_db_mdm_name.value)" `
    /TargetUser:$sqlAdminName `
    /TargetPassword:$sqlAdminPassword `
    /Profile:"$DatabaseArtifactPath\AbiDatabasesDeployment\sqldb-abi-mdm-dev\sqldb-abi-mdm.publish.xml" `
    /Variables:abicrossdbuserpasswordreport=$sqlCrossDbUserPassword `
    /Variables:abicrossdbuserpasswordmaster=$sqlCrossDbUserPassword `
    /Variables:dbmastername="$($parameters.parameters.sidi_sqlserver_db_master_name.value)" ` `
    /Variables:dbreportname="$($parameters.parameters.sidi_sqlserver_db_reporting_name.value)" `
    /Variables:masterkeypassword=$sqlMasterEncryptionKeyPassword `
    /Variables:servername=$serverName `
    /p:BlockOnPossibleDataLoss=false

  if( -not $?) {
    Write-Error "Error deploying mdm database."
    throw
  }

} catch {
    Write-Host "Error processing sql scripts" -ForegroundColor Red
    throw
} finally {
    Write-host "Removing firewall rule" -ForegroundColor White
    az sql server firewall-rule delete -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName
}
