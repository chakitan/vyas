<#
.SYNOPSIS
    Deploys the environment infrastructure to Azure.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.PARAMETER ReleaseName
    Optional release name
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops",

    [Parameter()]
    [string]
    $ReleaseName = ""
)

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Deploy main components
$deploymentName = "sidi-deployment-main-$([Guid]::NewGuid())"
Write-Host "Running deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParams.group_name `
  --template-file "$PSScriptRoot\templates\main-template.json" `
  --parameters "$PSScriptRoot\templates\parameters\environments\$Environment\main-parameters.json" `
  --parameters release_version=$ReleaseName


$deploymentName = "sidi-deployment-vm-$([Guid]::NewGuid())"
Write-Host "Running vm deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParams.group_name `
  --template-file "$PSScriptRoot\templates\vm-template.json" `
  --parameters "$PSScriptRoot\templates\parameters\environments\$Environment\vm-parameters.json" `
  --parameters release_version=$ReleaseName

