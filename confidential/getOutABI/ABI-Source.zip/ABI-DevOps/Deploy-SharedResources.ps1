<#
.SYNOPSIS
    Deploys the shared resources to the shared resource group.
    Note: Not all resources in the group are controlled by the template.
    Always run this deployment in the default Incremental mode.

#>

# Pull parameters into variables 
# Note: The prod file is used as this deployment is universal
Write-Host "Pulling variables from parameter files."
$coreParameters = Get-Content "$PSScriptRoot\templates\parameters\environments\prod\core-parameters.json" | ConvertFrom-Json

$deploymentName = "sidi-deployment-shared-$([Guid]::NewGuid())"
Write-Host "Running vm deployment: $deploymentName"
az deployment group create `
    --name $deploymentName `
    --template-file "$PSScriptRoot\templates\sharedResources.bicep" `
    --resource-group $coreParameters.group_shared_name