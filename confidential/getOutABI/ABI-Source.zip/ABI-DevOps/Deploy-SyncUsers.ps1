<#
.SYNOPSIS
    Deploys the database users from script.
    Parameters must be correctly supplied to each script run.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.NOTES
    Change Log:     MAY'22 Created
    Chakitan Vyas
#>

[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops"
)


# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\main-parameters.json" | ConvertFrom-Json
$deploymentParameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Obtain the agent ip for firewall purposes.
Write-Host "Obtaining agent ip."
$agentIP = (Invoke-WebRequest https://ifconfig.me/ip | Select-Object Content) -replace "[^\d\.]"

# Pull keyvault values.
Write-host "Adding keyvault firewall rule for $agentIP" -ForegroundColor White
az keyvault network-rule add --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP

try {
    Write-Host "Pulling secrets from infrastructure vault." -ForegroundColor Cyan
    $adminUser = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-admin-name" --query value -o tsv)
    $adminPass = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "sidi-sqlserver-admin-password" --query value -o tsv)
    $userPass  = $(az keyvault secret show --vault-name $deploymentParameters.parameters.sidi_corevault_name.value --name "abi-datasync-password" --query value -o tsv)
} catch {
  Write-Host "Error retrieving keyvault secrets" -ForegroundColor Red
} finally {
  Write-host "Removing keyvault firewall rule" -ForegroundColor White
  az keyvault network-rule remove --name $deploymentParameters.parameters.sidi_corevault_name.value --ip-address $agentIP
}

$ruleName = "temp-migration-rule-$([Guid]::NewGuid())"
Write-host "Adding firewall rule $ruleName for $agentIP" -ForegroundColor White
az sql server firewall-rule create -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName --start-ip-address $agentIP --end-ip-address $agentIP

$serverName = "$($parameters.parameters.sidi_sqlserver_name.value).database.windows.net"

try {
    # $Script:getEnvType = checkEnvType -et $Environment

    # Server Login and User
    Write-Host "Running script: AddSyncUsersOnServer for Server"
    sqlcmd `
    -S $serverName `
    -U $adminUser `
    -P $adminPass `
    -i "$PSScriptRoot\sql-scripts\AddSyncUsersOnServer.sql" `
    -v dbsync_user="$("abi-$Environment-sync")" dbsync_login="$("abi-$Environment-sync")" dbsync_login_pass=$userPass `
    -l 60

    if( -not $?) {
        Write-Error "Error running script: AddSyncUsersOnServer.sql"
        throw
    }    

    # Database User
    Write-Host "Running script: AddSyncUsersOnDatabase for MDM Database"
    sqlcmd `
      -S $serverName `
      -d $parameters.parameters.sidi_sqlserver_db_mdm_name.value `
      -U $adminUser `
      -P $adminPass `
      -i "$PSScriptRoot\sql-scripts\AddSyncUsersOnDatabase.sql" `
      -v dbsync_user="$("abi-$Environment-sync")" dbsync_login="$("abi-$Environment-sync")" `
      -l 60

    if( -not $?) {
        Write-Error "Error running script: AddSyncUsersOnDatabase.sql"
        throw
    }    
} catch {
    Write-Host "Error processing sql scripts" -ForegroundColor Red
    throw
} finally {
    Write-host "Removing firewall rule" -ForegroundColor White
    az sql server firewall-rule delete -g $coreParams.group_name -s $parameters.parameters.sidi_sqlserver_name.value -n $ruleName
}
