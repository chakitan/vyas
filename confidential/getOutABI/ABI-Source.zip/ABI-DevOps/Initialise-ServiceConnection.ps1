<#
.SYNOPSIS
    Sets up permissions and stores data for the preconfigured service connections.

.PARAMETER Environment
    The environment e.g. dev, test, uat.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops"
)

. "$PSScriptRoot\scripts\InfrastructureOperations.ps1"

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\deployment-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Confirm access policy for deployment principal
Write-Host "Please identify the object id of the environment service connection principal."
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName ad-sp-deploymentPrincipal-objectId

Write-Host "Ensuring access policy to deployment keyvault for deployment principal."
$deploymentPrincipalObjectId = $(az keyvault secret show --vault-name $parameters.parameters.sidi_corevault_name.value --name "ad-sp-deploymentPrincipal-objectId" --query value -o tsv)
az keyvault set-policy --name $parameters.parameters.sidi_corevault_name.value --object-id $deploymentPrincipalObjectId --secret-permissions get

if ($coreParams.use_logAnalytics -eq 'true') {
    Write-Host "Ensuring log analytics role assignment on shared resource group for deployment principal."

    az role assignment create `
        --assignee $deploymentPrincipalObjectId `
        --role "Log Analytics Contributor" `
        --resource-group $coreParams.group_shared_name
}

# Ensure the shared connection object id is recorded.
Write-Host "Please identify the object id of the shared service connection principal."
Add-UserEnteredSecret -VaultName $parameters.parameters.sidi_corevault_name.value -SecretName ad-sp-sharedDeploymentPrincipal-objectId