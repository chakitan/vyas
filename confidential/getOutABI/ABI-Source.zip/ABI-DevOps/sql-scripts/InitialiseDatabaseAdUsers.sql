/*********************************************************************************************************
**** Initialisation script for the master database ****
*********************************************************************************************************/

DECLARE @t nvarchar(4000);

/**********************************************************
**** Add Managed Identities ****
**********************************************************/ 

--Select appropriate database with an admin role
--Add Contained user to the database
IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = '$(df_identity)')
    SET @t = N'CREATE USER [$(df_identity)] FROM EXTERNAL PROVIDER';
    EXEC sp_executesql @t;
    SET @t = N'GRANT CONNECT TO [$(df_identity)]';
    EXEC sp_executesql @t;

/**********************************************************
**** Assign database roles ****
**********************************************************/ 

--Update User roles with appropriate policies
SET @t = N'ALTER ROLE [db_datawriter] ADD MEMBER [$(df_identity)]'
EXEC sp_executesql @t;

SET @t = N'ALTER ROLE [db_datareader] ADD MEMBER [$(df_identity)]'
EXEC sp_executesql @t;

SET @t = N'ALTER ROLE [db_executor] ADD MEMBER [$(df_identity)]'
EXEC sp_executesql @t;
