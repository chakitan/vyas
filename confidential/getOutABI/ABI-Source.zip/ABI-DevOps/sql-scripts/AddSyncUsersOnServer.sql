/*********************************************************************************************************
**** Initialisation script for the master database ****
*********************************************************************************************************/

DECLARE @t nvarchar(4000);

/**********************************************************
**** Add Server Login and User ****
**********************************************************/ 

IF NOT EXISTS (SELECT * FROM sys.sql_logins WHERE name = '$(dbsync_login)')
    CREATE LOGIN [$(dbsync_login)] WITH PASSWORD='$(dbsync_login_pass)';

IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = '$(dbsync_user)')
    CREATE USER [$(dbsync_user)] FOR LOGIN [$(dbsync_login)] WITH DEFAULT_SCHEMA = dbo;
