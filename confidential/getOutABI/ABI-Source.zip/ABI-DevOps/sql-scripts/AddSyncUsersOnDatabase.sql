/*********************************************************************************************************
**** Initialisation script for the master database ****
*********************************************************************************************************/

DECLARE @t nvarchar(4000);

/**********************************************************
**** Add database User ****
**********************************************************/ 

--Select appropriate database with an admin role
--Add Contained user to the database
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = '$(dbsync_user)')
    CREATE USER [$(dbsync_user)] FOR LOGIN [$(dbsync_login)] WITH DEFAULT_SCHEMA = dbo;
    
    GRANT CONNECT TO [$(dbsync_user)];
    

/**********************************************************
**** Assign database roles ****
**********************************************************/ 

--Update User roles with appropriate policies
--ALTER ROLE [db_owner] ADD MEMBER [$(dbsync_user)]

-- Add role
EXEC sp_addrolemember N'db_owner', N'$(dbsync_user)'
