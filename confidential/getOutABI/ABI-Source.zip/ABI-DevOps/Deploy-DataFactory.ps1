<#
.SYNOPSIS
    Deploys the datafactory components.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.PARAMETER TemplatePath
    Path to the resource manager template file.

.PARAMETER ParametersPath
    Path to the resource manager template parameters file.
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops",
    [Parameter()]
    [string]
    $TemplatePath = "$PSScriptRoot\..\ABI-SIDI\df-sidi-dev\ARMTemplateForFactory.json",
    [Parameter()]
    [string]
    $ParametersPath = "$PSScriptRoot\..\ABI-SIDI\df-sidi-dev\ARMTemplateParametersForFactory.json"
)

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$parameters = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\main-parameters.json" | ConvertFrom-Json
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

$dataLakeStorageUrl = "https://$($parameters.parameters.sidi_datalakestorage_name.value).dfs.core.windows.net"
$keyvaultUrl = "https://$($parameters.parameters.sidi_keyvault_name.value).vault.azure.net"
$datafactoryName = $parameters.parameters.sidi_datafactory_name.value

# Deploy adf components
$deploymentName = "sidi-deployment-adf-$([Guid]::NewGuid())"
Write-Host "Running deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParams.group_name `
  --template-file $TemplatePath `
  --parameters $ParametersPath `
  --parameters `
    factoryName=$datafactoryName `
    LS_ADLS_sidi_OnPremIR_properties_typeProperties_url=$dataLakeStorageUrl `
    LS_ADLS_sidi_vnet_properties_typeProperties_url=$dataLakeStorageUrl `
    LS_KeyVault_kv_sidi_properties_typeProperties_baseUrl=$keyvaultUrl `
    dataFactory_properties_globalParameters_key_vault_base_url_value=$keyvaultUrl
