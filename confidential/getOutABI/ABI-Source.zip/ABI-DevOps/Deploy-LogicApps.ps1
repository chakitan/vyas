<#
.SYNOPSIS
    Deploys the logic apps and associated infrastructure to Azure.

.PARAMETER Environment
    The environment e.g. dev, test, uat.

.PARAMETER ReleaseName
    Optional release name
#>
[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $Environment = "devops",

    [Parameter()]
    [string]
    $ReleaseName = ""
)

# Pull parameters from file.
Write-Host "Pulling variables from parameter files."
$coreParams = Get-Content "$PSScriptRoot\templates\parameters\environments\$Environment\core-parameters.json" | ConvertFrom-Json

# Deploy logic app components
$deploymentName = "sidi-deployment-logicApps-$([Guid]::NewGuid())"
Write-Host "Running deployment: $deploymentName"
az deployment group create `
  --name $deploymentName `
  --resource-group $coreParams.group_name `
  --template-file "$PSScriptRoot\templates\logicApps-template.json" `
  --parameters "$PSScriptRoot\templates\parameters\environments\$Environment\logicApps-parameters.json" `
  --parameters release_version=$ReleaseName
