# Introduction 

Referring to the image below, the database sync automation is created. Using Database Sync Functionality of Azure the MDM databases in ABI are synced. One MDM database is assigned as Hub and all other MDM datbases are members to it (different to nonprod and prod). 
![MDM Architecture](./databaseSyncPlan.png)

# Getting Started   
1.	[Prerequisites](#pre-requisites)
2.	[Release Process](#release-process)
3.	[Limitations](#notes-and-limitations)
4.	[References](#references)

# Pre-requisites
1. User and Login on databases (hub, member, metadata) and Server
   * User must have db_owner role on hub & member databases
   * User automatically gets Datasync_executor role on metadata database.
   - User addition script ``` ABI-DevOps/Deploy-SyncUsers.ps1 ``` is run in ``` ABI SIDI Deployment ``` Pipeline
2. Service Principal should have role assignment on 
   * Shared Metadata Database Server Resource Groups (both prod & nonprod) --> SQL Server Contributor 
   * MDM Database Resource Groups (all sidi RGs) --> SQL Server Contributor | Key Vault Contributor
   - Note: Key Vault Contributor role is required along side Access Policies - Get & List of Secrets
3. Core Keyvault of each environment should have Username and Password of new user (this is handled in Initialise-Environment.ps1 Script)

# Release process

## Artifacts

**_ABI-DatabaseSync**: contains the required scripts and parameter files for deployment. Check in to master to start database sync


## Stages

nonprod (env: devint dev test | hub: mdm devint | members: mdm dev test)

prod (env: uat preprod prod | hub: mdm prod | member: mdm uat preprod)


## Deployment

**Create DBSync**: Created required Infra for database sync (Creating Sync Group & Sync Member, Adding hub, metadata, member Databases)

**Configure SyncSchema**: Runs Schema Refresh, Schema Updation on the Sync Group. Also, triggers the sync.

# Notes and Limitations

> Azure PowerShell module is sufficient for Database Sync. However, due to vague Error arrived when using ``` New-AzSqlSyncGroup ```, APIs are used to create Sync Group and Sync Members.


# References
[Sync Group API](https://docs.microsoft.com/en-us/rest/api/sql/2021-02-01-preview/sync-groups)

[Sync Member API](https://docs.microsoft.com/en-us/rest/api/sql/2021-02-01-preview/sync-members)

[What is Data Sync?](https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-data-sync-data-sql-server-sql-database?view=azuresql)

[Best Practices](https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-data-sync-best-practices?view=azuresql)