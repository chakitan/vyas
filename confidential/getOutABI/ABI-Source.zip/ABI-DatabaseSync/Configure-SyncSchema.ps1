using namespace Microsoft.Azure.Commands.Sql.DataSync.Model
using namespace System.Collections.Generic

[CmdletBinding()]
param (
    $envType = 'devops'
)

$groupParam  = Get-Content "$PSScriptRoot\parameters\$envType\dbsync-group-parameters.json" | ConvertFrom-Json
$schemaParam = Get-Content "$PSScriptRoot\parameters\$envType\dbsync-schema-parameters.json" | ConvertFrom-Json

function Exec-Sync(){
    try{
        # temp file to save the sync schema 
        $tempFile = $env:TEMP+"\syncSchema.json"
        
        if(Test-Path $tempFile){
            Clear-Content $tempFile
        }
        
        $includedColumnsAndTables = New-Object "System.Collections.Generic.List[[String]]"
        # list of included columns and tables in quoted name
        # get the tables and columns from dbsync-schema-parameters.json
        for($x=0;$x -lt $schemaParam.tables.Length; $x+=1){
            if ($($schemaParam.tables[$x].columns.Length) -ge 1) {
                for($y=0;$y -lt $($schemaParam.tables[$x].columns.Length);$y+=1){
                    $includedColumnsAndTables.Add("$($schemaParam.tables[$x].name).[$($schemaParam.tables[$x].columns[$y])]")
                }    
            }
            else{
                $includedColumnsAndTables.Add("$($schemaParam.tables[$x].name)")
            }            
        }
                                
        $metadataList = [System.Collections.ArrayList]::new($includedColumnsAndTables)

        # refresh database schema from hub database, specify the -SyncMemberName parameter if you want to refresh schema from the member database   
        Write-Host "`nRefreshing database schema from hub database..." -Foregroundcolor DarkCyan
        $startTime = Get-Date   
        Update-AzSqlSyncSchema -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value `
            -SyncGroupName $groupParam.parameters.SyncGroupName.value

        # waiting for successful refresh
        $startTime = $startTime.ToUniversalTime()
        $timer=0
        $timeout=90

        # check the log and see if refresh has gone through
        Write-Host "`nCheck for successful refresh..." -ForegroundColor DarkCyan
        $isSucceeded = $false
        while ($isSucceeded -eq $false) {
            Start-Sleep -s 10
            $timer=$timer+10
            $details = Get-AzSqlSyncSchema -SyncGroupName $groupParam.parameters.SyncGroupName.value -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value -ResourceGroupName $groupParam.rgName
            if ($details.LastUpdateTime -gt $startTime) {
                Write-Host "`nRefresh was successful" -Foregroundcolor DarkCyan
                $isSucceeded = $true
            }
            if ($timer -eq $timeout) {
                Write-Host "`nRefresh timed out" -Foregroundcolor Yellow
                break;
            }
        }

        # get the database schema
        Write-Host "`nAdding tables and columns to the sync schema..." -Foregroundcolor DarkCyan
        $databaseSchema = Get-AzSqlSyncSchema -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value `
            -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value -SyncGroupName $groupParam.parameters.SyncGroupName.value 

        $newSchema = [AzureSqlSyncGroupSchemaModel]::new()
        $newSchema.Tables = [List[AzureSqlSyncGroupSchemaTableModel]]::new();

        # add columns and tables to the sync schema
        foreach ($tableSchema in $databaseSchema.Tables) {
            $newTableSchema = [AzureSqlSyncGroupSchemaTableModel]::new()
            $newTableSchema.QuotedName = $tableSchema.QuotedName
            $newTableSchema.Columns = [List[AzureSqlSyncGroupSchemaColumnModel]]::new();
            $addAllColumns = $false
            if ($MetadataList.Contains($tableSchema.QuotedName)) {
                if ($tableSchema.HasError) {
                    $fullTableName = $tableSchema.QuotedName
                    Write-Host "`nCan't add table $fullTableName to the sync schema" -foregroundcolor "Red"
                    Write-Host $tableSchema.ErrorId -foregroundcolor "Red"
                    continue;
                }
                else {
                    $addAllColumns = $true
                }
            }
            foreach($columnSchema in $tableSchema.Columns) {
                $fullColumnName = $tableSchema.QuotedName + "." + $columnSchema.QuotedName
                if ($addAllColumns -or $MetadataList.Contains($fullColumnName)) {
                    if ((-not $addAllColumns) -and $tableSchema.HasError) {
                        Write-Host "`nCan't add column $fullColumnName to the sync schema" -foregroundcolor "Red"
                        Write-Host $tableSchema.ErrorId -foregroundcolor "Red"
                    }
                    elseif ((-not $addAllColumns) -and $columnSchema.HasError) {
                        Write-Host "`nCan't add column $fullColumnName to the sync schema" -foregroundcolor "Red"
                        Write-Host $columnSchema.ErrorId -foregroundcolor "Red"
                    }
                    else {
                        Write-Host "Adding"$fullColumnName" to the sync schema" -Foregroundcolor Cyan
                        $newColumnSchema = [AzureSqlSyncGroupSchemaColumnModel]::new()
                        $newColumnSchema.QuotedName = $columnSchema.QuotedName
                        $newColumnSchema.DataSize = $columnSchema.DataSize
                        $newColumnSchema.DataType = $columnSchema.DataType
                        $newTableSchema.Columns.Add($newColumnSchema)
                    }
                }
            }
            if ($newTableSchema.Columns.Count -gt 0) {
                $newSchema.Tables.Add($newTableSchema)
            }
        }

        # convert sync schema to JSON format    
        $schemaString = $newSchema | ConvertTo-Json -depth 5 -Compress

        # work around a PowerShell bug
        $schemaString = $schemaString.Replace('"Tables"', '"tables"').Replace('"Columns"', '"columns"').Replace('"QuotedName"', '"quotedName"').Replace('"MasterSyncMemberName"','"masterSyncMemberName"')

        # show & save the sync schema to a temp file
        $schemaString
        $schemaString | Out-File $tempFile

        # update sync schema
        Write-Host "`nUpdating the sync schema..." -Foregroundcolor DarkCyan
        Update-AzSqlSyncGroup -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value `
            -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value -Name $groupParam.parameters.SyncGroupName.value -Schema $tempFile

        $syncLogStartTime = Get-Date

        # trigger sync manually
        Write-Host "`nTrigger sync manually..." -Foregroundcolor DarkCyan
        Start-AzSqlSyncGroupSync -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value -SyncGroupName $groupParam.parameters.SyncGroupName.value
    }
    catch {
        Write-Host "`nError Processing Sync. Please Check::`n$Error[0]" -ForegroundColor Red
    }

    if(!$Error[0]){
        # check the sync log and wait until the first sync succeeded
        Write-Host "`nCheck the sync log..." -Foregroundcolor DarkCyan
        $isSucceeded = $false 
        for ($i = 0; ($i -lt 300) -and (-not $isSucceeded); $i = $i + 10) {
            Start-Sleep -s 10
            $syncLogEndTime = Get-Date
            $syncLogList = Get-AzSqlSyncGroupLog -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value `
            -SyncGroupName $groupParam.parameters.SyncGroupName.value -StartTime $syncLogStartTime.ToUniversalTime() -EndTime $syncLogEndTime.ToUniversalTime()

            if ($synclogList.Length -gt 0) {
                foreach ($syncLog in $syncLogList) {
                    if ($syncLog.Details.Contains("Sync completed successfully")) {
                        Write-Host $syncLog.TimeStamp : $syncLog.Details
                        $isSucceeded = $true
                    }
                }
            }
        }

        if ($isSucceeded) {
            # enable scheduled sync
            Write-Host "`nEnable the scheduled sync with 300 seconds interval..."
            Update-AzSqlSyncGroup  -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value `
                -Name $groupParam.parameters.SyncGroupName.value -IntervalInSeconds $groupParam.parameters.intervalInSeconds.value
        }
        else {
            # output all log if sync doesn't succeed in 300 seconds
            $syncLogEndTime = Get-Date
            $syncLogList = Get-AzSqlSyncGroupLog  -ResourceGroupName $groupParam.rgName -ServerName $groupParam.parameters.sidi_sqlserver_name.value -DatabaseName $groupParam.parameters.sidi_synchub_db_name.value `
                -SyncGroupName $groupParam.parameters.SyncGroupName.value -StartTime $syncLogStartTime.ToUniversalTime() -EndTime $syncLogEndTime.ToUniversalTime()

            if ($synclogList.Length -gt 0) {
                foreach ($syncLog in $syncLogList) {
                    Write-Host $syncLog.TimeStamp : $syncLog.Details
                }
            }
        }
    }
    else {
        exit 1
    }
}

Exec-Sync