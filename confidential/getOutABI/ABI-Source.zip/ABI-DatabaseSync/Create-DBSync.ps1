<#
    .SYNOPSIS
    Create DB Sync

    .DESCRIPTION
    creating sync group and members required for Database Sync Azure

    .NOTES
    Chakitan Vyas
    Change Log: APR'22 - Created
#>

[CmdletBinding()]
param (
    $envType = "devops"
)

$Script:groupParam  = Get-Content "$PSScriptRoot\parameters\$envType\dbsync-group-parameters.json" | ConvertFrom-Json
$Script:memberParam = Get-Content "$PSScriptRoot\parameters\$envType\dbsync-member-parameters.json" | ConvertFrom-Json


# Get environment based on Environment Type
if($envType -eq 'nonprod'){
    $script:groupEnv = 'devint'
    $script:memberEnv = @('dev','test')
}
elseif($envType -eq 'prod') {
    $script:groupEnv = 'prod'
    $script:memberEnv = @('uat','preprod')
}
elseif($envType -eq 'devops') {
    $script:groupEnv = 'devops'
    $script:memberEnv = @('devops')
}
else {
    Write-Host "`nEnv Type is Incorrect"
    exit 1
}
  

# Obtain the agent ip for firewall purposes.
Write-Host "Obtaining agent ip."
$Script:agentIP = (Invoke-WebRequest https://ifconfig.me/ip | Select-Object Content) -replace "[^\d\.]"

function Get-KVSecret{
    param(
        [Parameter(Mandatory=$true)]
        $KVName,
        [Parameter(Mandatory=$true)]
        $resourceGrpName
    )
    # Pull keyvault values.
    Write-host "Adding keyvault firewall rule for $agentIP" -ForegroundColor White
    Add-AzKeyVaultNetworkRule -VaultName $KVName -ResourceGroupName $resourceGrpName -IpAddressRange $agentIP

    try {
        Write-Host "Pulling secrets from infrastructure vault." -ForegroundColor Cyan
        $Script:sqlserverUserLogin = (Get-AzKeyVaultSecret -VaultName $KVName -Name "abi-datasync-name").SecretValueText
        $Script:sqlserverUserPass  = (Get-AzKeyVaultSecret -VaultName $KVName -Name "abi-datasync-password").SecretValueText
    } 
    catch {
        Write-Host "Error retrieving keyvault secrets:: $Error[0]" -ForegroundColor Red
    } 
    finally {
        Write-host "Removing keyvault firewall rule" -ForegroundColor White
        Remove-AzKeyVaultNetworkRule -VaultName $KVName -ResourceGroupName $resourceGrpName -IpAddressRange $agentIP
    }
}

function Get-Resource {

    param (
        [Parameter(Mandatory=$true)]
        $resType,
        $syncGroupName,
        $resourceGroupName,
        $serverName,
        $databaseName,
        $syncMemberName
    )

    ##################### CHECK RESOURCE #####################
    switch ($resType) {
        syncGroup { 
            $checkResource = Get-AzSqlSyncGroup -Name $syncGroupName `
             -ResourceGroupName $resourceGroupName `
             -ServerName $serverName `
             -DatabaseName $databaseName `
             -ErrorAction Ignore
            if(!$checkResource){
                Write-Warning " :: Sync Group $syncGroupName NOT Found ::"
                return $false
            }
            else {
                Start-Sleep -Seconds 5
                return $true
            }
        }
        syncMember { 
            $checkResource = Get-AzSqlSyncMember -Name $syncMemberName `
             -ResourceGroupName $resourceGroupName `
             -ServerName $serverName `
             -DatabaseName $databaseName `
             -SyncGroupName $syncGroupName `
             -ErrorAction Ignore
            if(!$checkResource){
                Write-Warning " :: Sync Member $syncMemberName NOT Found ::"
                return $false
            }
            else {
                Start-Sleep -Seconds 5
                return $true
            }
        }
        Default {
            Write-Host "B E G I N"
        }
    }
}

function Create-SyncGroup{

    $preCheck = Get-Resource -resType syncGroup -syncGroupName "$($groupParam.parameters.syncGroupName.value)" `
    -serverName "$($groupParam.parameters.sidi_sqlserver_name.value)" `
    -databaseName "$($groupParam.parameters.sidi_synchub_db_name.value)" `
    -resourceGroupName "$($groupParam.rgName)"

    if(!$preCheck){
        Get-KVSecret -KVName $groupParam.parameters.sidi_corevault_name.value -resourceGrpName $groupParam.rgName
        Write-Host "[INFO]:: Creating Sync Group for $($groupParam.parameters.syncGroupName.value)"
        try{        
            ##################### CREATE SYNC GROUP #####################
            $bodySyncGroup = "{
                'properties':{
                    'conflictResolutionPolicy':'hubwin',
                    'hubDatabaseUserName':'$($sqlserverUserLogin)',
                    'hubDatabasePassword':'$($sqlserverUserPass)',
                    'syncDatabaseId':'/subscriptions/$($groupParam.subscriptionID)/resourceGroups/$($groupParam.metaRGName)/providers/Microsoft.Sql/servers/$("abi-sql-sync-$envType")/databases/$("sqldb-abi-mdm-sync-$envType")'
                }
            }"

            $bodySyncGroup = $bodySyncGroup -replace ("`'","`"")

            $requestSyncGroup = @{
                Method = 'PUT' 
                Uri = "https://management.azure.com/subscriptions/$($groupParam.subscriptionID)/resourceGroups/$($groupParam.rgName)/providers/Microsoft.Sql/servers/$($groupParam.parameters.sidi_sqlserver_name.value)/databases/$($groupParam.parameters.sidi_synchub_db_name.value)/syncGroups/$($groupParam.parameters.SyncGroupName.value)?api-version=2021-08-01-preview"
                Headers = @{
                    Authorization = "Bearer $($token)"
                }
                ContentType = 'application/json'
                Body = $bodySyncGroup
            }

            Invoke-RestMethod @requestSyncGroup

            # Check if the SyncGroup is ready
            foreach ($x in 1..20){
                Write-Progress -Activity "Sync Group Creation in Progress" -Status "$($x*5)% Complete" -PercentComplete $($x*5)
                Start-Sleep -Seconds 1
            }
            $checkGroup = Get-Resource -resType syncGroup -syncGroupName "$($groupParam.parameters.syncGroupName.value)" `
            -serverName "$($groupParam.parameters.sidi_sqlserver_name.value)" `
            -databaseName "$($groupParam.parameters.sidi_synchub_db_name.value)" `
            -resourceGroupName "$($groupParam.rgName)"

            if(!$checkGroup){
                exit 1
            }

        }
        catch {
            Write-Host "[ERROR] StatusCode:" $_.Exception.Response.StatusCode.value__
        
            $_
        
            $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
            $streamReader.BaseStream.Position = 0
            $streamReader.DiscardBufferedData()
            $errResp = $streamReader.ReadToEnd()
            $streamReader.Close()
        
            $ErrResp
        
            exit 1
        }
    }
    else {
        Write-Host "[INFO]:: Sync Group $($groupParam.parameters.syncGroupName.value) Present - Continue>"   
    }
}

function Create-SyncMember{
    param(
        $memDatabaseName,
        $hubDatabaseName,
        $syncMemberName,
        $syncGroupName,
        $memServerName,
        $hubServerName,
        $sqlserverUserLogin,
        $sqlserverUserPass,
        $memSubscriptionID,
        $hubSubscriptionID,
        $memResourceGroupName,
        $hubResourceGroupName
    )

    $preCheck = Get-Resource -resType syncMember -syncMemberName $syncMemberName `
    -syncGroupName $syncGroupName `
    -serverName $hubServerName `
    -databaseName $hubDatabaseName `
    -resourceGroupName $hubResourceGroupName
    
    if(!$preCheck){

        try{
            ##################### CREATE SYNC MEMBER #####################
            $bodySyncMember = "{
                'properties':{
                'databaseName':'$($memDatabaseName)',
                'serverName':'$($memServerName).database.windows.net',
                'userName':'$($sqlserverUserLogin)',
                'password':'$($sqlserverUserPass)',
                'syncMemberAzureDatabaseResourceId':'/subscriptions/$($memSubscriptionID)/resourceGroups/$($memResourceGroupName)/providers/Microsoft.Sql/servers/$($memServerName)/databases/$($memDatabaseName)',
                'syncDirection':'OneWayHubToMember',
                'databaseType':'AzureSqlDatabase'
                }
            }"
            $bodySyncMember = $bodySyncMember -replace ("`'","`"")

            $requestSyncMember = @{
                Method = 'PUT' 
                Uri = "https://management.azure.com/subscriptions/$($hubSubscriptionID)/resourceGroups/$($hubResourceGroupName)/providers/Microsoft.Sql/servers/$($hubServerName)/databases/$($hubDatabaseName)/syncGroups/$($syncGroupName)/syncMembers/$($syncMemberName)?api-version=2021-08-01-preview"
                Headers = @{
                    Authorization = "Bearer $($token)"
                }
                ContentType = 'application/json'
                Body = $bodySyncMember
            }

            Invoke-RestMethod @requestSyncMember
        }
        catch {
            Write-Host "[ERROR]:: StatusCode:" $_.Exception.Response.StatusCode.value__
        
            $_
        
            $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
            $streamReader.BaseStream.Position = 0
            $streamReader.DiscardBufferedData()
            $errResp = $streamReader.ReadToEnd()
            $streamReader.Close()
        
            $ErrResp
        
            exit 1
        }
        # Check if the SyncMember is ready
        foreach ($x in 1..20){
            Write-Progress -Activity "Sync Member Creation in Progress" -Status "$($x*5)% Complete" -PercentComplete $($x*5)
            Start-Sleep -Seconds 1
        }
        $checkMember = Get-Resource -resType syncMember -syncMemberName $syncMemberName `
        -syncGroupName $syncGroupName `
        -serverName $hubServerName `
        -databaseName $hubDatabaseName `
        -resourceGroupName $hubDatabaseName

        if(!$checkMember){
            Write-Host "[INFO]:: Sync Member $syncMemberName created"
        }
    }
    else {   
        Write-Host "[INFO]:: Sync Member $syncMemberName Present - Continue>"
    }
}

##################### EXECUTION STARTS #####################

$Script:token = Get-AzAccessToken -Verbose | foreach {$_.Token}

if($token){
    Create-SyncGroup 
    
    if($?){
        for($x=0;$x -lt $memberParam.rgName.Length;$x+=1){
            Get-KVSecret -KVName $($memberParam.parameters.sidi_corevault_name[$x]) -resourceGrpName $memberParam.rgName[$x]

            Write-Host "[INFO]:: Creating Sync Member for $($memberParam.parameters.sidi_syncmember_db_name[$x])"
            Create-SyncMember -memDatabaseName $($memberParam.parameters.sidi_syncmember_db_name[$x]) `
            -hubDatabaseName $($groupParam.parameters.sidi_synchub_db_name.value) `
            -syncMemberName $($memberParam.parameters.syncMemberName[$x]) `
            -syncGroupName $($memberParam.parameters.syncGroupName.value) `
            -memServerName $($memberParam.parameters.sidi_sqlserver_name[$x]) `
            -hubServerName $($groupParam.parameters.sidi_sqlserver_name.value) `
            -sqlserverUserLogin $sqlserverUserLogin `
            -sqlserverUserPass $sqlserverUserPass `
            -memSubscriptionID $($memberParam.subscriptionID) `
            -hubSubscriptionID $($groupParam.subscriptionID) `
            -memResourceGroupName $($memberParam.rgName[$x]) `
            -hubResourceGroupName $($groupParam.rgName)
        }
    }
}

    